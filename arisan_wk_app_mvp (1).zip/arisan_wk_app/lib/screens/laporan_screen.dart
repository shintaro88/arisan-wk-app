import 'package:flutter/material.dart';

import '../core/database/database_helper.dart';
import '../services/pdf_service.dart';

class LaporanScreen extends StatefulWidget {
  const LaporanScreen({super.key});

  @override
  State<LaporanScreen> createState() => _LaporanScreenState();
}

class _LaporanScreenState extends State<LaporanScreen> {
  bool _loading = false;
  String? _lastPath;

  Future<void> _runExport(Future<String> Function() task) async {
    setState(() => _loading = true);
    try {
      final path = await task();
      if (!mounted) return;
      setState(() => _lastPath = path);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('PDF berhasil dibuat: $path')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal export PDF: $e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<String> _exportAnggota() async {
    final db = DatabaseHelper.instance;
    final data = await db.getAnggota();
    final pengaturan = await db.getPengaturan();
    return PdfService().exportGenericReport(
      title: 'Laporan Data Anggota',
      headers: ['No', 'Nama', 'No HP', 'Wilayah', 'Status', 'Ikut Kas', 'Ikut Arisan', 'Tanggal Bergabung'],
      rows: [
        for (var i = 0; i < data.length; i++)
          [i + 1, data[i].nama, data[i].noHp, data[i].wilayah, data[i].status, data[i].ikutKas ? 'Ya' : 'Tidak', data[i].ikutArisan ? 'Ya' : 'Tidak', data[i].tanggalBergabung]
      ],
      pengaturan: pengaturan,
      fileName: 'Laporan_Anggota_WK.pdf',
    );
  }

  Future<String> _exportKas() async {
    final db = DatabaseHelper.instance;
    final data = await db.getKas();
    final pengaturan = await db.getPengaturan();
    return PdfService().exportKas(transaksi: data, pengaturan: pengaturan);
  }

  Future<String> _exportPemenang() async {
    final db = DatabaseHelper.instance;
    final data = await db.getPemenangDetail();
    final pengaturan = await db.getPengaturan();
    return PdfService().exportGenericReport(
      title: 'Laporan Pemenang Arisan',
      headers: ['No', 'Periode', 'Nama', 'Tanggal', 'Nominal', 'Status'],
      rows: [
        for (var i = 0; i < data.length; i++)
          [i + 1, data[i]['nama_periode'], data[i]['nama'], data[i]['tanggal_menang'], data[i]['nominal_diterima'], data[i]['status_penerimaan']]
      ],
      pengaturan: pengaturan,
      fileName: 'Laporan_Pemenang_Arisan_WK.pdf',
    );
  }

  Future<String> _exportPembayaranAktif() async {
    final db = DatabaseHelper.instance;
    final periode = await db.getPeriodeAktif();
    if (periode == null || periode.id == null) throw Exception('Belum ada periode aktif.');
    final data = await db.getPembayaranDetail(periode.id!);
    final pengaturan = await db.getPengaturan();
    return PdfService().exportGenericReport(
      title: 'Laporan Pembayaran Iuran ${periode.namaPeriode}',
      headers: ['No', 'Nama', 'No HP', 'Wilayah', 'Tanggal Bayar', 'Metode', 'Nominal', 'Status'],
      rows: [
        for (var i = 0; i < data.length; i++)
          [i + 1, data[i]['nama'], data[i]['no_hp'], data[i]['wilayah'], data[i]['tanggal_bayar'], data[i]['metode_bayar'], data[i]['nominal_bayar'], data[i]['status_bayar']]
      ],
      pengaturan: pengaturan,
      fileName: 'Laporan_Pembayaran_Iuran_WK.pdf',
    );
  }

  Future<String> _exportBelumBayarAktif() async {
    final db = DatabaseHelper.instance;
    final periode = await db.getPeriodeAktif();
    if (periode == null || periode.id == null) throw Exception('Belum ada periode aktif.');
    final data = await db.getAnggotaBelumBayarDetail(periode.id!);
    final pengaturan = await db.getPengaturan();
    return PdfService().exportGenericReport(
      title: 'Laporan Anggota Belum Bayar ${periode.namaPeriode}',
      headers: ['No', 'Nama', 'No HP', 'Wilayah', 'Nominal Iuran', 'Status'],
      rows: [
        for (var i = 0; i < data.length; i++) [i + 1, data[i]['nama'], data[i]['no_hp'], data[i]['wilayah'], periode.nominalIuran, 'Belum Bayar']
      ],
      pengaturan: pengaturan,
      fileName: 'Laporan_Belum_Bayar_Arisan_WK.pdf',
    );
  }

  Future<String> _exportArisanLengkap() async {
    final db = DatabaseHelper.instance;
    final data = await db.getRingkasanArisan();
    final pengaturan = await db.getPengaturan();
    return PdfService().exportGenericReport(
      title: 'Laporan Ringkasan Arisan WK',
      headers: ['No', 'Periode', 'Tanggal', 'Status', 'Peserta Bayar', 'Nominal Iuran', 'Target Peserta', 'Total Iuran', 'Pencairan', 'Saldo Arisan', 'Pemenang'],
      rows: [
        for (var i = 0; i < data.length; i++)
          [
            i + 1,
            data[i]['nama_periode'],
            data[i]['tanggal_arisan'],
            data[i]['status'],
            data[i]['jumlah_peserta'],
            data[i]['nominal_iuran'],
            ((data[i]['jumlah_peserta'] as num?)?.toDouble() ?? 0) * ((data[i]['nominal_iuran'] as num?)?.toDouble() ?? 0),
            data[i]['total_iuran'],
            data[i]['total_pencairan'],
            ((data[i]['total_iuran'] as num?)?.toDouble() ?? 0) - ((data[i]['total_pencairan'] as num?)?.toDouble() ?? 0),
            data[i]['pemenang'],
          ]
      ],
      pengaturan: pengaturan,
      fileName: 'Laporan_Ringkasan_Arisan_WK.pdf',
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Export Laporan PDF', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text('Laporan dibuat dalam format PDF resmi dan rapi. File disimpan ke folder Download/Arisan WK jika perangkat mengizinkan.'),
                if (_lastPath != null) ...[
                  const SizedBox(height: 12),
                  Text('File terakhir: $_lastPath', style: const TextStyle(fontSize: 12, color: Colors.black54)),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (_loading) const LinearProgressIndicator(),
        _ReportTile(title: 'Laporan Ringkasan Arisan', subtitle: 'Rekap periode, peserta bayar, total iuran, pencairan pemenang, dan saldo arisan.', icon: Icons.event_available, onTap: () => _runExport(_exportArisanLengkap)),
        _ReportTile(title: 'Laporan Pembayaran Iuran', subtitle: 'PDF pembayaran arisan pada periode aktif.', icon: Icons.payments, onTap: () => _runExport(_exportPembayaranAktif)),
        _ReportTile(title: 'Laporan Belum Bayar Arisan', subtitle: 'PDF anggota yang belum membayar pada periode aktif.', icon: Icons.warning_amber, onTap: () => _runExport(_exportBelumBayarAktif)),
        _ReportTile(title: 'Laporan Pemenang Arisan', subtitle: 'PDF riwayat pemenang arisan.', icon: Icons.emoji_events, onTap: () => _runExport(_exportPemenang)),
        _ReportTile(title: 'Laporan Kas WK', subtitle: 'PDF mutasi kas, pemasukan, pengeluaran, dan saldo akhir.', icon: Icons.account_balance_wallet, onTap: () => _runExport(_exportKas)),
        _ReportTile(title: 'Laporan Data Anggota', subtitle: 'PDF data anggota berikut status ikut kas/arisan.', icon: Icons.people, onTap: () => _runExport(_exportAnggota)),
      ],
    );
  }
}

class _ReportTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;

  const _ReportTile({required this.title, required this.subtitle, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.picture_as_pdf_outlined),
        onTap: onTap,
      ),
    );
  }
}
