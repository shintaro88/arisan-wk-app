import 'package:flutter/material.dart';

import '../core/database/database_helper.dart';
import '../core/utils/formatters.dart';
import '../services/pdf_service.dart';

class BuktiIuranScreen extends StatefulWidget {
  const BuktiIuranScreen({super.key});

  @override
  State<BuktiIuranScreen> createState() => _BuktiIuranScreenState();
}

class _BuktiIuranScreenState extends State<BuktiIuranScreen> {
  List<Map<String, dynamic>> _data = [];
  bool _loading = true;
  bool _processing = false;
  String? _lastPath;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final data = await DatabaseHelper.instance.getSemuaPembayaranBukti();
    if (!mounted) return;
    setState(() {
      _data = data;
      _loading = false;
    });
  }

  Future<void> _buatBukti(Map<String, dynamic> item) async {
    setState(() => _processing = true);
    try {
      final pengaturan = await DatabaseHelper.instance.getPengaturan();
      final path = await PdfService().exportBuktiPembayaran(pembayaran: item, pengaturan: pengaturan);
      if (!mounted) return;
      setState(() => _lastPath = path);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Bukti PDF berhasil dibuat: $path')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal membuat bukti: $e')));
    } finally {
      if (mounted) setState(() => _processing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Bukti Pembayaran Iuran', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text('Pilih transaksi iuran arisan, lalu buat bukti PDF. Bukti dilengkapi nomor bukti dan kode validasi otomatis sebagai penanda keaslian data transaksi.'),
                if (_processing) ...[
                  const SizedBox(height: 12),
                  const LinearProgressIndicator(),
                ],
                if (_lastPath != null) ...[
                  const SizedBox(height: 12),
                  Text('File terakhir: $_lastPath', style: const TextStyle(fontSize: 12, color: Colors.black54)),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (_data.isEmpty)
          const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('Belum ada pembayaran iuran yang bisa dibuatkan bukti.')))
        else
          ..._data.map((item) {
            final nominal = (item['nominal_bayar'] as num?)?.toDouble() ?? 0;
            return Card(
              child: ListTile(
                leading: const Icon(Icons.receipt_long_outlined),
                title: Text(item['nama']?.toString() ?? '-', style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('${item['nama_periode']} • ${item['tanggal_bayar']}\n${AppFormatters.rupiah(nominal)} • ${item['status_bayar']}'),
                isThreeLine: true,
                trailing: IconButton(
                  icon: const Icon(Icons.picture_as_pdf_outlined),
                  tooltip: 'Buat Bukti PDF',
                  onPressed: _processing ? null : () => _buatBukti(item),
                ),
              ),
            );
          }),
      ],
    );
  }
}
