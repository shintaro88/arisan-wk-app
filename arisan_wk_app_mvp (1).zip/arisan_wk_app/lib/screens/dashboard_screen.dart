import 'package:flutter/material.dart';

import '../core/database/database_helper.dart';
import '../core/utils/formatters.dart';
import '../models/anggota_model.dart';
import '../models/kas_model.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int aktif = 0;
  int nonAktif = 0;
  int ikutArisan = 0;
  int ikutKas = 0;
  int sudahBayarArisan = 0;
  int belumBayarArisan = 0;
  double saldoKas = 0;
  double totalPemasukan = 0;
  double totalPengeluaran = 0;
  double totalIuranAktif = 0;
  double pencairanAktif = 0;
  String periodeAktif = '-';
  String pemenangTerakhir = '-';
  int? periodeAktifId;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = DatabaseHelper.instance;
    final pa = await db.getPeriodeAktif();
    final pt = await db.getPemenangTerakhir();
    var sudah = 0;
    var belum = 0;
    var iuran = 0.0;
    var pencairan = 0.0;
    if (pa?.id != null) {
      sudah = await db.countPembayaranStatus(pa!.id!, 'Sudah Bayar');
      final belumList = await db.getAnggotaBelumBayar(pa.id!);
      belum = belumList.length;
      iuran = await db.totalIuranPeriode(pa.id!);
      pencairan = await db.totalPencairanPeriode(pa.id!);
    }

    final result = await Future.wait([
      db.countAnggota('Aktif'),
      db.countAnggota('Nonaktif'),
      db.countAnggotaIkut(jenis: 'arisan'),
      db.countAnggotaIkut(jenis: 'kas'),
      db.getSaldoKas(),
      db.totalKasByJenis('Pemasukan'),
      db.totalKasByJenis('Pengeluaran'),
    ]);
    if (!mounted) return;
    setState(() {
      aktif = result[0] as int;
      nonAktif = result[1] as int;
      ikutArisan = result[2] as int;
      ikutKas = result[3] as int;
      saldoKas = result[4] as double;
      totalPemasukan = result[5] as double;
      totalPengeluaran = result[6] as double;
      sudahBayarArisan = sudah;
      belumBayarArisan = belum;
      totalIuranAktif = iuran;
      pencairanAktif = pencairan;
      periodeAktif = pa?.namaPeriode ?? '-';
      periodeAktifId = pa?.id;
      pemenangTerakhir = pt == null ? '-' : '${pt['nama']} / ${pt['nama_periode']}';
      loading = false;
    });
  }

  String _memberLines(List<Anggota> members) {
    if (members.isEmpty) return 'Tidak ada data.';
    return members.map((a) => '• ${a.nama}${a.wilayah.isNotEmpty ? ' - ${a.wilayah}' : ''}').join('\n');
  }

  String _paymentLines(List<Map<String, dynamic>> payments) {
    if (payments.isEmpty) return 'Tidak ada data pembayaran pada periode aktif.';
    return payments.map((p) {
      final nama = p['nama'] ?? '-';
      final status = p['status_bayar'] ?? '-';
      final nominal = AppFormatters.rupiah((p['nominal_bayar'] as num?)?.toDouble() ?? 0);
      return '• $nama - $status - $nominal';
    }).join('\n');
  }

  String _kasLines(List<KasTransaksi> transaksi, String jenis) {
    final filtered = transaksi.where((k) => k.jenisTransaksi == jenis).toList();
    if (filtered.isEmpty) return 'Belum ada transaksi $jenis.';
    return filtered.take(20).map((k) {
      return '• ${k.tanggalTransaksi} - ${k.kategori} - ${AppFormatters.rupiah(k.nominal)}\n  ${k.keterangan}';
    }).join('\n');
  }

  Future<void> _showDetail(String title, Future<String> Function() contentBuilder) async {
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (context) => const AlertDialog(
        content: Row(
          children: [
            SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2)),
            SizedBox(width: 16),
            Expanded(child: Text('Mengambil detail data...')),
          ],
        ),
      ),
    );

    String content;
    try {
      content = await contentBuilder();
    } catch (e) {
      content = 'Detail gagal dimuat: ${e.toString()}';
    }

    if (!mounted) return;
    Navigator.pop(context);
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 520),
          child: SingleChildScrollView(child: Text(content)),
        ),
        actions: [
          FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Tutup')),
        ],
      ),
    );
  }

  Future<String> _detailAnggotaAktif() async {
    final members = await DatabaseHelper.instance.getAnggota(status: 'Aktif');
    return 'Total anggota aktif: $aktif\n\nDaftar anggota:\n${_memberLines(members)}';
  }

  Future<String> _detailAnggotaNonAktif() async {
    final members = await DatabaseHelper.instance.getAnggota(status: 'Nonaktif');
    return 'Total anggota nonaktif: $nonAktif\n\nDaftar anggota:\n${_memberLines(members)}';
  }

  Future<String> _detailIkutArisan() async {
    final members = await DatabaseHelper.instance.getAnggotaIkutArisan();
    return 'Total anggota ikut arisan: $ikutArisan\n\nDaftar anggota:\n${_memberLines(members)}';
  }

  Future<String> _detailIkutKas() async {
    final members = await DatabaseHelper.instance.getAnggotaIkutKas();
    return 'Total anggota ikut kas: $ikutKas\n\nDaftar anggota:\n${_memberLines(members)}';
  }

  Future<String> _detailPembayaran() async {
    if (periodeAktifId == null) return 'Belum ada periode arisan aktif.';
    final payments = await DatabaseHelper.instance.getPembayaranDetail(periodeAktifId!);
    return 'Periode aktif: $periodeAktif\nTotal sudah bayar: $sudahBayarArisan\nTotal iuran masuk: ${AppFormatters.rupiah(totalIuranAktif)}\n\nDaftar pembayaran:\n${_paymentLines(payments)}';
  }

  Future<String> _detailBelumBayar() async {
    if (periodeAktifId == null) return 'Belum ada periode arisan aktif.';
    final members = await DatabaseHelper.instance.getAnggotaBelumBayar(periodeAktifId!);
    return 'Periode aktif: $periodeAktif\nTotal belum bayar: $belumBayarArisan\n\nDaftar belum bayar:\n${_memberLines(members)}';
  }

  Future<String> _detailSaldoArisan() async {
    final saldoArisan = totalIuranAktif - pencairanAktif;
    return 'Periode aktif: $periodeAktif\n\nTotal iuran terkumpul: ${AppFormatters.rupiah(totalIuranAktif)}\nTotal pencairan pemenang: ${AppFormatters.rupiah(pencairanAktif)}\nSaldo arisan aktif: ${AppFormatters.rupiah(saldoArisan)}\n\nCatatan: saldo arisan otomatis berkurang setelah pemenang dicatat dengan status penerimaan Sudah Diterima.';
  }

  Future<String> _detailKas(String jenis) async {
    final transaksi = await DatabaseHelper.instance.getKas();
    final total = jenis == 'Pemasukan' ? totalPemasukan : totalPengeluaran;
    return 'Total $jenis kas: ${AppFormatters.rupiah(total)}\nSaldo kas saat ini: ${AppFormatters.rupiah(saldoKas)}\n\nTransaksi terbaru:\n${_kasLines(transaksi, jenis)}';
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());
    final saldoArisan = totalIuranAktif - pencairanAktif;
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Ringkasan WK', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text('Periode aktif: $periodeAktif'),
                  Text('Pemenang terakhir: $pemenangTerakhir'),
                  const SizedBox(height: 8),
                  const Text('Ketuk kotak ringkasan untuk melihat detail datanya.', style: TextStyle(fontSize: 12, color: Colors.black54)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: MediaQuery.of(context).size.width > 600 ? 3 : 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.25,
            children: [
              _InfoCard(title: 'Anggota Aktif', value: '$aktif', icon: Icons.people, onTap: () => _showDetail('Detail Anggota Aktif', _detailAnggotaAktif)),
              _InfoCard(title: 'Ikut Arisan', value: '$ikutArisan', icon: Icons.groups, onTap: () => _showDetail('Detail Anggota Ikut Arisan', _detailIkutArisan)),
              _InfoCard(title: 'Ikut Kas', value: '$ikutKas', icon: Icons.savings, onTap: () => _showDetail('Detail Anggota Ikut Kas', _detailIkutKas)),
              _InfoCard(title: 'Sudah Bayar Arisan', value: '$sudahBayarArisan', icon: Icons.check_circle, onTap: () => _showDetail('Detail Pembayaran Arisan', _detailPembayaran)),
              _InfoCard(title: 'Belum Bayar Arisan', value: '$belumBayarArisan', icon: Icons.warning_amber, onTap: () => _showDetail('Detail Belum Bayar Arisan', _detailBelumBayar)),
              _InfoCard(title: 'Total Iuran Arisan', value: AppFormatters.rupiah(totalIuranAktif), icon: Icons.payments, onTap: () => _showDetail('Detail Total Iuran Arisan', _detailPembayaran)),
              _InfoCard(title: 'Saldo Arisan Aktif', value: AppFormatters.rupiah(saldoArisan), icon: Icons.event_available, onTap: () => _showDetail('Detail Saldo Arisan Aktif', _detailSaldoArisan)),
              _InfoCard(title: 'Saldo Kas', value: AppFormatters.rupiah(saldoKas), icon: Icons.account_balance_wallet, onTap: () => _showDetail('Detail Saldo Kas', () => _detailKas('Pemasukan'))),
              _InfoCard(title: 'Pemasukan Kas', value: AppFormatters.rupiah(totalPemasukan), icon: Icons.trending_up, onTap: () => _showDetail('Detail Pemasukan Kas', () => _detailKas('Pemasukan'))),
              _InfoCard(title: 'Pengeluaran Kas', value: AppFormatters.rupiah(totalPengeluaran), icon: Icons.trending_down, onTap: () => _showDetail('Detail Pengeluaran Kas', () => _detailKas('Pengeluaran'))),
              _InfoCard(title: 'Anggota Nonaktif', value: '$nonAktif', icon: Icons.person_off, onTap: () => _showDetail('Detail Anggota Nonaktif', _detailAnggotaNonAktif)),
            ],
          ),
          const SizedBox(height: 16),
          const Text('Tarik layar ke bawah untuk refresh data dashboard.', style: TextStyle(color: Colors.black54)),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final VoidCallback? onTap;

  const _InfoCard({required this.title, required this.value, required this.icon, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(icon, size: 32, color: Theme.of(context).colorScheme.primary),
                  Icon(Icons.touch_app_outlined, size: 18, color: Colors.grey.shade500),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis),
                  Text(title, style: const TextStyle(color: Colors.black54), maxLines: 2),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
