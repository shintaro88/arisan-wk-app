import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class NumericTextField extends StatefulWidget {
  final TextEditingController controller;
  final String labelText;
  final String? Function(String?)? validator;
  final void Function(String)? onChanged;
  final bool enabled;

  const NumericTextField({
    super.key,
    required this.controller,
    required this.labelText,
    this.validator,
    this.onChanged,
    this.enabled = true,
  });

  @override
  State<NumericTextField> createState() => _NumericTextFieldState();
}

class _NumericTextFieldState extends State<NumericTextField> {
  bool _warningOpen = false;

  void _showWarning() {
    if (_warningOpen || !mounted) return;
    _warningOpen = true;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Nominal tidak valid'),
          content: const Text('Kolom nominal hanya boleh diisi angka. Gunakan angka tanpa titik, koma, Rp, atau simbol lain.'),
          actions: [
            FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Mengerti')),
          ],
        ),
      );
      _warningOpen = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: widget.controller,
      enabled: widget.enabled,
      decoration: InputDecoration(labelText: widget.labelText),
      keyboardType: TextInputType.number,
      inputFormatters: [
        TextInputFormatter.withFunction((oldValue, newValue) {
          final valid = RegExp(r'^\d*$').hasMatch(newValue.text);
          if (!valid) {
            _showWarning();
            return oldValue;
          }
          return newValue;
        }),
      ],
      validator: (value) {
        final text = value ?? '';
        if (!RegExp(r'^\d+$').hasMatch(text)) {
          return 'Nominal hanya boleh angka';
        }
        return widget.validator?.call(value);
      },
      onChanged: widget.onChanged,
    );
  }
}
