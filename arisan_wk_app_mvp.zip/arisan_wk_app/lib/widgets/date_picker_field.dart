import 'package:flutter/material.dart';

import '../core/utils/formatters.dart';

class DatePickerField extends StatelessWidget {
  final TextEditingController controller;
  final String labelText;
  final String? helperText;
  final String? Function(String?)? validator;
  final DateTime? firstDate;
  final DateTime? lastDate;

  const DatePickerField({
    super.key,
    required this.controller,
    required this.labelText,
    this.helperText,
    this.validator,
    this.firstDate,
    this.lastDate,
  });

  Future<void> _pickDate(BuildContext context) async {
    final initial = AppFormatters.tryParseDate(controller.text) ?? DateTime.now();
    final selected = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: firstDate ?? DateTime(2000),
      lastDate: lastDate ?? DateTime(2100),
      helpText: 'Pilih Tanggal',
      cancelText: 'Batal',
      confirmText: 'Pilih',
      fieldLabelText: labelText,
    );
    if (selected != null) {
      controller.text = AppFormatters.formatDate(selected);
    }
  }

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      readOnly: true,
      decoration: InputDecoration(
        labelText: labelText,
        helperText: helperText,
        suffixIcon: const Icon(Icons.calendar_month_outlined),
      ),
      validator: validator,
      onTap: () => _pickDate(context),
    );
  }
}
