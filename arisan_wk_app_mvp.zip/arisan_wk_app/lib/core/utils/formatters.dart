import 'package:intl/intl.dart';

class AppFormatters {
  static final NumberFormat _rupiah = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);
  static final DateFormat _date = DateFormat('yyyy-MM-dd');

  static String rupiah(num value) => _rupiah.format(value);

  static String today() => _date.format(DateTime.now());

  static String formatDate(DateTime value) => _date.format(value);

  static DateTime? tryParseDate(String value) {
    try {
      if (value.trim().isEmpty) return null;
      return _date.parseStrict(value.trim());
    } catch (_) {
      return null;
    }
  }

  static double parseNumber(String value) {
    final clean = value.replaceAll('.', '').replaceAll(',', '').replaceAll('Rp', '').trim();
    return double.tryParse(clean) ?? 0;
  }
}
