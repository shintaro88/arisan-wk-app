import 'dart:io';

import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import '../../models/anggota_model.dart';
import '../../models/kas_model.dart';
import '../../models/pembayaran_model.dart';
import '../../models/pemenang_model.dart';
import '../../models/pengaturan_model.dart';
import '../../models/periode_model.dart';

class DatabaseHelper {
  DatabaseHelper._internal();
  static final DatabaseHelper instance = DatabaseHelper._internal();

  static Database? _database;
  static const String _dbName = 'arisan_wk.db';

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<String> get databasePath async {
    final dbPath = await getDatabasesPath();
    return join(dbPath, _dbName);
  }

  Future<Database> _initDatabase() async {
    final path = await databasePath;

    return openDatabase(
      path,
      version: 5,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE anggota (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL,
        no_hp TEXT,
        alamat TEXT,
        wilayah TEXT,
        status TEXT NOT NULL,
        tanggal_bergabung TEXT,
        catatan TEXT,
        ikut_arisan INTEGER NOT NULL DEFAULT 1,
        ikut_kas INTEGER NOT NULL DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE periode_arisan (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama_periode TEXT NOT NULL,
        tanggal_arisan TEXT,
        lokasi TEXT,
        nominal_iuran REAL NOT NULL,
        status TEXT NOT NULL,
        catatan TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE pembayaran_iuran (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_anggota INTEGER NOT NULL,
        id_periode INTEGER NOT NULL,
        nominal_iuran REAL NOT NULL,
        nominal_bayar REAL NOT NULL,
        tanggal_bayar TEXT,
        metode_bayar TEXT,
        status_bayar TEXT,
        catatan TEXT,
        UNIQUE(id_anggota, id_periode),
        FOREIGN KEY(id_anggota) REFERENCES anggota(id),
        FOREIGN KEY(id_periode) REFERENCES periode_arisan(id)
      )
    ''');

    await db.execute('''
      CREATE TABLE pemenang_arisan (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_periode INTEGER NOT NULL,
        id_anggota INTEGER NOT NULL,
        tanggal_menang TEXT,
        nominal_diterima REAL NOT NULL,
        status_penerimaan TEXT,
        catatan TEXT,
        FOREIGN KEY(id_anggota) REFERENCES anggota(id),
        FOREIGN KEY(id_periode) REFERENCES periode_arisan(id)
      )
    ''');

    await db.execute('''
      CREATE TABLE kas_transaksi (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tanggal_transaksi TEXT,
        jenis_transaksi TEXT NOT NULL,
        kategori TEXT,
        nominal REAL NOT NULL,
        keterangan TEXT NOT NULL,
        penanggung_jawab TEXT,
        id_anggota INTEGER,
        FOREIGN KEY(id_anggota) REFERENCES anggota(id)
      )
    ''');

    await db.execute('''
      CREATE TABLE pengaturan (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama_organisasi TEXT,
        nama_ketua TEXT,
        nama_bendahara TEXT,
        nama_sekretaris TEXT,
        default_iuran_arisan REAL,
        default_iuran_kas REAL
      )
    ''');

    await db.insert('pengaturan', const Pengaturan(
      namaOrganisasi: 'Wanita Katolik',
      namaKetua: '',
      namaBendahara: '',
      namaSekretaris: '',
      defaultIuranArisan: 50000,
      defaultIuranKas: 10000,
    ).toMap());

    await db.insert('anggota', const Anggota(
      nama: 'Maria Contoh',
      noHp: '081234567890',
      alamat: 'Contoh alamat',
      wilayah: 'Lingkungan 1',
      status: 'Aktif',
      tanggalBergabung: '2026-01-01',
      catatan: 'Data dummy awal',
      ikutArisan: true,
      ikutKas: true,
    ).toMap());

    await db.insert('periode_arisan', const PeriodeArisan(
      namaPeriode: 'Arisan Mei 2026',
      tanggalArisan: '2026-05-31',
      lokasi: 'Aula Paroki',
      nominalIuran: 50000,
      status: 'Aktif',
      catatan: 'Periode contoh',
    ).toMap());
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    await _ensureSchema(db);
  }

  Future<void> restructureDatabase() async {
    final db = await database;
    await _ensureSchema(db);
  }

  Future<void> _ensureSchema(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String definition) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((row) => row['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $definition');
      }
    }

    await addColumnIfMissing('anggota', 'ikut_arisan', 'INTEGER NOT NULL DEFAULT 1');
    await addColumnIfMissing('anggota', 'ikut_kas', 'INTEGER NOT NULL DEFAULT 1');
    await addColumnIfMissing('kas_transaksi', 'id_anggota', 'INTEGER');
  }

  Future<int> insertAnggota(Anggota anggota) async {
    final db = await database;
    return db.insert('anggota', anggota.toMap());
  }

  Future<int> updateAnggota(Anggota anggota) async {
    final db = await database;
    return db.update('anggota', anggota.toMap(), where: 'id = ?', whereArgs: [anggota.id]);
  }

  Future<int> deleteAnggota(int id) async {
    final db = await database;
    return db.delete('anggota', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Anggota>> getAnggota({String keyword = '', String status = 'Semua'}) async {
    final db = await database;
    final where = <String>[];
    final args = <Object>[];

    if (keyword.isNotEmpty) {
      where.add('nama LIKE ?');
      args.add('%$keyword%');
    }
    if (status != 'Semua') {
      where.add('status = ?');
      args.add(status);
    }

    final maps = await db.query(
      'anggota',
      where: where.isEmpty ? null : where.join(' AND '),
      whereArgs: args,
      orderBy: 'nama ASC',
    );
    return maps.map(Anggota.fromMap).toList();
  }

  Future<int> countAnggota(String status) async {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) AS total FROM anggota WHERE status = ?', [status]);
    return Sqflite.firstIntValue(result) ?? 0;
  }


  Future<int> countAnggotaIkut({required String jenis}) async {
    final db = await database;
    final column = jenis == 'kas' ? 'ikut_kas' : 'ikut_arisan';
    final result = await db.rawQuery("SELECT COUNT(*) AS total FROM anggota WHERE status = 'Aktif' AND $column = 1");
    return Sqflite.firstIntValue(result) ?? 0;
  }

  Future<List<Anggota>> getAnggotaIkutKas() async {
    final db = await database;
    final maps = await db.query('anggota', where: 'status = ? AND ikut_kas = 1', whereArgs: ['Aktif'], orderBy: 'nama ASC');
    return maps.map(Anggota.fromMap).toList();
  }

  Future<List<Anggota>> getAnggotaIkutArisan() async {
    final db = await database;
    final maps = await db.query('anggota', where: 'status = ? AND ikut_arisan = 1', whereArgs: ['Aktif'], orderBy: 'nama ASC');
    return maps.map(Anggota.fromMap).toList();
  }

  Future<int> insertPeriode(PeriodeArisan periode) async {
    final db = await database;
    return db.insert('periode_arisan', periode.toMap());
  }

  Future<int> updatePeriode(PeriodeArisan periode) async {
    final db = await database;
    return db.update('periode_arisan', periode.toMap(), where: 'id = ?', whereArgs: [periode.id]);
  }

  Future<int> deletePeriode(int id) async {
    final db = await database;
    return db.delete('periode_arisan', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<PeriodeArisan>> getPeriode() async {
    final db = await database;
    final maps = await db.query('periode_arisan', orderBy: 'id DESC');
    return maps.map(PeriodeArisan.fromMap).toList();
  }

  Future<PeriodeArisan?> getPeriodeAktif() async {
    final db = await database;
    final maps = await db.query('periode_arisan', where: 'status = ?', whereArgs: ['Aktif'], limit: 1, orderBy: 'id DESC');
    if (maps.isEmpty) return null;
    return PeriodeArisan.fromMap(maps.first);
  }

  Future<bool> existsPembayaran(int idAnggota, int idPeriode) async {
    final db = await database;
    final result = await db.rawQuery(
      'SELECT COUNT(*) AS total FROM pembayaran_iuran WHERE id_anggota = ? AND id_periode = ?',
      [idAnggota, idPeriode],
    );
    return (Sqflite.firstIntValue(result) ?? 0) > 0;
  }

  Future<int> insertPembayaran(PembayaranIuran pembayaran) async {
    final db = await database;
    final exists = await existsPembayaran(pembayaran.idAnggota, pembayaran.idPeriode);
    if (exists) {
      throw Exception('Anggota ini sudah tercatat membayar pada periode yang sama. Data tidak disimpan agar tidak duplikat.');
    }
    return db.insert('pembayaran_iuran', pembayaran.toMap(), conflictAlgorithm: ConflictAlgorithm.abort);
  }

  Future<int> deletePembayaran(int id) async {
    final db = await database;
    return db.delete('pembayaran_iuran', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Map<String, dynamic>>> getPembayaranDetail(int idPeriode) async {
    final db = await database;
    return db.rawQuery('''
      SELECT p.*, a.nama, a.no_hp, a.wilayah
      FROM pembayaran_iuran p
      JOIN anggota a ON a.id = p.id_anggota
      WHERE p.id_periode = ?
      ORDER BY a.nama ASC
    ''', [idPeriode]);
  }


  Future<List<Map<String, dynamic>>> getSemuaPembayaranBukti() async {
    final db = await database;
    return db.rawQuery('''
      SELECT p.*, a.nama, a.no_hp, a.wilayah, pr.nama_periode
      FROM pembayaran_iuran p
      JOIN anggota a ON a.id = p.id_anggota
      JOIN periode_arisan pr ON pr.id = p.id_periode
      ORDER BY p.tanggal_bayar DESC, p.id DESC
    ''');
  }

  Future<List<Anggota>> getAnggotaBelumBayar(int idPeriode) async {
    final db = await database;
    final maps = await db.rawQuery('''
      SELECT a.*
      FROM anggota a
      WHERE a.status = 'Aktif'
        AND COALESCE(a.ikut_arisan, 1) = 1
        AND NOT EXISTS (
          SELECT 1 FROM pembayaran_iuran p
          WHERE p.id_anggota = a.id AND p.id_periode = ?
        )
      ORDER BY a.nama ASC
    ''', [idPeriode]);
    return maps.map(Anggota.fromMap).toList();
  }

  Future<List<Map<String, dynamic>>> getAnggotaBelumBayarDetail(int idPeriode) async {
    final db = await database;
    return db.rawQuery('''
      SELECT a.id, a.nama, a.no_hp, a.wilayah
      FROM anggota a
      WHERE a.status = 'Aktif'
        AND COALESCE(a.ikut_arisan, 1) = 1
        AND NOT EXISTS (
          SELECT 1 FROM pembayaran_iuran p
          WHERE p.id_anggota = a.id AND p.id_periode = ?
        )
      ORDER BY a.nama ASC
    ''', [idPeriode]);
  }

  Future<int> countPembayaranStatus(int idPeriode, String status) async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT COUNT(*) AS total FROM pembayaran_iuran
      WHERE id_periode = ? AND status_bayar = ?
    ''', [idPeriode, status]);
    return Sqflite.firstIntValue(result) ?? 0;
  }

  Future<double> totalIuranPeriode(int idPeriode) async {
    final db = await database;
    final result = await db.rawQuery('SELECT SUM(nominal_bayar) AS total FROM pembayaran_iuran WHERE id_periode = ?', [idPeriode]);
    final value = result.first['total'];
    return (value as num?)?.toDouble() ?? 0;
  }

  Future<double> totalPencairanPeriode(int idPeriode) async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT SUM(nominal_diterima) AS total
      FROM pemenang_arisan
      WHERE id_periode = ? AND status_penerimaan = 'Sudah Diterima'
    ''', [idPeriode]);
    return (result.first['total'] as num?)?.toDouble() ?? 0;
  }

  Future<List<Map<String, dynamic>>> getRingkasanArisan() async {
    final db = await database;
    return db.rawQuery('''
      SELECT
        pr.id,
        pr.nama_periode,
        pr.tanggal_arisan,
        pr.lokasi,
        pr.nominal_iuran,
        pr.status,
        COUNT(DISTINCT p.id_anggota) AS jumlah_peserta,
        COALESCE(SUM(p.nominal_bayar), 0) AS total_iuran,
        COALESCE((
          SELECT SUM(pm.nominal_diterima)
          FROM pemenang_arisan pm
          WHERE pm.id_periode = pr.id AND pm.status_penerimaan = 'Sudah Diterima'
        ), 0) AS total_pencairan,
        COALESCE((
          SELECT GROUP_CONCAT(a2.nama, ', ')
          FROM pemenang_arisan pm2
          JOIN anggota a2 ON a2.id = pm2.id_anggota
          WHERE pm2.id_periode = pr.id
        ), '') AS pemenang
      FROM periode_arisan pr
      LEFT JOIN pembayaran_iuran p ON p.id_periode = pr.id
      GROUP BY pr.id, pr.nama_periode, pr.tanggal_arisan, pr.lokasi, pr.nominal_iuran, pr.status
      ORDER BY pr.id DESC
    ''');
  }

  Future<int> insertPemenang(PemenangArisan pemenang) async {
    final db = await database;
    return db.insert('pemenang_arisan', pemenang.toMap());
  }

  Future<int> deletePemenang(int id) async {
    final db = await database;
    return db.delete('pemenang_arisan', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Map<String, dynamic>>> getPemenangDetail() async {
    final db = await database;
    return db.rawQuery('''
      SELECT pm.*, a.nama, pr.nama_periode
      FROM pemenang_arisan pm
      JOIN anggota a ON a.id = pm.id_anggota
      JOIN periode_arisan pr ON pr.id = pm.id_periode
      ORDER BY pm.id DESC
    ''');
  }

  Future<Map<String, dynamic>?> getPemenangTerakhir() async {
    final db = await database;
    final maps = await db.rawQuery('''
      SELECT pm.*, a.nama, pr.nama_periode
      FROM pemenang_arisan pm
      JOIN anggota a ON a.id = pm.id_anggota
      JOIN periode_arisan pr ON pr.id = pm.id_periode
      ORDER BY pm.id DESC
      LIMIT 1
    ''');
    if (maps.isEmpty) return null;
    return maps.first;
  }

  String _monthKey(String date) {
    if (date.length >= 7) return date.substring(0, 7);
    return date;
  }

  Future<bool> existsKasIuranBulanan({required String tanggal, int? ignoreId}) async {
    final db = await database;
    final args = <Object?>[_monthKey(tanggal)];
    var whereIgnore = '';
    if (ignoreId != null) {
      whereIgnore = ' AND id != ?';
      args.add(ignoreId);
    }
    final result = await db.rawQuery('''
      SELECT COUNT(*) AS total
      FROM kas_transaksi
      WHERE jenis_transaksi = 'Pemasukan'
        AND kategori = 'Iuran Kas'
        AND substr(tanggal_transaksi, 1, 7) = ?
        $whereIgnore
    ''', args);
    return (Sqflite.firstIntValue(result) ?? 0) > 0;
  }

  Future<double> totalIuranKasBulanan(String tanggal) async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT SUM(nominal) AS total
      FROM kas_transaksi
      WHERE jenis_transaksi = 'Pemasukan'
        AND kategori = 'Iuran Kas'
        AND substr(tanggal_transaksi, 1, 7) = ?
    ''', [_monthKey(tanggal)]);
    return (result.first['total'] as num?)?.toDouble() ?? 0;
  }

  Future<List<String>> getNamaAnggotaIkutKas() async {
    final anggota = await getAnggotaIkutKas();
    return anggota.map((a) => a.nama).toList();
  }

  Future<void> _validateKasDuplicate(KasTransaksi kas) async {
    if (kas.jenisTransaksi == 'Pemasukan' && kas.kategori == 'Iuran Kas') {
      final duplicate = await existsKasIuranBulanan(tanggal: kas.tanggalTransaksi, ignoreId: kas.id);
      if (duplicate) {
        throw Exception('Iuran kas untuk bulan yang sama sudah pernah dicatat. Data tidak disimpan agar tidak duplikat.');
      }
    }
  }

  Future<int> insertKas(KasTransaksi kas) async {
    final db = await database;
    await _validateKasDuplicate(kas);
    return db.insert('kas_transaksi', kas.toMap());
  }

  Future<int> updateKas(KasTransaksi kas) async {
    final db = await database;
    await _validateKasDuplicate(kas);
    return db.update('kas_transaksi', kas.toMap(), where: 'id = ?', whereArgs: [kas.id]);
  }

  Future<int> deleteKas(int id) async {
    final db = await database;
    return db.delete('kas_transaksi', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<KasTransaksi>> getKas() async {
    final db = await database;
    final maps = await db.query('kas_transaksi', orderBy: 'tanggal_transaksi DESC, id DESC');
    return maps.map(KasTransaksi.fromMap).toList();
  }

  Future<double> getSaldoKas() async {
    final db = await database;
    final pemasukan = await db.rawQuery("SELECT SUM(nominal) AS total FROM kas_transaksi WHERE jenis_transaksi = 'Pemasukan'");
    final pengeluaran = await db.rawQuery("SELECT SUM(nominal) AS total FROM kas_transaksi WHERE jenis_transaksi = 'Pengeluaran'");
    final totalMasuk = (pemasukan.first['total'] as num?)?.toDouble() ?? 0;
    final totalKeluar = (pengeluaran.first['total'] as num?)?.toDouble() ?? 0;
    return totalMasuk - totalKeluar;
  }

  Future<double> totalKasByJenis(String jenis) async {
    final db = await database;
    final result = await db.rawQuery('SELECT SUM(nominal) AS total FROM kas_transaksi WHERE jenis_transaksi = ?', [jenis]);
    return (result.first['total'] as num?)?.toDouble() ?? 0;
  }

  Future<Pengaturan> getPengaturan() async {
    final db = await database;
    final maps = await db.query('pengaturan', limit: 1);
    if (maps.isEmpty) {
      return const Pengaturan(
        namaOrganisasi: 'Wanita Katolik',
        namaKetua: '',
        namaBendahara: '',
        namaSekretaris: '',
        defaultIuranArisan: 50000,
        defaultIuranKas: 10000,
      );
    }
    return Pengaturan.fromMap(maps.first);
  }

  Future<int> updatePengaturan(Pengaturan pengaturan) async {
    final db = await database;
    if (pengaturan.id == null) return db.insert('pengaturan', pengaturan.toMap());
    return db.update('pengaturan', pengaturan.toMap(), where: 'id = ?', whereArgs: [pengaturan.id]);
  }

  Future<String> backupDatabase() async {
    final sourcePath = await databasePath;
    await _database?.close();
    _database = null;

    final source = File(sourcePath);
    if (!await source.exists()) {
      await database;
    }

    final backupDir = await _resolveBackupDirectory();
    final now = DateTime.now();
    final stamp = '${now.year}${_two(now.month)}${_two(now.day)}_${_two(now.hour)}${_two(now.minute)}${_two(now.second)}';
    final targetPath = join(backupDir.path, 'arisan_wk_backup_$stamp.db');
    await File(sourcePath).copy(targetPath);
    await database;
    return targetPath;
  }

  Future<String> restoreLatestBackup() async {
    final backupDir = await _resolveBackupDirectory();
    if (!await backupDir.exists()) {
      throw Exception('Folder backup belum tersedia. Buat backup terlebih dahulu.');
    }

    final backups = backupDir
        .listSync()
        .whereType<File>()
        .where((file) => basename(file.path).startsWith('arisan_wk_backup_') && basename(file.path).endsWith('.db'))
        .toList()
      ..sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));

    if (backups.isEmpty) {
      throw Exception('File backup tidak ditemukan.');
    }

    await _database?.close();
    _database = null;
    final targetPath = await databasePath;
    await backups.first.copy(targetPath);
    await database;
    return backups.first.path;
  }


  Future<String> restoreDatabaseFromFile(String selectedPath) async {
    final source = File(selectedPath);
    if (!await source.exists()) {
      throw Exception('File backup tidak ditemukan. Pilih file backup database yang valid.');
    }

    final fileName = basename(source.path).toLowerCase();
    if (!fileName.endsWith('.db')) {
      throw Exception('Format file tidak sesuai. Pilih file backup dengan ekstensi .db');
    }

    final size = await source.length();
    if (size <= 0) {
      throw Exception('File backup kosong atau tidak valid.');
    }

    await _database?.close();
    _database = null;
    final targetPath = await databasePath;

    for (final path in [targetPath, '$targetPath-wal', '$targetPath-shm', '$targetPath-journal']) {
      final file = File(path);
      if (await file.exists()) {
        await file.delete();
      }
    }

    await source.copy(targetPath);
    await database;
    await restructureDatabase();
    return source.path;
  }

  String _two(int value) => value.toString().padLeft(2, '0');

  Future<Directory> _resolveBackupDirectory() async {
    final candidates = <Directory>[];

    if (Platform.isAndroid) {
      candidates.add(Directory('/storage/emulated/0/Download/Arisan WK/Backup Database'));
      candidates.add(Directory('/sdcard/Download/Arisan WK/Backup Database'));
    }

    try {
      final systemDownloads = await getDownloadsDirectory();
      if (systemDownloads != null) {
        candidates.add(Directory(join(systemDownloads.path, 'Arisan WK', 'Backup Database')));
      }
    } catch (_) {
      // Beberapa Android tidak mengizinkan akses langsung ke Downloads.
    }

    final appDocuments = await getApplicationDocumentsDirectory();
    candidates.add(Directory(join(appDocuments.path, 'Arisan WK', 'Backup Database')));

    for (final directory in candidates) {
      try {
        await directory.create(recursive: true);
        final probe = File(join(directory.path, '.write_test'));
        await probe.writeAsString('ok', flush: true);
        if (await probe.exists()) await probe.delete();
        return directory;
      } catch (_) {
        continue;
      }
    }

    throw Exception('Tidak bisa menemukan folder backup yang dapat ditulis.');
  }
}
