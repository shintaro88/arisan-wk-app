import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../../models/anggota_model.dart';
import '../../models/kas_model.dart';
import '../../models/pembayaran_model.dart';
import '../../models/pemenang_model.dart';
import '../../models/pengaturan_model.dart';
import '../../models/periode_model.dart';

class DatabaseHelper {
  DatabaseHelper._internal();
  static final DatabaseHelper instance = DatabaseHelper._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'arisan_wk.db');

    return openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE anggota (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL,
        no_hp TEXT,
        alamat TEXT,
        wilayah TEXT,
        status TEXT NOT NULL,
        tanggal_bergabung TEXT,
        catatan TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE periode_arisan (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama_periode TEXT NOT NULL,
        tanggal_arisan TEXT,
        lokasi TEXT,
        nominal_iuran REAL NOT NULL,
        status TEXT NOT NULL,
        catatan TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE pembayaran_iuran (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_anggota INTEGER NOT NULL,
        id_periode INTEGER NOT NULL,
        nominal_iuran REAL NOT NULL,
        nominal_bayar REAL NOT NULL,
        tanggal_bayar TEXT,
        metode_bayar TEXT,
        status_bayar TEXT,
        catatan TEXT,
        UNIQUE(id_anggota, id_periode),
        FOREIGN KEY(id_anggota) REFERENCES anggota(id),
        FOREIGN KEY(id_periode) REFERENCES periode_arisan(id)
      )
    ''');

    await db.execute('''
      CREATE TABLE pemenang_arisan (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_periode INTEGER NOT NULL,
        id_anggota INTEGER NOT NULL,
        tanggal_menang TEXT,
        nominal_diterima REAL NOT NULL,
        status_penerimaan TEXT,
        catatan TEXT,
        FOREIGN KEY(id_anggota) REFERENCES anggota(id),
        FOREIGN KEY(id_periode) REFERENCES periode_arisan(id)
      )
    ''');

    await db.execute('''
      CREATE TABLE kas_transaksi (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tanggal_transaksi TEXT,
        jenis_transaksi TEXT NOT NULL,
        kategori TEXT,
        nominal REAL NOT NULL,
        keterangan TEXT NOT NULL,
        penanggung_jawab TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE pengaturan (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama_organisasi TEXT,
        nama_ketua TEXT,
        nama_bendahara TEXT,
        nama_sekretaris TEXT,
        default_iuran_arisan REAL,
        default_iuran_kas REAL
      )
    ''');

    await db.insert('pengaturan', const Pengaturan(
      namaOrganisasi: 'Wanita Katolik',
      namaKetua: '',
      namaBendahara: '',
      namaSekretaris: '',
      defaultIuranArisan: 50000,
      defaultIuranKas: 10000,
    ).toMap());

    await db.insert('anggota', const Anggota(
      nama: 'Maria Contoh',
      noHp: '081234567890',
      alamat: 'Contoh alamat',
      wilayah: 'Lingkungan 1',
      status: 'Aktif',
      tanggalBergabung: '2026-01-01',
      catatan: 'Data dummy awal',
    ).toMap());

    await db.insert('periode_arisan', const PeriodeArisan(
      namaPeriode: 'Arisan Mei 2026',
      tanggalArisan: '2026-05-31',
      lokasi: 'Aula Paroki',
      nominalIuran: 50000,
      status: 'Aktif',
      catatan: 'Periode contoh',
    ).toMap());
  }

  Future<int> insertAnggota(Anggota anggota) async {
    final db = await database;
    return db.insert('anggota', anggota.toMap());
  }

  Future<int> updateAnggota(Anggota anggota) async {
    final db = await database;
    return db.update('anggota', anggota.toMap(), where: 'id = ?', whereArgs: [anggota.id]);
  }

  Future<int> deleteAnggota(int id) async {
    final db = await database;
    return db.delete('anggota', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Anggota>> getAnggota({String keyword = '', String status = 'Semua'}) async {
    final db = await database;
    final where = <String>[];
    final args = <Object>[];

    if (keyword.isNotEmpty) {
      where.add('nama LIKE ?');
      args.add('%$keyword%');
    }
    if (status != 'Semua') {
      where.add('status = ?');
      args.add(status);
    }

    final maps = await db.query(
      'anggota',
      where: where.isEmpty ? null : where.join(' AND '),
      whereArgs: args,
      orderBy: 'nama ASC',
    );
    return maps.map(Anggota.fromMap).toList();
  }

  Future<int> countAnggota(String status) async {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) AS total FROM anggota WHERE status = ?', [status]);
    return Sqflite.firstIntValue(result) ?? 0;
  }

  Future<int> insertPeriode(PeriodeArisan periode) async {
    final db = await database;
    return db.insert('periode_arisan', periode.toMap());
  }

  Future<int> updatePeriode(PeriodeArisan periode) async {
    final db = await database;
    return db.update('periode_arisan', periode.toMap(), where: 'id = ?', whereArgs: [periode.id]);
  }

  Future<int> deletePeriode(int id) async {
    final db = await database;
    return db.delete('periode_arisan', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<PeriodeArisan>> getPeriode() async {
    final db = await database;
    final maps = await db.query('periode_arisan', orderBy: 'id DESC');
    return maps.map(PeriodeArisan.fromMap).toList();
  }

  Future<PeriodeArisan?> getPeriodeAktif() async {
    final db = await database;
    final maps = await db.query('periode_arisan', where: 'status = ?', whereArgs: ['Aktif'], limit: 1, orderBy: 'id DESC');
    if (maps.isEmpty) return null;
    return PeriodeArisan.fromMap(maps.first);
  }

  Future<int> insertPembayaran(PembayaranIuran pembayaran) async {
    final db = await database;
    return db.insert('pembayaran_iuran', pembayaran.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<int> deletePembayaran(int id) async {
    final db = await database;
    return db.delete('pembayaran_iuran', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Map<String, dynamic>>> getPembayaranDetail(int idPeriode) async {
    final db = await database;
    return db.rawQuery('''
      SELECT p.*, a.nama, a.no_hp, a.wilayah
      FROM pembayaran_iuran p
      JOIN anggota a ON a.id = p.id_anggota
      WHERE p.id_periode = ?
      ORDER BY a.nama ASC
    ''', [idPeriode]);
  }

  Future<int> countPembayaranStatus(int idPeriode, String status) async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT COUNT(*) AS total FROM pembayaran_iuran
      WHERE id_periode = ? AND status_bayar = ?
    ''', [idPeriode, status]);
    return Sqflite.firstIntValue(result) ?? 0;
  }

  Future<double> totalIuranPeriode(int idPeriode) async {
    final db = await database;
    final result = await db.rawQuery('SELECT SUM(nominal_bayar) AS total FROM pembayaran_iuran WHERE id_periode = ?', [idPeriode]);
    final value = result.first['total'];
    return (value as num?)?.toDouble() ?? 0;
  }

  Future<int> insertPemenang(PemenangArisan pemenang) async {
    final db = await database;
    return db.insert('pemenang_arisan', pemenang.toMap());
  }

  Future<int> deletePemenang(int id) async {
    final db = await database;
    return db.delete('pemenang_arisan', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Map<String, dynamic>>> getPemenangDetail() async {
    final db = await database;
    return db.rawQuery('''
      SELECT pm.*, a.nama, pr.nama_periode
      FROM pemenang_arisan pm
      JOIN anggota a ON a.id = pm.id_anggota
      JOIN periode_arisan pr ON pr.id = pm.id_periode
      ORDER BY pm.id DESC
    ''');
  }

  Future<Map<String, dynamic>?> getPemenangTerakhir() async {
    final db = await database;
    final maps = await db.rawQuery('''
      SELECT pm.*, a.nama, pr.nama_periode
      FROM pemenang_arisan pm
      JOIN anggota a ON a.id = pm.id_anggota
      JOIN periode_arisan pr ON pr.id = pm.id_periode
      ORDER BY pm.id DESC
      LIMIT 1
    ''');
    if (maps.isEmpty) return null;
    return maps.first;
  }

  Future<int> insertKas(KasTransaksi kas) async {
    final db = await database;
    return db.insert('kas_transaksi', kas.toMap());
  }

  Future<int> updateKas(KasTransaksi kas) async {
    final db = await database;
    return db.update('kas_transaksi', kas.toMap(), where: 'id = ?', whereArgs: [kas.id]);
  }

  Future<int> deleteKas(int id) async {
    final db = await database;
    return db.delete('kas_transaksi', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<KasTransaksi>> getKas() async {
    final db = await database;
    final maps = await db.query('kas_transaksi', orderBy: 'tanggal_transaksi DESC, id DESC');
    return maps.map(KasTransaksi.fromMap).toList();
  }

  Future<double> getSaldoKas() async {
    final db = await database;
    final pemasukan = await db.rawQuery("SELECT SUM(nominal) AS total FROM kas_transaksi WHERE jenis_transaksi = 'Pemasukan'");
    final pengeluaran = await db.rawQuery("SELECT SUM(nominal) AS total FROM kas_transaksi WHERE jenis_transaksi = 'Pengeluaran'");
    final totalMasuk = (pemasukan.first['total'] as num?)?.toDouble() ?? 0;
    final totalKeluar = (pengeluaran.first['total'] as num?)?.toDouble() ?? 0;
    return totalMasuk - totalKeluar;
  }

  Future<double> totalKasByJenis(String jenis) async {
    final db = await database;
    final result = await db.rawQuery('SELECT SUM(nominal) AS total FROM kas_transaksi WHERE jenis_transaksi = ?', [jenis]);
    return (result.first['total'] as num?)?.toDouble() ?? 0;
  }

  Future<Pengaturan> getPengaturan() async {
    final db = await database;
    final maps = await db.query('pengaturan', limit: 1);
    if (maps.isEmpty) {
      return const Pengaturan(
        namaOrganisasi: 'Wanita Katolik',
        namaKetua: '',
        namaBendahara: '',
        namaSekretaris: '',
        defaultIuranArisan: 50000,
        defaultIuranKas: 10000,
      );
    }
    return Pengaturan.fromMap(maps.first);
  }

  Future<int> updatePengaturan(Pengaturan pengaturan) async {
    final db = await database;
    if (pengaturan.id == null) return db.insert('pengaturan', pengaturan.toMap());
    return db.update('pengaturan', pengaturan.toMap(), where: 'id = ?', whereArgs: [pengaturan.id]);
  }
}
