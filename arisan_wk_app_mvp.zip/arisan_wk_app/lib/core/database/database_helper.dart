import 'dart:io';

import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../../services/download_storage_service.dart';

import '../../models/anggota_model.dart';
import '../../models/kas_model.dart';
import '../../models/pembayaran_model.dart';
import '../../models/pemenang_model.dart';
import '../../models/pengaturan_model.dart';
import '../../models/periode_model.dart';

class DatabaseHelper {
  DatabaseHelper._internal();
  static final DatabaseHelper instance = DatabaseHelper._internal();

  static Database? _database;
  static const String _dbName = 'arisan_wk.db';
  static const int _dbVersion = 20;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<String> get databasePath async {
    final dbPath = await getDatabasesPath();
    return join(dbPath, _dbName);
  }

  Future<Database> _initDatabase() async {
    final path = await databasePath;

    return openDatabase(
      path,
      version: _dbVersion,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
      onOpen: (db) async {
        // Tetap jalankan pengecekan schema setiap app dibuka.
        // Ini membuat update APK / restore backup lama tetap aman walaupun version DB berbeda.
        await _ensureSchema(db);
      },
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE anggota (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL,
        no_hp TEXT,
        alamat TEXT,
        wilayah TEXT,
        status TEXT NOT NULL,
        tanggal_bergabung TEXT,
        catatan TEXT,
        ikut_arisan INTEGER NOT NULL DEFAULT 1,
        ikut_kas INTEGER NOT NULL DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE periode_arisan (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama_periode TEXT NOT NULL,
        tanggal_arisan TEXT,
        lokasi TEXT,
        nominal_iuran REAL NOT NULL,
        status TEXT NOT NULL,
        catatan TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE pembayaran_iuran (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_anggota INTEGER NOT NULL,
        id_periode INTEGER NOT NULL,
        nominal_iuran REAL NOT NULL,
        nominal_bayar REAL NOT NULL,
        tanggal_bayar TEXT,
        metode_bayar TEXT,
        status_bayar TEXT,
        catatan TEXT,
        sumber_bayar TEXT DEFAULT 'Pribadi',
        status_talangan TEXT DEFAULT 'Tidak Ada',
        tanggal_pelunasan_talangan TEXT DEFAULT '',
        UNIQUE(id_anggota, id_periode),
        FOREIGN KEY(id_anggota) REFERENCES anggota(id),
        FOREIGN KEY(id_periode) REFERENCES periode_arisan(id)
      )
    ''');

    await db.execute('''
      CREATE TABLE pemenang_arisan (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_periode INTEGER NOT NULL,
        id_anggota INTEGER NOT NULL,
        tanggal_menang TEXT,
        nominal_diterima REAL NOT NULL,
        status_penerimaan TEXT,
        catatan TEXT,
        FOREIGN KEY(id_anggota) REFERENCES anggota(id),
        FOREIGN KEY(id_periode) REFERENCES periode_arisan(id)
      )
    ''');

    await db.execute('''
      CREATE TABLE kas_transaksi (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tanggal_transaksi TEXT,
        jenis_transaksi TEXT NOT NULL,
        kategori TEXT,
        nominal REAL NOT NULL,
        keterangan TEXT NOT NULL,
        penanggung_jawab TEXT,
        id_anggota INTEGER,
        referensi TEXT DEFAULT '',
        FOREIGN KEY(id_anggota) REFERENCES anggota(id)
      )
    ''');

    await db.execute('''
      CREATE TABLE pembayaran_kas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_anggota INTEGER NOT NULL,
        bulan TEXT NOT NULL,
        nominal_bayar REAL NOT NULL,
        tanggal_bayar TEXT,
        status_bayar TEXT DEFAULT 'Sudah Bayar',
        catatan TEXT DEFAULT '',
        UNIQUE(id_anggota, bulan),
        FOREIGN KEY(id_anggota) REFERENCES anggota(id)
      )
    ''');

    await db.execute('''
      CREATE TABLE pengaturan (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama_organisasi TEXT,
        nama_ketua TEXT,
        nama_bendahara TEXT,
        nama_sekretaris TEXT,
        default_iuran_arisan REAL,
        default_iuran_kas REAL
      )
    ''');

    await db.insert('pengaturan', const Pengaturan(
      namaOrganisasi: 'Wanita Katolik',
      namaKetua: '',
      namaBendahara: '',
      namaSekretaris: '',
      defaultIuranArisan: 50000,
      defaultIuranKas: 10000,
    ).toMap());

    await db.insert('anggota', const Anggota(
      nama: 'Maria Contoh',
      noHp: '081234567890',
      alamat: 'Contoh alamat',
      wilayah: 'Lingkungan 1',
      status: 'Aktif',
      tanggalBergabung: '2026-01-01',
      catatan: 'Data dummy awal',
      ikutArisan: true,
      ikutKas: true,
    ).toMap());

    await db.insert('periode_arisan', const PeriodeArisan(
      namaPeriode: 'Arisan Mei 2026',
      tanggalArisan: '2026-05-31',
      lokasi: 'Aula Paroki',
      nominalIuran: 50000,
      status: 'Aktif',
      catatan: 'Periode contoh',
    ).toMap());
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    await _ensureSchema(db);
  }

  Future<void> restructureDatabase() async {
    final db = await database;
    await _ensureSchema(db);
  }

  Future<bool> _tableExists(DatabaseExecutor db, String table) async {
    final result = await db.rawQuery(
      "SELECT name FROM sqlite_master WHERE type = 'table' AND name = ?",
      [table],
    );
    return result.isNotEmpty;
  }

  Future<void> _createCoreTablesIfMissing(DatabaseExecutor db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS anggota (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL DEFAULT '',
        no_hp TEXT DEFAULT '',
        alamat TEXT DEFAULT '',
        wilayah TEXT DEFAULT '',
        status TEXT NOT NULL DEFAULT 'Aktif',
        tanggal_bergabung TEXT DEFAULT '',
        catatan TEXT DEFAULT '',
        ikut_arisan INTEGER NOT NULL DEFAULT 1,
        ikut_kas INTEGER NOT NULL DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS periode_arisan (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama_periode TEXT NOT NULL DEFAULT '',
        tanggal_arisan TEXT DEFAULT '',
        lokasi TEXT DEFAULT '',
        nominal_iuran REAL NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'Aktif',
        catatan TEXT DEFAULT ''
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS pembayaran_iuran (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_anggota INTEGER NOT NULL DEFAULT 0,
        id_periode INTEGER NOT NULL DEFAULT 0,
        nominal_iuran REAL NOT NULL DEFAULT 0,
        nominal_bayar REAL NOT NULL DEFAULT 0,
        tanggal_bayar TEXT DEFAULT '',
        metode_bayar TEXT DEFAULT 'Tunai',
        status_bayar TEXT DEFAULT 'Belum Bayar',
        catatan TEXT DEFAULT '',
        sumber_bayar TEXT DEFAULT 'Pribadi',
        status_talangan TEXT DEFAULT 'Tidak Ada',
        tanggal_pelunasan_talangan TEXT DEFAULT ''
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS pemenang_arisan (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_periode INTEGER NOT NULL DEFAULT 0,
        id_anggota INTEGER NOT NULL DEFAULT 0,
        tanggal_menang TEXT DEFAULT '',
        nominal_diterima REAL NOT NULL DEFAULT 0,
        status_penerimaan TEXT DEFAULT 'Belum Diterima',
        catatan TEXT DEFAULT ''
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS kas_transaksi (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tanggal_transaksi TEXT DEFAULT '',
        jenis_transaksi TEXT NOT NULL DEFAULT 'Pemasukan',
        kategori TEXT DEFAULT '',
        nominal REAL NOT NULL DEFAULT 0,
        keterangan TEXT NOT NULL DEFAULT '',
        penanggung_jawab TEXT DEFAULT '',
        id_anggota INTEGER,
        referensi TEXT DEFAULT ''
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS pembayaran_kas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_anggota INTEGER NOT NULL DEFAULT 0,
        bulan TEXT NOT NULL DEFAULT '',
        nominal_bayar REAL NOT NULL DEFAULT 0,
        tanggal_bayar TEXT DEFAULT '',
        status_bayar TEXT DEFAULT 'Sudah Bayar',
        catatan TEXT DEFAULT ''
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS pengaturan (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama_organisasi TEXT DEFAULT 'Wanita Katolik',
        nama_ketua TEXT DEFAULT '',
        nama_bendahara TEXT DEFAULT '',
        nama_sekretaris TEXT DEFAULT '',
        default_iuran_arisan REAL DEFAULT 50000,
        default_iuran_kas REAL DEFAULT 10000
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS app_database_meta (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        schema_version INTEGER NOT NULL DEFAULT 0,
        last_restructure_at TEXT DEFAULT ''
      )
    ''');
  }

  Future<void> _addColumnIfMissing(DatabaseExecutor db, String table, String column, String definition) async {
    final tableExists = await _tableExists(db, table);
    if (!tableExists) return;
    final info = await db.rawQuery('PRAGMA table_info($table)');
    final exists = info.any((row) => row['name'] == column);
    if (!exists) {
      await db.execute('ALTER TABLE $table ADD COLUMN $column $definition');
    }
  }

  Future<void> _seedDefaultPengaturanIfMissing(DatabaseExecutor db) async {
    final result = await db.rawQuery('SELECT COUNT(*) AS total FROM pengaturan');
    final total = Sqflite.firstIntValue(result) ?? 0;
    if (total == 0) {
      await db.insert('pengaturan', const Pengaturan(
        namaOrganisasi: 'Wanita Katolik',
        namaKetua: '',
        namaBendahara: '',
        namaSekretaris: '',
        defaultIuranArisan: 50000,
        defaultIuranKas: 10000,
      ).toMap());
    }
  }

  Future<void> _writeSchemaMeta(DatabaseExecutor db) async {
    final now = DateTime.now().toIso8601String();
    await db.insert(
      'app_database_meta',
      {'id': 1, 'schema_version': _dbVersion, 'last_restructure_at': now},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> _ensureSchema(Database db) async {
    // Prinsip migrasi:
    // 1. Jangan drop table agar data lama tidak hilang.
    // 2. Buat table yang belum ada.
    // 3. Tambahkan kolom baru dengan DEFAULT agar backup versi lama tetap bisa dibuka.
    // 4. Jalankan juga dari menu Restruktur Database untuk menyesuaikan schema setelah update app.
    await db.transaction((txn) async {
      await _createCoreTablesIfMissing(txn);

      await _addColumnIfMissing(txn, 'anggota', 'nama', "TEXT NOT NULL DEFAULT ''");
      await _addColumnIfMissing(txn, 'anggota', 'no_hp', "TEXT DEFAULT ''");
      await _addColumnIfMissing(txn, 'anggota', 'alamat', "TEXT DEFAULT ''");
      await _addColumnIfMissing(txn, 'anggota', 'wilayah', "TEXT DEFAULT ''");
      await _addColumnIfMissing(txn, 'anggota', 'status', "TEXT NOT NULL DEFAULT 'Aktif'");
      await _addColumnIfMissing(txn, 'anggota', 'tanggal_bergabung', "TEXT DEFAULT ''");
      await _addColumnIfMissing(txn, 'anggota', 'catatan', "TEXT DEFAULT ''");
      await _addColumnIfMissing(txn, 'anggota', 'ikut_arisan', 'INTEGER NOT NULL DEFAULT 1');
      await _addColumnIfMissing(txn, 'anggota', 'ikut_kas', 'INTEGER NOT NULL DEFAULT 1');

      await _addColumnIfMissing(txn, 'periode_arisan', 'nama_periode', "TEXT NOT NULL DEFAULT ''");
      await _addColumnIfMissing(txn, 'periode_arisan', 'tanggal_arisan', "TEXT DEFAULT ''");
      await _addColumnIfMissing(txn, 'periode_arisan', 'lokasi', "TEXT DEFAULT ''");
      await _addColumnIfMissing(txn, 'periode_arisan', 'nominal_iuran', 'REAL NOT NULL DEFAULT 0');
      await _addColumnIfMissing(txn, 'periode_arisan', 'status', "TEXT NOT NULL DEFAULT 'Aktif'");
      await _addColumnIfMissing(txn, 'periode_arisan', 'catatan', "TEXT DEFAULT ''");

      await _addColumnIfMissing(txn, 'pembayaran_iuran', 'id_anggota', 'INTEGER NOT NULL DEFAULT 0');
      await _addColumnIfMissing(txn, 'pembayaran_iuran', 'id_periode', 'INTEGER NOT NULL DEFAULT 0');
      await _addColumnIfMissing(txn, 'pembayaran_iuran', 'nominal_iuran', 'REAL NOT NULL DEFAULT 0');
      await _addColumnIfMissing(txn, 'pembayaran_iuran', 'nominal_bayar', 'REAL NOT NULL DEFAULT 0');
      await _addColumnIfMissing(txn, 'pembayaran_iuran', 'tanggal_bayar', "TEXT DEFAULT ''");
      await _addColumnIfMissing(txn, 'pembayaran_iuran', 'metode_bayar', "TEXT DEFAULT 'Tunai'");
      await _addColumnIfMissing(txn, 'pembayaran_iuran', 'status_bayar', "TEXT DEFAULT 'Belum Bayar'");
      await _addColumnIfMissing(txn, 'pembayaran_iuran', 'catatan', "TEXT DEFAULT ''");
      await _addColumnIfMissing(txn, 'pembayaran_iuran', 'sumber_bayar', "TEXT DEFAULT 'Pribadi'");
      await _addColumnIfMissing(txn, 'pembayaran_iuran', 'status_talangan', "TEXT DEFAULT 'Tidak Ada'");
      await _addColumnIfMissing(txn, 'pembayaran_iuran', 'tanggal_pelunasan_talangan', "TEXT DEFAULT ''");

      await _addColumnIfMissing(txn, 'pemenang_arisan', 'id_periode', 'INTEGER NOT NULL DEFAULT 0');
      await _addColumnIfMissing(txn, 'pemenang_arisan', 'id_anggota', 'INTEGER NOT NULL DEFAULT 0');
      await _addColumnIfMissing(txn, 'pemenang_arisan', 'tanggal_menang', "TEXT DEFAULT ''");
      await _addColumnIfMissing(txn, 'pemenang_arisan', 'nominal_diterima', 'REAL NOT NULL DEFAULT 0');
      await _addColumnIfMissing(txn, 'pemenang_arisan', 'status_penerimaan', "TEXT DEFAULT 'Belum Diterima'");
      await _addColumnIfMissing(txn, 'pemenang_arisan', 'catatan', "TEXT DEFAULT ''");

      await _addColumnIfMissing(txn, 'kas_transaksi', 'tanggal_transaksi', "TEXT DEFAULT ''");
      await _addColumnIfMissing(txn, 'kas_transaksi', 'jenis_transaksi', "TEXT NOT NULL DEFAULT 'Pemasukan'");
      await _addColumnIfMissing(txn, 'kas_transaksi', 'kategori', "TEXT DEFAULT ''");
      await _addColumnIfMissing(txn, 'kas_transaksi', 'nominal', 'REAL NOT NULL DEFAULT 0');
      await _addColumnIfMissing(txn, 'kas_transaksi', 'keterangan', "TEXT NOT NULL DEFAULT ''");
      await _addColumnIfMissing(txn, 'kas_transaksi', 'penanggung_jawab', "TEXT DEFAULT ''");
      await _addColumnIfMissing(txn, 'kas_transaksi', 'id_anggota', 'INTEGER');
      await _addColumnIfMissing(txn, 'kas_transaksi', 'referensi', "TEXT DEFAULT ''");

      await _addColumnIfMissing(txn, 'pembayaran_kas', 'id_anggota', 'INTEGER NOT NULL DEFAULT 0');
      await _addColumnIfMissing(txn, 'pembayaran_kas', 'bulan', "TEXT NOT NULL DEFAULT ''");
      await _addColumnIfMissing(txn, 'pembayaran_kas', 'nominal_bayar', 'REAL NOT NULL DEFAULT 0');
      await _addColumnIfMissing(txn, 'pembayaran_kas', 'tanggal_bayar', "TEXT DEFAULT ''");
      await _addColumnIfMissing(txn, 'pembayaran_kas', 'status_bayar', "TEXT DEFAULT 'Sudah Bayar'");
      await _addColumnIfMissing(txn, 'pembayaran_kas', 'catatan', "TEXT DEFAULT ''");

      await _addColumnIfMissing(txn, 'pengaturan', 'nama_organisasi', "TEXT DEFAULT 'Wanita Katolik'");
      await _addColumnIfMissing(txn, 'pengaturan', 'nama_ketua', "TEXT DEFAULT ''");
      await _addColumnIfMissing(txn, 'pengaturan', 'nama_bendahara', "TEXT DEFAULT ''");
      await _addColumnIfMissing(txn, 'pengaturan', 'nama_sekretaris', "TEXT DEFAULT ''");
      await _addColumnIfMissing(txn, 'pengaturan', 'default_iuran_arisan', 'REAL DEFAULT 50000');
      await _addColumnIfMissing(txn, 'pengaturan', 'default_iuran_kas', 'REAL DEFAULT 10000');

      await _seedDefaultPengaturanIfMissing(txn);
      await _writeSchemaMeta(txn);
    });

    await db.execute('PRAGMA user_version = $_dbVersion');
  }

  Future<bool> existsAnggotaNama(String nama, {int? exceptId}) async {
    final db = await database;
    final normalizedName = nama.trim();
    if (normalizedName.isEmpty) return false;

    final where = <String>['LOWER(TRIM(nama)) = LOWER(TRIM(?))'];
    final args = <Object>[normalizedName];
    if (exceptId != null) {
      where.add('id != ?');
      args.add(exceptId);
    }

    final result = await db.rawQuery(
      'SELECT COUNT(*) AS total FROM anggota WHERE ${where.join(' AND ')}',
      args,
    );
    return (Sqflite.firstIntValue(result) ?? 0) > 0;
  }

  Future<int> insertAnggota(Anggota anggota) async {
    final db = await database;
    if (await existsAnggotaNama(anggota.nama)) {
      throw Exception('Nama anggota sudah terdaftar. Gunakan nama berbeda agar data tidak duplikat.');
    }
    return db.insert('anggota', anggota.toMap());
  }

  Future<int> updateAnggota(Anggota anggota) async {
    final db = await database;
    if (await existsAnggotaNama(anggota.nama, exceptId: anggota.id)) {
      throw Exception('Nama anggota sudah terdaftar. Gunakan nama berbeda agar data tidak duplikat.');
    }
    return db.update('anggota', anggota.toMap(), where: 'id = ?', whereArgs: [anggota.id]);
  }

  Future<int> deleteAnggota(int id) async {
    final db = await database;
    return db.delete('anggota', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Anggota>> getAnggota({String keyword = '', String status = 'Semua'}) async {
    final db = await database;
    final where = <String>[];
    final args = <Object>[];

    if (keyword.isNotEmpty) {
      where.add('nama LIKE ?');
      args.add('%$keyword%');
    }
    if (status != 'Semua') {
      where.add('status = ?');
      args.add(status);
    }

    final maps = await db.query(
      'anggota',
      where: where.isEmpty ? null : where.join(' AND '),
      whereArgs: args,
      orderBy: 'nama ASC',
    );
    return maps.map(Anggota.fromMap).toList();
  }

  Future<int> countAnggota(String status) async {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) AS total FROM anggota WHERE status = ?', [status]);
    return Sqflite.firstIntValue(result) ?? 0;
  }


  Future<int> countAnggotaIkut({required String jenis}) async {
    final db = await database;
    final column = jenis == 'kas' ? 'ikut_kas' : 'ikut_arisan';
    final result = await db.rawQuery("SELECT COUNT(*) AS total FROM anggota WHERE status = 'Aktif' AND $column = 1");
    return Sqflite.firstIntValue(result) ?? 0;
  }

  Future<List<Anggota>> getAnggotaIkutKas() async {
    final db = await database;
    final maps = await db.query('anggota', where: 'status = ? AND ikut_kas = 1', whereArgs: ['Aktif'], orderBy: 'nama ASC');
    return maps.map(Anggota.fromMap).toList();
  }

  Future<List<Anggota>> getAnggotaIkutArisan() async {
    final db = await database;
    final maps = await db.query('anggota', where: 'status = ? AND ikut_arisan = 1', whereArgs: ['Aktif'], orderBy: 'nama ASC');
    return maps.map(Anggota.fromMap).toList();
  }

  Future<int> insertPeriode(PeriodeArisan periode) async {
    final db = await database;
    return db.insert('periode_arisan', periode.toMap());
  }

  Future<int> updatePeriode(PeriodeArisan periode) async {
    final db = await database;
    return db.update('periode_arisan', periode.toMap(), where: 'id = ?', whereArgs: [periode.id]);
  }

  Future<int> deletePeriode(int id) async {
    final db = await database;
    return db.delete('periode_arisan', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<PeriodeArisan>> getPeriode() async {
    final db = await database;
    final maps = await db.query('periode_arisan', orderBy: 'id DESC');
    return maps.map(PeriodeArisan.fromMap).toList();
  }

  Future<PeriodeArisan?> getPeriodeAktif() async {
    final db = await database;
    final maps = await db.query('periode_arisan', where: 'status = ?', whereArgs: ['Aktif'], limit: 1, orderBy: 'id DESC');
    if (maps.isEmpty) return null;
    return PeriodeArisan.fromMap(maps.first);
  }

  Future<bool> existsPembayaran(int idAnggota, int idPeriode) async {
    final db = await database;
    final result = await db.rawQuery(
      'SELECT COUNT(*) AS total FROM pembayaran_iuran WHERE id_anggota = ? AND id_periode = ?',
      [idAnggota, idPeriode],
    );
    return (Sqflite.firstIntValue(result) ?? 0) > 0;
  }

  Future<int> insertPembayaran(PembayaranIuran pembayaran) async {
    final db = await database;
    final exists = await existsPembayaran(pembayaran.idAnggota, pembayaran.idPeriode);
    if (exists) {
      throw Exception('Anggota ini sudah tercatat membayar pada periode yang sama. Data tidak disimpan agar tidak duplikat.');
    }
    return db.insert('pembayaran_iuran', pembayaran.toMap(), conflictAlgorithm: ConflictAlgorithm.abort);
  }


  Future<int> insertTalanganKasForPeriode({
    required int idPeriode,
    required String namaPeriode,
    required String tanggal,
    required double nominal,
    required int jumlahAnggota,
    required String catatan,
  }) async {
    final kas = KasTransaksi(
      tanggalTransaksi: tanggal,
      jenisTransaksi: 'Pengeluaran',
      kategori: 'Talangan Arisan',
      nominal: nominal,
      keterangan: 'Talangan iuran arisan $namaPeriode (ID Periode: $idPeriode) untuk $jumlahAnggota anggota. $catatan'.trim(),
      penanggungJawab: 'Bendahara',
      idAnggota: null,
    );
    final db = await database;
    return db.insert('kas_transaksi', kas.toMap());
  }


  Future<int> tandaiTalanganSudahDiganti(int pembayaranId) async {
    final db = await database;
    return db.update(
      'pembayaran_iuran',
      {
        'status_talangan': 'Sudah Diganti',
        'tanggal_pelunasan_talangan': DateTime.now().toIso8601String().substring(0, 10),
      },
      where: 'id = ?',
      whereArgs: [pembayaranId],
    );
  }

  Future<int> deletePembayaran(int id) async {
    final db = await database;
    return db.delete('pembayaran_iuran', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Map<String, dynamic>>> getPembayaranDetail(int idPeriode) async {
    final db = await database;
    return db.rawQuery('''
      SELECT p.*, a.nama, a.no_hp, a.wilayah
      FROM pembayaran_iuran p
      JOIN anggota a ON a.id = p.id_anggota
      WHERE p.id_periode = ?
      ORDER BY a.nama ASC
    ''', [idPeriode]);
  }


  Future<List<Map<String, dynamic>>> getSemuaPembayaranBukti() async {
    final db = await database;
    return db.rawQuery('''
      SELECT p.*, a.nama, a.no_hp, a.wilayah, pr.nama_periode, 'Arisan' AS jenis_bukti
      FROM pembayaran_iuran p
      JOIN anggota a ON a.id = p.id_anggota
      JOIN periode_arisan pr ON pr.id = p.id_periode
      ORDER BY p.tanggal_bayar DESC, p.id DESC
    ''');
  }

  Future<List<Map<String, dynamic>>> getSemuaBuktiIuran() async {
    final db = await database;
    final arisan = await db.rawQuery('''
      SELECT p.*, a.nama, a.no_hp, a.wilayah, pr.nama_periode, 'Arisan' AS jenis_bukti
      FROM pembayaran_iuran p
      JOIN anggota a ON a.id = p.id_anggota
      JOIN periode_arisan pr ON pr.id = p.id_periode
    ''');
    final kas = await db.rawQuery('''
      SELECT
        k.id,
        0 AS id_anggota,
        0 AS id_periode,
        k.nominal AS nominal_iuran,
        k.nominal AS nominal_bayar,
        k.tanggal_transaksi AS tanggal_bayar,
        'Kolektif' AS metode_bayar,
        'Sudah Bayar' AS status_bayar,
        k.keterangan AS catatan,
        'Kas' AS sumber_bayar,
        'Tidak Ada' AS status_talangan,
        '' AS tanggal_pelunasan_talangan,
        'Kolektif Anggota WK' AS nama,
        '' AS no_hp,
        '' AS wilayah,
        substr(k.tanggal_transaksi, 1, 7) AS nama_periode,
        'Kas' AS jenis_bukti
      FROM kas_transaksi k
      WHERE k.jenis_transaksi = 'Pemasukan' AND k.kategori = 'Iuran Kas'
    ''');
    final merged = <Map<String, dynamic>>[...arisan, ...kas];
    merged.sort((a, b) {
      final ad = (a['tanggal_bayar'] ?? '').toString();
      final bd = (b['tanggal_bayar'] ?? '').toString();
      final dateCompare = bd.compareTo(ad);
      if (dateCompare != 0) return dateCompare;
      return ((b['id'] as num?)?.toInt() ?? 0).compareTo(((a['id'] as num?)?.toInt() ?? 0));
    });
    return merged;
  }

  Future<List<Anggota>> getAnggotaBelumBayar(int idPeriode) async {
    final db = await database;
    final maps = await db.rawQuery('''
      SELECT a.*
      FROM anggota a
      WHERE a.status = 'Aktif'
        AND COALESCE(a.ikut_arisan, 1) = 1
        AND NOT EXISTS (
          SELECT 1 FROM pembayaran_iuran p
          WHERE p.id_anggota = a.id AND p.id_periode = ?
        )
      ORDER BY a.nama ASC
    ''', [idPeriode]);
    return maps.map(Anggota.fromMap).toList();
  }

  Future<List<Map<String, dynamic>>> getAnggotaBelumBayarDetail(int idPeriode) async {
    final db = await database;
    return db.rawQuery('''
      SELECT a.id, a.nama, a.no_hp, a.wilayah
      FROM anggota a
      WHERE a.status = 'Aktif'
        AND COALESCE(a.ikut_arisan, 1) = 1
        AND NOT EXISTS (
          SELECT 1 FROM pembayaran_iuran p
          WHERE p.id_anggota = a.id AND p.id_periode = ?
        )
      ORDER BY a.nama ASC
    ''', [idPeriode]);
  }

  Future<int> countPembayaranStatus(int idPeriode, String status) async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT COUNT(*) AS total FROM pembayaran_iuran
      WHERE id_periode = ? AND status_bayar = ?
    ''', [idPeriode, status]);
    return Sqflite.firstIntValue(result) ?? 0;
  }

  Future<double> totalIuranPeriode(int idPeriode) async {
    final db = await database;
    final result = await db.rawQuery('SELECT SUM(nominal_bayar) AS total FROM pembayaran_iuran WHERE id_periode = ?', [idPeriode]);
    final value = result.first['total'];
    return (value as num?)?.toDouble() ?? 0;
  }

  Future<double> totalPencairanPeriode(int idPeriode) async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT SUM(nominal_diterima) AS total
      FROM pemenang_arisan
      WHERE id_periode = ? AND status_penerimaan = 'Sudah Diterima'
    ''', [idPeriode]);
    return (result.first['total'] as num?)?.toDouble() ?? 0;
  }

  Future<List<Map<String, dynamic>>> getRingkasanArisan() async {
    final db = await database;
    return db.rawQuery('''
      SELECT
        pr.id,
        pr.nama_periode,
        pr.tanggal_arisan,
        pr.lokasi,
        pr.nominal_iuran,
        pr.status,
        COUNT(DISTINCT p.id_anggota) AS jumlah_peserta,
        COALESCE(SUM(p.nominal_bayar), 0) AS total_iuran,
        COALESCE((
          SELECT SUM(pm.nominal_diterima)
          FROM pemenang_arisan pm
          WHERE pm.id_periode = pr.id AND pm.status_penerimaan = 'Sudah Diterima'
        ), 0) AS total_pencairan,
        COALESCE((
          SELECT GROUP_CONCAT(a2.nama, ', ')
          FROM pemenang_arisan pm2
          JOIN anggota a2 ON a2.id = pm2.id_anggota
          WHERE pm2.id_periode = pr.id
        ), '') AS pemenang
      FROM periode_arisan pr
      LEFT JOIN pembayaran_iuran p ON p.id_periode = pr.id
      GROUP BY pr.id, pr.nama_periode, pr.tanggal_arisan, pr.lokasi, pr.nominal_iuran, pr.status
      ORDER BY pr.id DESC
    ''');
  }

  Future<int> insertPemenang(PemenangArisan pemenang) async {
    final db = await database;
    return db.insert('pemenang_arisan', pemenang.toMap());
  }

  Future<int> deletePemenang(int id) async {
    final db = await database;
    return db.delete('pemenang_arisan', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Map<String, dynamic>>> getPemenangDetail() async {
    final db = await database;
    return db.rawQuery('''
      SELECT pm.*, a.nama, pr.nama_periode
      FROM pemenang_arisan pm
      JOIN anggota a ON a.id = pm.id_anggota
      JOIN periode_arisan pr ON pr.id = pm.id_periode
      ORDER BY pm.id DESC
    ''');
  }

  Future<Map<String, dynamic>?> getPemenangTerakhir() async {
    final db = await database;
    final maps = await db.rawQuery('''
      SELECT pm.*, a.nama, pr.nama_periode
      FROM pemenang_arisan pm
      JOIN anggota a ON a.id = pm.id_anggota
      JOIN periode_arisan pr ON pr.id = pm.id_periode
      ORDER BY pm.id DESC
      LIMIT 1
    ''');
    if (maps.isEmpty) return null;
    return maps.first;
  }

  String _monthKey(String date) {
    if (date.length >= 7) return date.substring(0, 7);
    return date;
  }

  Future<bool> existsKasIuranBulanan({required String tanggal, int? ignoreId}) async {
    final db = await database;
    final args = <Object?>[_monthKey(tanggal)];
    var whereIgnore = '';
    if (ignoreId != null) {
      whereIgnore = ' AND id != ?';
      args.add(ignoreId);
    }
    final result = await db.rawQuery('''
      SELECT COUNT(*) AS total
      FROM kas_transaksi
      WHERE jenis_transaksi = 'Pemasukan'
        AND kategori = 'Iuran Kas'
        AND substr(tanggal_transaksi, 1, 7) = ?
        $whereIgnore
    ''', args);
    return (Sqflite.firstIntValue(result) ?? 0) > 0;
  }

  Future<double> totalIuranKasBulanan(String tanggal) async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT SUM(nominal) AS total
      FROM kas_transaksi
      WHERE jenis_transaksi = 'Pemasukan'
        AND kategori = 'Iuran Kas'
        AND substr(tanggal_transaksi, 1, 7) = ?
    ''', [_monthKey(tanggal)]);
    return (result.first['total'] as num?)?.toDouble() ?? 0;
  }

  Future<List<String>> getNamaAnggotaIkutKas() async {
    final anggota = await getAnggotaIkutKas();
    return anggota.map((a) => a.nama).toList();
  }

  Future<void> _validateKasDuplicate(KasTransaksi kas) async {
    if (kas.jenisTransaksi == 'Pemasukan' && kas.kategori == 'Iuran Kas') {
      final duplicate = await existsKasIuranBulanan(tanggal: kas.tanggalTransaksi, ignoreId: kas.id);
      if (duplicate) {
        throw Exception('Iuran kas untuk bulan yang sama sudah pernah dicatat. Data tidak disimpan agar tidak duplikat.');
      }
    }
  }

  Future<int> insertKas(KasTransaksi kas) async {
    final db = await database;
    await _validateKasDuplicate(kas);
    return db.insert('kas_transaksi', kas.toMap());
  }

  Future<int> updateKas(KasTransaksi kas) async {
    final db = await database;
    await _validateKasDuplicate(kas);
    return db.update('kas_transaksi', kas.toMap(), where: 'id = ?', whereArgs: [kas.id]);
  }

  Future<int> deleteKas(int id) async {
    final db = await database;
    return db.delete('kas_transaksi', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<KasTransaksi>> getKas() async {
    final db = await database;
    final maps = await db.query('kas_transaksi', orderBy: 'tanggal_transaksi DESC, id DESC');
    return maps.map(KasTransaksi.fromMap).toList();
  }


  Future<List<Map<String, dynamic>>> getPembayaranKasDetail(String tanggal) async {
    final db = await database;
    return db.rawQuery('''
      SELECT pk.*, a.nama, a.no_hp, a.wilayah
      FROM pembayaran_kas pk
      JOIN anggota a ON a.id = pk.id_anggota
      WHERE pk.bulan = ?
      ORDER BY a.nama ASC
    ''', [_monthKey(tanggal)]);
  }

  Future<List<Anggota>> getAnggotaBelumBayarKas(String tanggal) async {
    final db = await database;
    final maps = await db.rawQuery('''
      SELECT a.*
      FROM anggota a
      WHERE a.status = 'Aktif'
        AND COALESCE(a.ikut_kas, 1) = 1
        AND NOT EXISTS (
          SELECT 1 FROM pembayaran_kas pk
          WHERE pk.id_anggota = a.id AND pk.bulan = ?
        )
      ORDER BY a.nama ASC
    ''', [_monthKey(tanggal)]);
    return maps.map(Anggota.fromMap).toList();
  }

  Future<void> insertKasIuranBatch({
    required KasTransaksi kas,
    required List<int> anggotaIds,
    required double nominalPerOrang,
  }) async {
    final db = await database;
    if (anggotaIds.isEmpty) {
      throw Exception('Pilih minimal satu anggota yang membayar iuran kas.');
    }
    final bulan = _monthKey(kas.tanggalTransaksi);
    await db.transaction((txn) async {
      for (final idAnggota in anggotaIds) {
        final result = await txn.rawQuery(
          'SELECT COUNT(*) AS total FROM pembayaran_kas WHERE id_anggota = ? AND bulan = ?',
          [idAnggota, bulan],
        );
        if ((Sqflite.firstIntValue(result) ?? 0) > 0) {
          throw Exception('Ada anggota yang sudah tercatat membayar kas pada bulan $bulan. Data tidak disimpan agar tidak duplikat.');
        }
      }

      await txn.insert('kas_transaksi', kas.toMap());
      for (final idAnggota in anggotaIds) {
        await txn.insert('pembayaran_kas', {
          'id_anggota': idAnggota,
          'bulan': bulan,
          'nominal_bayar': nominalPerOrang,
          'tanggal_bayar': kas.tanggalTransaksi,
          'status_bayar': 'Sudah Bayar',
          'catatan': kas.keterangan,
        });
      }
    });
  }

  Future<List<Map<String, dynamic>>> getTalanganAktif() async {
    final db = await database;
    return db.rawQuery('''
      SELECT p.*, a.nama, a.no_hp, a.wilayah, pr.nama_periode
      FROM pembayaran_iuran p
      JOIN anggota a ON a.id = p.id_anggota
      JOIN periode_arisan pr ON pr.id = p.id_periode
      WHERE p.sumber_bayar = 'Ditalangi Kas WK'
        AND p.status_talangan = 'Masih Ditalangi'
      ORDER BY p.tanggal_bayar DESC, a.nama ASC
    ''');
  }

  Future<List<Map<String, dynamic>>> getTunggakanArisanDanKas() async {
    final db = await database;
    final rows = <Map<String, dynamic>>[];
    final periode = await getPeriode();
    for (final p in periode) {
      if (p.id == null) continue;
      final belum = await getAnggotaBelumBayarDetail(p.id!);
      for (final a in belum) {
        rows.add({
          'bulan': _monthKey(p.tanggalArisan),
          'jenis': 'Arisan',
          'periode': p.namaPeriode,
          'nama': a['nama'],
          'no_hp': a['no_hp'],
          'wilayah': a['wilayah'],
          'nominal': p.nominalIuran,
          'status': 'Belum Bayar',
        });
      }
    }

    final months = <String>{};
    for (final p in periode) {
      if (p.tanggalArisan.length >= 7) months.add(_monthKey(p.tanggalArisan));
    }
    for (final m in await db.rawQuery("SELECT DISTINCT bulan FROM pembayaran_kas WHERE bulan != ''")) {
      final bulan = (m['bulan'] ?? '').toString();
      if (bulan.isNotEmpty) months.add(bulan);
    }
    for (final m in await db.rawQuery("SELECT DISTINCT substr(tanggal_transaksi, 1, 7) AS bulan FROM kas_transaksi WHERE kategori = 'Iuran Kas' AND tanggal_transaksi != ''")) {
      final bulan = (m['bulan'] ?? '').toString();
      if (bulan.isNotEmpty) months.add(bulan);
    }
    months.add(_monthKey(DateTime.now().toIso8601String()));

    final pengaturan = await getPengaturan();
    for (final bulan in months) {
      final belumKas = await getAnggotaBelumBayarKas('$bulan-01');
      for (final a in belumKas) {
        rows.add({
          'bulan': bulan,
          'jenis': 'Kas',
          'periode': 'Kas $bulan',
          'nama': a.nama,
          'no_hp': a.noHp,
          'wilayah': a.wilayah,
          'nominal': pengaturan.defaultIuranKas,
          'status': 'Belum Bayar',
        });
      }
    }

    rows.sort((a, b) {
      final byMonth = (b['bulan'] ?? '').toString().compareTo((a['bulan'] ?? '').toString());
      if (byMonth != 0) return byMonth;
      final byType = (a['jenis'] ?? '').toString().compareTo((b['jenis'] ?? '').toString());
      if (byType != 0) return byType;
      return (a['nama'] ?? '').toString().compareTo((b['nama'] ?? '').toString());
    });
    return rows;
  }

  Future<double> getSaldoKas() async {
    final db = await database;
    final pemasukan = await db.rawQuery("SELECT SUM(nominal) AS total FROM kas_transaksi WHERE jenis_transaksi = 'Pemasukan'");
    final pengeluaran = await db.rawQuery("SELECT SUM(nominal) AS total FROM kas_transaksi WHERE jenis_transaksi = 'Pengeluaran'");
    final totalMasuk = (pemasukan.first['total'] as num?)?.toDouble() ?? 0;
    final totalKeluar = (pengeluaran.first['total'] as num?)?.toDouble() ?? 0;
    return totalMasuk - totalKeluar;
  }

  Future<double> totalKasByJenis(String jenis) async {
    final db = await database;
    final result = await db.rawQuery('SELECT SUM(nominal) AS total FROM kas_transaksi WHERE jenis_transaksi = ?', [jenis]);
    return (result.first['total'] as num?)?.toDouble() ?? 0;
  }

  Future<Pengaturan> getPengaturan() async {
    final db = await database;
    final maps = await db.query('pengaturan', limit: 1);
    if (maps.isEmpty) {
      return const Pengaturan(
        namaOrganisasi: 'Wanita Katolik',
        namaKetua: '',
        namaBendahara: '',
        namaSekretaris: '',
        defaultIuranArisan: 50000,
        defaultIuranKas: 10000,
      );
    }
    return Pengaturan.fromMap(maps.first);
  }

  Future<int> updatePengaturan(Pengaturan pengaturan) async {
    final db = await database;
    if (pengaturan.id == null) return db.insert('pengaturan', pengaturan.toMap());
    return db.update('pengaturan', pengaturan.toMap(), where: 'id = ?', whereArgs: [pengaturan.id]);
  }

  Future<String> backupDatabase() async {
    final sourcePath = await databasePath;
    await _database?.close();
    _database = null;

    final source = File(sourcePath);
    if (!await source.exists()) {
      await database;
    }

    final now = DateTime.now();
    final stamp = '${now.year}${_two(now.month)}${_two(now.day)}_${_two(now.hour)}${_two(now.minute)}${_two(now.second)}';
    final fileName = 'arisan_wk_backup_$stamp.db';
    final bytes = await File(sourcePath).readAsBytes();
    final savedPath = await DownloadStorageService.saveBackup(bytes: bytes, fileName: fileName);
    await database;
    return savedPath;
  }

  Future<String> restoreLatestBackup() async {
    final backupBytes = await DownloadStorageService.readLatestBackupFromDownloads();
    if (backupBytes.isEmpty) {
      throw Exception('File backup database kosong atau tidak valid.');
    }

    await _database?.close();
    _database = null;
    final targetPath = await databasePath;

    for (final path in [targetPath, '$targetPath-wal', '$targetPath-shm', '$targetPath-journal']) {
      final file = File(path);
      if (await file.exists()) {
        await file.delete();
      }
    }

    await File(targetPath).writeAsBytes(backupBytes, flush: true);
    await database;
    await restructureDatabase();
    return DownloadStorageService.backupLocationLabel;
  }

  Future<String> getBackupLocation() async {
    return DownloadStorageService.backupLocationLabel;
  }

  Future<String> restoreDatabaseFromFile(String selectedPath) async {
    final source = File(selectedPath);
    if (!await source.exists()) {
      throw Exception('File backup tidak ditemukan. Pilih file backup database yang valid.');
    }

    final fileName = basename(source.path).toLowerCase();
    if (!fileName.endsWith('.db')) {
      throw Exception('Format file tidak sesuai. Pilih file backup dengan ekstensi .db');
    }

    final size = await source.length();
    if (size <= 0) {
      throw Exception('File backup kosong atau tidak valid.');
    }

    await _database?.close();
    _database = null;
    final targetPath = await databasePath;

    for (final path in [targetPath, '$targetPath-wal', '$targetPath-shm', '$targetPath-journal']) {
      final file = File(path);
      if (await file.exists()) {
        await file.delete();
      }
    }

    await source.copy(targetPath);
    await database;
    await restructureDatabase();
    return source.path;
  }

  String _two(int value) => value.toString().padLeft(2, '0');

}
