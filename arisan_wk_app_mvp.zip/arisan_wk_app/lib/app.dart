import 'package:flutter/material.dart';

import 'screens/home_screen.dart';

class ArisanWkApp extends StatelessWidget {
  const ArisanWkApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Arisan WK',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF7B2CBF)),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF8F5FB),
        appBarTheme: const AppBarTheme(centerTitle: false),
        cardTheme: CardThemeData(
          elevation: 1,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          filled: true,
          fillColor: Colors.white,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
