class KasTransaksi {
  final int? id;
  final String tanggalTransaksi;
  final String jenisTransaksi;
  final String kategori;
  final double nominal;
  final String keterangan;
  final String penanggungJawab;

  const KasTransaksi({
    this.id,
    required this.tanggalTransaksi,
    required this.jenisTransaksi,
    required this.kategori,
    required this.nominal,
    required this.keterangan,
    required this.penanggungJawab,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'tanggal_transaksi': tanggalTransaksi,
      'jenis_transaksi': jenisTransaksi,
      'kategori': kategori,
      'nominal': nominal,
      'keterangan': keterangan,
      'penanggung_jawab': penanggungJawab,
    };
  }

  factory KasTransaksi.fromMap(Map<String, dynamic> map) {
    return KasTransaksi(
      id: map['id'] as int?,
      tanggalTransaksi: map['tanggal_transaksi'] as String? ?? '',
      jenisTransaksi: map['jenis_transaksi'] as String? ?? 'Pemasukan',
      kategori: map['kategori'] as String? ?? '',
      nominal: (map['nominal'] as num?)?.toDouble() ?? 0,
      keterangan: map['keterangan'] as String? ?? '',
      penanggungJawab: map['penanggung_jawab'] as String? ?? '',
    );
  }
}
