class PemenangArisan {
  final int? id;
  final int idPeriode;
  final int idAnggota;
  final String tanggalMenang;
  final double nominalDiterima;
  final String statusPenerimaan;
  final String catatan;

  const PemenangArisan({
    this.id,
    required this.idPeriode,
    required this.idAnggota,
    required this.tanggalMenang,
    required this.nominalDiterima,
    required this.statusPenerimaan,
    required this.catatan,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'id_periode': idPeriode,
      'id_anggota': idAnggota,
      'tanggal_menang': tanggalMenang,
      'nominal_diterima': nominalDiterima,
      'status_penerimaan': statusPenerimaan,
      'catatan': catatan,
    };
  }

  factory PemenangArisan.fromMap(Map<String, dynamic> map) {
    return PemenangArisan(
      id: map['id'] as int?,
      idPeriode: map['id_periode'] as int? ?? 0,
      idAnggota: map['id_anggota'] as int? ?? 0,
      tanggalMenang: map['tanggal_menang'] as String? ?? '',
      nominalDiterima: (map['nominal_diterima'] as num?)?.toDouble() ?? 0,
      statusPenerimaan: map['status_penerimaan'] as String? ?? 'Belum Diterima',
      catatan: map['catatan'] as String? ?? '',
    );
  }
}
