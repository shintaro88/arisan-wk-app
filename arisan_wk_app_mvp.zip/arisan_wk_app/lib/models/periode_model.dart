class PeriodeArisan {
  final int? id;
  final String namaPeriode;
  final String tanggalArisan;
  final String lokasi;
  final double nominalIuran;
  final String status;
  final String catatan;

  const PeriodeArisan({
    this.id,
    required this.namaPeriode,
    required this.tanggalArisan,
    required this.lokasi,
    required this.nominalIuran,
    required this.status,
    required this.catatan,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nama_periode': namaPeriode,
      'tanggal_arisan': tanggalArisan,
      'lokasi': lokasi,
      'nominal_iuran': nominalIuran,
      'status': status,
      'catatan': catatan,
    };
  }

  factory PeriodeArisan.fromMap(Map<String, dynamic> map) {
    return PeriodeArisan(
      id: map['id'] as int?,
      namaPeriode: map['nama_periode'] as String? ?? '',
      tanggalArisan: map['tanggal_arisan'] as String? ?? '',
      lokasi: map['lokasi'] as String? ?? '',
      nominalIuran: (map['nominal_iuran'] as num?)?.toDouble() ?? 0,
      status: map['status'] as String? ?? 'Aktif',
      catatan: map['catatan'] as String? ?? '',
    );
  }
}
