class Pengaturan {
  final int? id;
  final String namaOrganisasi;
  final String namaKetua;
  final String namaBendahara;
  final String namaSekretaris;
  final double defaultIuranArisan;
  final double defaultIuranKas;

  const Pengaturan({
    this.id,
    required this.namaOrganisasi,
    required this.namaKetua,
    required this.namaBendahara,
    required this.namaSekretaris,
    required this.defaultIuranArisan,
    required this.defaultIuranKas,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nama_organisasi': namaOrganisasi,
      'nama_ketua': namaKetua,
      'nama_bendahara': namaBendahara,
      'nama_sekretaris': namaSekretaris,
      'default_iuran_arisan': defaultIuranArisan,
      'default_iuran_kas': defaultIuranKas,
    };
  }

  factory Pengaturan.fromMap(Map<String, dynamic> map) {
    return Pengaturan(
      id: map['id'] as int?,
      namaOrganisasi: map['nama_organisasi'] as String? ?? 'Wanita Katolik',
      namaKetua: map['nama_ketua'] as String? ?? '',
      namaBendahara: map['nama_bendahara'] as String? ?? '',
      namaSekretaris: map['nama_sekretaris'] as String? ?? '',
      defaultIuranArisan: (map['default_iuran_arisan'] as num?)?.toDouble() ?? 0,
      defaultIuranKas: (map['default_iuran_kas'] as num?)?.toDouble() ?? 0,
    );
  }

  Pengaturan copyWith({
    int? id,
    String? namaOrganisasi,
    String? namaKetua,
    String? namaBendahara,
    String? namaSekretaris,
    double? defaultIuranArisan,
    double? defaultIuranKas,
  }) {
    return Pengaturan(
      id: id ?? this.id,
      namaOrganisasi: namaOrganisasi ?? this.namaOrganisasi,
      namaKetua: namaKetua ?? this.namaKetua,
      namaBendahara: namaBendahara ?? this.namaBendahara,
      namaSekretaris: namaSekretaris ?? this.namaSekretaris,
      defaultIuranArisan: defaultIuranArisan ?? this.defaultIuranArisan,
      defaultIuranKas: defaultIuranKas ?? this.defaultIuranKas,
    );
  }
}
