class Anggota {
  final int? id;
  final String nama;
  final String noHp;
  final String alamat;
  final String wilayah;
  final String status;
  final String tanggalBergabung;
  final String catatan;

  const Anggota({
    this.id,
    required this.nama,
    required this.noHp,
    required this.alamat,
    required this.wilayah,
    required this.status,
    required this.tanggalBergabung,
    required this.catatan,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nama': nama,
      'no_hp': noHp,
      'alamat': alamat,
      'wilayah': wilayah,
      'status': status,
      'tanggal_bergabung': tanggalBergabung,
      'catatan': catatan,
    };
  }

  factory Anggota.fromMap(Map<String, dynamic> map) {
    return Anggota(
      id: map['id'] as int?,
      nama: map['nama'] as String? ?? '',
      noHp: map['no_hp'] as String? ?? '',
      alamat: map['alamat'] as String? ?? '',
      wilayah: map['wilayah'] as String? ?? '',
      status: map['status'] as String? ?? 'Aktif',
      tanggalBergabung: map['tanggal_bergabung'] as String? ?? '',
      catatan: map['catatan'] as String? ?? '',
    );
  }

  Anggota copyWith({
    int? id,
    String? nama,
    String? noHp,
    String? alamat,
    String? wilayah,
    String? status,
    String? tanggalBergabung,
    String? catatan,
  }) {
    return Anggota(
      id: id ?? this.id,
      nama: nama ?? this.nama,
      noHp: noHp ?? this.noHp,
      alamat: alamat ?? this.alamat,
      wilayah: wilayah ?? this.wilayah,
      status: status ?? this.status,
      tanggalBergabung: tanggalBergabung ?? this.tanggalBergabung,
      catatan: catatan ?? this.catatan,
    );
  }
}
