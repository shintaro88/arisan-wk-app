class PembayaranIuran {
  final int? id;
  final int idAnggota;
  final int idPeriode;
  final double nominalIuran;
  final double nominalBayar;
  final String tanggalBayar;
  final String metodeBayar;
  final String statusBayar;
  final String catatan;
  final String sumberBayar;
  final String statusTalangan;
  final String tanggalPelunasanTalangan;

  const PembayaranIuran({
    this.id,
    required this.idAnggota,
    required this.idPeriode,
    required this.nominalIuran,
    required this.nominalBayar,
    required this.tanggalBayar,
    required this.metodeBayar,
    required this.statusBayar,
    required this.catatan,
    this.sumberBayar = 'Pribadi',
    this.statusTalangan = 'Tidak Ada',
    this.tanggalPelunasanTalangan = '',
  });

  static String hitungStatus(double nominalIuran, double nominalBayar) {
    if (nominalBayar <= 0) return 'Belum Bayar';
    if (nominalBayar < nominalIuran) return 'Sebagian';
    return 'Sudah Bayar';
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'id_anggota': idAnggota,
      'id_periode': idPeriode,
      'nominal_iuran': nominalIuran,
      'nominal_bayar': nominalBayar,
      'tanggal_bayar': tanggalBayar,
      'metode_bayar': metodeBayar,
      'status_bayar': statusBayar,
      'catatan': catatan,
      'sumber_bayar': sumberBayar,
      'status_talangan': statusTalangan,
      'tanggal_pelunasan_talangan': tanggalPelunasanTalangan,
    };
  }

  factory PembayaranIuran.fromMap(Map<String, dynamic> map) {
    return PembayaranIuran(
      id: map['id'] as int?,
      idAnggota: map['id_anggota'] as int? ?? 0,
      idPeriode: map['id_periode'] as int? ?? 0,
      nominalIuran: (map['nominal_iuran'] as num?)?.toDouble() ?? 0,
      nominalBayar: (map['nominal_bayar'] as num?)?.toDouble() ?? 0,
      tanggalBayar: map['tanggal_bayar'] as String? ?? '',
      metodeBayar: map['metode_bayar'] as String? ?? 'Tunai',
      statusBayar: map['status_bayar'] as String? ?? 'Belum Bayar',
      catatan: map['catatan'] as String? ?? '',
      sumberBayar: map['sumber_bayar'] as String? ?? 'Pribadi',
      statusTalangan: map['status_talangan'] as String? ?? 'Tidak Ada',
      tanggalPelunasanTalangan: map['tanggal_pelunasan_talangan'] as String? ?? '',
    );
  }
}
