import 'package:flutter/material.dart';

import '../core/database/database_helper.dart';
import '../core/utils/formatters.dart';
import '../models/anggota_model.dart';
import '../models/kas_model.dart';
import '../models/pengaturan_model.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/numeric_text_field.dart';

class KasScreen extends StatefulWidget {
  const KasScreen({super.key});

  @override
  State<KasScreen> createState() => _KasScreenState();
}

class _KasScreenState extends State<KasScreen> {
  List<KasTransaksi> _transaksi = [];
  double _saldo = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final transaksi = await DatabaseHelper.instance.getKas();
    final saldo = await DatabaseHelper.instance.getSaldoKas();
    if (!mounted) return;
    setState(() {
      _transaksi = transaksi;
      _saldo = saldo;
      _loading = false;
    });
  }

  Future<void> _openForm({KasTransaksi? transaksi}) async {
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (context) => _KasForm(transaksi: transaksi, saldoSaatIni: _saldo),
    );
    if (saved == true) _load();
  }

  Future<void> _delete(KasTransaksi transaksi) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus transaksi?'),
        content: Text(transaksi.keterangan),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus')),
        ],
      ),
    );
    if (ok == true && transaksi.id != null) {
      await DatabaseHelper.instance.deleteKas(transaksi.id!);
      await _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openForm(),
        icon: const Icon(Icons.add),
        label: const Text('Tambah'),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Saldo Kas Saat Ini', style: TextStyle(color: Colors.black54)),
                  const SizedBox(height: 6),
                  Text(AppFormatters.rupiah(_saldo), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (_transaksi.isEmpty)
            const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('Belum ada transaksi kas.')))
          else
            ..._transaksi.map((item) {
              final nominalText = item.jenisTransaksi == 'Pemasukan'
                  ? '+ ${AppFormatters.rupiah(item.nominal)}'
                  : '- ${AppFormatters.rupiah(item.nominal)}';
              return Card(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: ListTile(
                    leading: Icon(item.jenisTransaksi == 'Pemasukan' ? Icons.arrow_downward : Icons.arrow_upward),
                    title: Text(item.keterangan, style: const TextStyle(fontWeight: FontWeight.bold), maxLines: 2, overflow: TextOverflow.ellipsis),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 4),
                        Text('${item.tanggalTransaksi} • ${item.kategori}'),
                        Text('${item.jenisTransaksi} • $nominalText'),
                        Text('Penanggung jawab: ${item.penanggungJawab.isEmpty ? '-' : item.penanggungJawab}'),
                      ],
                    ),
                    trailing: PopupMenuButton<String>(
                      onSelected: (value) {
                        if (value == 'edit') _openForm(transaksi: item);
                        if (value == 'delete') _delete(item);
                      },
                      itemBuilder: (context) => const [
                        PopupMenuItem(value: 'edit', child: Text('Edit')),
                        PopupMenuItem(value: 'delete', child: Text('Hapus')),
                      ],
                    ),
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }
}

class _KasForm extends StatefulWidget {
  final KasTransaksi? transaksi;
  final double saldoSaatIni;

  const _KasForm({this.transaksi, required this.saldoSaatIni});

  @override
  State<_KasForm> createState() => _KasFormState();
}

class _KasFormState extends State<_KasForm> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _tanggal;
  late final TextEditingController _nominal;
  late final TextEditingController _keterangan;
  late final TextEditingController _pj;
  final TextEditingController _searchKas = TextEditingController();
  String _jenis = 'Pemasukan';
  String _kategori = 'Iuran Kas';
  List<Anggota> _anggotaBelumBayarKas = [];
  List<Anggota> _anggotaKas = [];
  List<Map<String, dynamic>> _anggotaSudahBayarKas = [];
  Map<int, Map<String, dynamic>> _kasPaidByAnggota = {};
  final Set<int> _selectedKasIds = <int>{};
  Pengaturan? _pengaturan;
  bool _loadingMaster = true;
  bool _reminderOpen = false;

  static const List<String> _kategoriPemasukan = ['Iuran Kas', 'Donasi', 'Sisa Kegiatan', 'Bantuan Anggota', 'Lainnya'];
  static const List<String> _kategoriPengeluaran = ['Konsumsi Kegiatan', 'Bantuan Sosial', 'Dana Kunjungan', 'Perlengkapan Kegiatan', 'Kegiatan Gereja', 'Talangan Arisan', 'Lainnya'];

  @override
  void initState() {
    super.initState();
    final t = widget.transaksi;
    _tanggal = TextEditingController(text: t?.tanggalTransaksi ?? AppFormatters.today());
    _nominal = TextEditingController(text: t == null ? '0' : t.nominal.toStringAsFixed(0));
    _keterangan = TextEditingController(text: t?.keterangan ?? '');
    _pj = TextEditingController(text: t?.penanggungJawab ?? 'Bendahara');
    _jenis = t?.jenisTransaksi ?? 'Pemasukan';
    _kategori = t?.kategori ?? 'Iuran Kas';
    if (!_kategoriList.contains(_kategori)) _kategori = _kategoriList.first;
    _tanggal.addListener(_onTanggalChanged);
    _searchKas.addListener(() => setState(() {}));
    _loadMaster();
  }

  Future<void> _loadMaster() async {
    final p = await DatabaseHelper.instance.getPengaturan();
    final semuaKas = await DatabaseHelper.instance.getAnggotaIkutKas();
    final belumKas = await DatabaseHelper.instance.getAnggotaBelumBayarKas(_tanggal.text);
    final sudahKas = await DatabaseHelper.instance.getPembayaranKasDetail(_tanggal.text);
    final hasMainKas = await DatabaseHelper.instance.existsKasIuranBulanan(tanggal: _tanggal.text);
    final paidMap = <int, Map<String, dynamic>>{};
    for (final item in sudahKas) {
      final id = item['id_anggota'];
      if (id is int) paidMap[id] = item;
    }
    if (!mounted) return;
    setState(() {
      _pengaturan = p;
      _anggotaKas = semuaKas;
      _anggotaBelumBayarKas = belumKas;
      _anggotaSudahBayarKas = sudahKas;
      _kasPaidByAnggota = paidMap;
      _selectedKasIds.clear();
      if (widget.transaksi != null && _isIuranKas) {
        _selectedKasIds.addAll(paidMap.keys);
      } else if (_isIuranKas && !hasMainKas) {
        // Kalau transaksi utama bulan ini sudah dihapus tetapi detail lama masih ada,
        // default-kan kembali semua anggota ikut kas agar admin bisa input ulang tanpa tersangkut data orphan.
        _selectedKasIds.addAll(semuaKas.where((a) => a.id != null).map((a) => a.id!));
      } else {
        _selectedKasIds.addAll(belumKas.where((a) => a.id != null).map((a) => a.id!));
      }
      _loadingMaster = false;
    });
    if (_isIuranKas) {
      _applyIuranKasDefault(showReminder: widget.transaksi == null);
    }
  }

  Future<void> _reloadKasByMonth() async {
    final semuaKas = await DatabaseHelper.instance.getAnggotaIkutKas();
    final belumKas = await DatabaseHelper.instance.getAnggotaBelumBayarKas(_tanggal.text);
    final sudahKas = await DatabaseHelper.instance.getPembayaranKasDetail(_tanggal.text);
    final hasMainKas = await DatabaseHelper.instance.existsKasIuranBulanan(tanggal: _tanggal.text);
    final paidMap = <int, Map<String, dynamic>>{};
    for (final item in sudahKas) {
      final id = item['id_anggota'];
      if (id is int) paidMap[id] = item;
    }
    if (!mounted) return;
    setState(() {
      _anggotaKas = semuaKas;
      _anggotaBelumBayarKas = belumKas;
      _anggotaSudahBayarKas = sudahKas;
      _kasPaidByAnggota = paidMap;
      _selectedKasIds.clear();
      if (widget.transaksi != null && _isIuranKas) {
        _selectedKasIds.addAll(paidMap.keys);
      } else if (_isIuranKas && !hasMainKas) {
        _selectedKasIds.addAll(semuaKas.where((a) => a.id != null).map((a) => a.id!));
      } else {
        _selectedKasIds.addAll(belumKas.where((a) => a.id != null).map((a) => a.id!));
      }
    });
    _applyIuranKasDefault(showReminder: false);
  }

  void _onTanggalChanged() {
    if (_isIuranKas) _reloadKasByMonth();
  }

  @override
  void dispose() {
    _tanggal.removeListener(_onTanggalChanged);
    _tanggal.dispose();
    _nominal.dispose();
    _keterangan.dispose();
    _pj.dispose();
    _searchKas.dispose();
    super.dispose();
  }

  bool get _isIuranKas => _jenis == 'Pemasukan' && _kategori == 'Iuran Kas';
  List<String> get _kategoriList => _jenis == 'Pemasukan' ? _kategoriPemasukan : _kategoriPengeluaran;
  double get _nominalKasPerOrang => _pengaturan?.defaultIuranKas ?? 0;
  double get _totalIuranKasTerpilih => _selectedKasIds.length * _nominalKasPerOrang;

  List<Anggota> get _filteredAnggotaKas {
    final q = _searchKas.text.trim().toLowerCase();
    if (q.isEmpty) return _anggotaKas;
    return _anggotaKas.where((a) => '${a.nama} ${a.wilayah} ${a.noHp}'.toLowerCase().contains(q)).toList();
  }

  bool get _semuaKasTerpilih => _filteredAnggotaKas.isNotEmpty && _filteredAnggotaKas.every((a) => a.id != null && _selectedKasIds.contains(a.id));

  void _toggleSemuaKas(bool? checked) {
    setState(() {
      if (checked == true) {
        for (final a in _filteredAnggotaKas) {
          if (a.id != null) _selectedKasIds.add(a.id!);
        }
      } else {
        for (final a in _filteredAnggotaKas) {
          if (a.id != null) _selectedKasIds.remove(a.id!);
        }
      }
      _setIuranKasFields();
    });
  }

  void _onJenisChanged(String? value) {
    setState(() {
      _jenis = value ?? 'Pemasukan';
      _kategori = _kategoriList.first;
    });
    if (_isIuranKas) _applyIuranKasDefault(showReminder: true);
  }

  void _onKategoriChanged(String? value) {
    setState(() => _kategori = value ?? _kategoriList.first);
    if (_isIuranKas) _applyIuranKasDefault(showReminder: true);
  }

  void _setIuranKasFields() {
    _nominal.text = _totalIuranKasTerpilih.toStringAsFixed(0);
    if (_keterangan.text.trim().isEmpty || _keterangan.text.startsWith('Iuran Kas Bulanan')) {
      _keterangan.text = 'Iuran Kas Bulanan ${_tanggal.text.length >= 7 ? _tanggal.text.substring(0, 7) : _tanggal.text}';
    }
  }

  void _applyIuranKasDefault({required bool showReminder}) {
    if (!_isIuranKas) return;
    setState(_setIuranKasFields);
    if (showReminder) _showKasReminder();
  }

  Future<void> _showKasReminder() async {
    if (_reminderOpen || !mounted || !_isIuranKas) return;
    _reminderOpen = true;
    final month = _tanggal.text.length >= 7 ? _tanggal.text.substring(0, 7) : _tanggal.text;
    final belumNames = _anggotaBelumBayarKas.map((e) => e.nama).join('\n• ');
    final sudahNames = _anggotaSudahBayarKas.map((e) => e['nama']?.toString() ?? '-').join('\n• ');
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Pengingat Iuran Kas $month'),
        content: SingleChildScrollView(
          child: Text(
            'Nominal otomatis dihitung dari anggota yang dicentang.\n\n'
            'Belum bayar kas: ${_anggotaBelumBayarKas.length} anggota\n'
            'Sudah bayar kas: ${_anggotaSudahBayarKas.length} anggota\n'
            'Nominal per orang: ${AppFormatters.rupiah(_nominalKasPerOrang)}\n'
            'Total terpilih: ${AppFormatters.rupiah(_totalIuranKasTerpilih)}\n\n'
            'Daftar belum bayar:\n• ${belumNames.isEmpty ? 'Tidak ada' : belumNames}\n\n'
            'Daftar sudah bayar/lunas:\n• ${sudahNames.isEmpty ? 'Belum ada' : sudahNames}',
          ),
        ),
        actions: [FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Mengerti'))],
      ),
    );
    _reminderOpen = false;
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final nominal = AppFormatters.parseNumber(_nominal.text);
    if (_jenis == 'Pengeluaran' && nominal > widget.saldoSaatIni && _keterangan.text.trim().length < 10) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pengeluaran melebihi saldo. Tambahkan keterangan yang jelas.')));
      return;
    }
    final kas = KasTransaksi(
      id: widget.transaksi?.id,
      tanggalTransaksi: _tanggal.text.trim(),
      jenisTransaksi: _jenis,
      kategori: _kategori,
      nominal: nominal,
      keterangan: _keterangan.text.trim(),
      penanggungJawab: _pj.text.trim(),
      idAnggota: null,
    );
    try {
      if (widget.transaksi == null && _isIuranKas) {
        await DatabaseHelper.instance.insertKasIuranBatch(
          kas: kas,
          anggotaIds: _selectedKasIds.toList(),
          nominalPerOrang: _nominalKasPerOrang,
        );
      } else if (widget.transaksi != null && _isIuranKas) {
        await DatabaseHelper.instance.updateKasIuranBatch(
          kas: kas,
          anggotaIds: _selectedKasIds.toList(),
          nominalPerOrang: _nominalKasPerOrang,
        );
      } else if (widget.transaksi == null) {
        await DatabaseHelper.instance.insertKas(kas);
      } else {
        await DatabaseHelper.instance.updateKas(kas);
      }
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(context).viewInsets.bottom + 16),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(widget.transaksi == null ? 'Tambah Transaksi Kas' : 'Edit Transaksi Kas', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              if (_loadingMaster) const LinearProgressIndicator(),
              DropdownButtonFormField<String>(
                initialValue: _jenis,
                decoration: const InputDecoration(labelText: 'Jenis transaksi'),
                items: const ['Pemasukan', 'Pengeluaran'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                onChanged: _onJenisChanged,
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                initialValue: _kategori,
                decoration: const InputDecoration(labelText: 'Kategori / keperluan'),
                items: _kategoriList.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                onChanged: _onKategoriChanged,
              ),
              const SizedBox(height: 10),
              DatePickerField(controller: _tanggal, labelText: 'Tanggal transaksi'),
              const SizedBox(height: 10),
              if (_isIuranKas) ...[
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Iuran Kas per Anggota', style: TextStyle(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 6),
                        Text('Centang anggota yang membayar kas. Nominal otomatis = jumlah centang x default iuran kas (${AppFormatters.rupiah(_nominalKasPerOrang)}).'),
                        const SizedBox(height: 8),
                        TextField(
                          controller: _searchKas,
                          decoration: const InputDecoration(prefixIcon: Icon(Icons.search), labelText: 'Cari nama anggota kas'),
                        ),
                        CheckboxListTile(
                          value: _semuaKasTerpilih,
                          onChanged: _toggleSemuaKas,
                          controlAffinity: ListTileControlAffinity.leading,
                          title: const Text('Centang semua hasil pencarian'),
                          subtitle: const Text('Anggota yang sudah lunas tetap muncul dan bisa diedit. Centang = lunas, tidak dicentang = belum bayar.'),
                        ),
                        ConstrainedBox(
                          constraints: const BoxConstraints(maxHeight: 220),
                          child: ListView.builder(
                            shrinkWrap: true,
                            itemCount: _filteredAnggotaKas.length,
                            itemBuilder: (context, index) {
                              final anggota = _filteredAnggotaKas[index];
                              final id = anggota.id;
                              final selected = id != null && _selectedKasIds.contains(id);
                              final paidInfo = id == null ? null : _kasPaidByAnggota[id];
                              final statusText = paidInfo == null
                                  ? 'Belum bayar bulan ini'
                                  : 'Sudah bayar/lunas • ${AppFormatters.rupiah((paidInfo['nominal_bayar'] as num?) ?? 0)}';
                              return CheckboxListTile(
                                dense: true,
                                value: selected,
                                onChanged: id == null
                                    ? null
                                    : (checked) {
                                        setState(() {
                                          if (checked == true) {
                                            _selectedKasIds.add(id);
                                          } else {
                                            _selectedKasIds.remove(id);
                                          }
                                          _setIuranKasFields();
                                        });
                                      },
                                title: Text(anggota.nama),
                                subtitle: Text('${anggota.wilayah.isEmpty ? 'Tanpa wilayah' : anggota.wilayah} • $statusText'),
                              );
                            },
                          ),
                        ),
                        if (_anggotaSudahBayarKas.isNotEmpty) ...[
                          const Divider(),
                          Text(
                            'Catatan: ${_anggotaSudahBayarKas.length} anggota sudah tercatat lunas bulan ini. Mereka tetap muncul di daftar dan bisa diubah jika admin salah input.',
                            style: const TextStyle(color: Colors.black54),
                          ),
                        ],
                        TextButton.icon(onPressed: _showKasReminder, icon: const Icon(Icons.notifications_active_outlined), label: const Text('Lihat pengingat belum bayar kas')),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
              ],
              NumericTextField(controller: _nominal, labelText: 'Nominal', enabled: !_isIuranKas, validator: (v) => AppFormatters.parseNumber(v ?? '') <= 0 ? 'Nominal wajib lebih dari 0' : null),
              const SizedBox(height: 10),
              TextFormField(controller: _keterangan, decoration: const InputDecoration(labelText: 'Keterangan / pengeluaran untuk apa'), minLines: 1, maxLines: 3, validator: (v) => v == null || v.trim().isEmpty ? 'Keterangan wajib diisi' : null),
              const SizedBox(height: 10),
              TextFormField(controller: _pj, decoration: const InputDecoration(labelText: 'Penanggung jawab')),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Simpan'))),
            ],
          ),
        ),
      ),
    );
  }
}
