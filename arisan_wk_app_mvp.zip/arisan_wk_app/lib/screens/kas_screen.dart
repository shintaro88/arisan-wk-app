import 'package:flutter/material.dart';

import '../core/database/database_helper.dart';
import '../core/utils/formatters.dart';
import '../models/anggota_model.dart';
import '../models/kas_model.dart';
import '../widgets/date_picker_field.dart';

class KasScreen extends StatefulWidget {
  const KasScreen({super.key});

  @override
  State<KasScreen> createState() => _KasScreenState();
}

class _KasScreenState extends State<KasScreen> {
  List<KasTransaksi> _transaksi = [];
  Map<int, String> _namaAnggota = {};
  double _saldo = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final transaksi = await DatabaseHelper.instance.getKas();
    final saldo = await DatabaseHelper.instance.getSaldoKas();
    final anggota = await DatabaseHelper.instance.getAnggota();
    if (!mounted) return;
    setState(() {
      _transaksi = transaksi;
      _namaAnggota = {for (final item in anggota) if (item.id != null) item.id!: item.nama};
      _saldo = saldo;
      _loading = false;
    });
  }

  Future<void> _openForm({KasTransaksi? transaksi}) async {
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (context) => _KasForm(transaksi: transaksi, saldoSaatIni: _saldo),
    );
    if (saved == true) _load();
  }

  Future<void> _delete(KasTransaksi transaksi) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus transaksi?'),
        content: Text(transaksi.keterangan),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus')),
        ],
      ),
    );
    if (ok == true && transaksi.id != null) {
      await DatabaseHelper.instance.deleteKas(transaksi.id!);
      await _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openForm(),
        icon: const Icon(Icons.add),
        label: const Text('Tambah'),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Saldo Kas Saat Ini', style: TextStyle(color: Colors.black54)),
                  const SizedBox(height: 6),
                  Text(AppFormatters.rupiah(_saldo), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (_transaksi.isEmpty)
            const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('Belum ada transaksi kas.')))
          else
            ..._transaksi.map((item) {
              final nama = item.idAnggota == null ? '' : (_namaAnggota[item.idAnggota!] ?? 'Anggota tidak ditemukan');
              final detailNama = nama.isEmpty ? '' : '\nAnggota: $nama';
              final nominalText = item.jenisTransaksi == 'Pemasukan'
                  ? '+ ${AppFormatters.rupiah(item.nominal)}'
                  : '- ${AppFormatters.rupiah(item.nominal)}';
              return Card(
                child: ListTile(
                  leading: Icon(item.jenisTransaksi == 'Pemasukan' ? Icons.arrow_downward : Icons.arrow_upward),
                  title: Text(item.keterangan, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(
                    '${item.tanggalTransaksi} • ${item.kategori}\n${item.jenisTransaksi} • $nominalText • PJ: ${item.penanggungJawab}$detailNama',
                  ),
                  isThreeLine: true,
                  trailing: PopupMenuButton<String>(
                    onSelected: (value) {
                      if (value == 'edit') _openForm(transaksi: item);
                      if (value == 'delete') _delete(item);
                    },
                    itemBuilder: (context) => const [
                      PopupMenuItem(value: 'edit', child: Text('Edit')),
                      PopupMenuItem(value: 'delete', child: Text('Hapus')),
                    ],
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }
}

class _KasForm extends StatefulWidget {
  final KasTransaksi? transaksi;
  final double saldoSaatIni;

  const _KasForm({this.transaksi, required this.saldoSaatIni});

  @override
  State<_KasForm> createState() => _KasFormState();
}

class _KasFormState extends State<_KasForm> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _tanggal;
  late final TextEditingController _nominal;
  late final TextEditingController _keterangan;
  late final TextEditingController _pj;
  String _jenis = 'Pemasukan';
  String _kategori = 'Iuran Kas';
  int? _selectedAnggotaId;
  List<Anggota> _anggota = [];

  static const List<String> _kategoriPemasukan = ['Iuran Kas', 'Donasi', 'Sisa Kegiatan', 'Bantuan Anggota', 'Lainnya'];
  static const List<String> _kategoriPengeluaran = ['Konsumsi Kegiatan', 'Bantuan Sosial', 'Dana Kunjungan', 'Perlengkapan Kegiatan', 'Kegiatan Gereja', 'Lainnya'];

  @override
  void initState() {
    super.initState();
    final t = widget.transaksi;
    _tanggal = TextEditingController(text: t?.tanggalTransaksi ?? AppFormatters.today());
    _nominal = TextEditingController(text: t == null ? '0' : t.nominal.toStringAsFixed(0));
    _keterangan = TextEditingController(text: t?.keterangan ?? '');
    _pj = TextEditingController(text: t?.penanggungJawab ?? 'Bendahara');
    _jenis = t?.jenisTransaksi ?? 'Pemasukan';
    _kategori = t?.kategori ?? 'Iuran Kas';
    if (!_kategoriList.contains(_kategori)) {
      _kategori = 'Lainnya';
    }
    _selectedAnggotaId = t?.idAnggota;
    _loadAnggota();
  }

  Future<void> _loadAnggota() async {
    final data = await DatabaseHelper.instance.getAnggota(status: 'Aktif');
    if (!mounted) return;
    setState(() {
      _anggota = data;
      final validSelected = _selectedAnggotaId == null || data.any((a) => a.id == _selectedAnggotaId);
      if (!validSelected) _selectedAnggotaId = null;
      if (_selectedAnggotaId == null && _isIuranKas && data.isNotEmpty) {
        _selectedAnggotaId = data.first.id;
      }
    });
  }

  @override
  void dispose() {
    _tanggal.dispose();
    _nominal.dispose();
    _keterangan.dispose();
    _pj.dispose();
    super.dispose();
  }

  bool get _isIuranKas => _jenis == 'Pemasukan' && _kategori == 'Iuran Kas';

  List<String> get _kategoriList => _jenis == 'Pemasukan' ? _kategoriPemasukan : _kategoriPengeluaran;

  void _onJenisChanged(String? value) {
    setState(() {
      _jenis = value ?? 'Pemasukan';
      _kategori = _kategoriList.first;
      if (!_isIuranKas) _selectedAnggotaId = null;
      if (_isIuranKas && _selectedAnggotaId == null && _anggota.isNotEmpty) {
        _selectedAnggotaId = _anggota.first.id;
      }
    });
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final nominal = AppFormatters.parseNumber(_nominal.text);
    if (_jenis == 'Pengeluaran' && nominal > widget.saldoSaatIni && _keterangan.text.trim().length < 10) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pengeluaran melebihi saldo. Tambahkan keterangan yang jelas.')));
      return;
    }
    final kas = KasTransaksi(
      id: widget.transaksi?.id,
      tanggalTransaksi: _tanggal.text.trim(),
      jenisTransaksi: _jenis,
      kategori: _kategori,
      nominal: nominal,
      keterangan: _keterangan.text.trim(),
      penanggungJawab: _pj.text.trim(),
      idAnggota: _isIuranKas ? _selectedAnggotaId : null,
    );
    try {
      if (widget.transaksi == null) {
        await DatabaseHelper.instance.insertKas(kas);
      } else {
        await DatabaseHelper.instance.updateKas(kas);
      }
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(context).viewInsets.bottom + 16),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(widget.transaksi == null ? 'Tambah Transaksi Kas' : 'Edit Transaksi Kas', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                initialValue: _jenis,
                decoration: const InputDecoration(labelText: 'Jenis transaksi'),
                items: const ['Pemasukan', 'Pengeluaran'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                onChanged: _onJenisChanged,
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                initialValue: _kategori,
                decoration: const InputDecoration(labelText: 'Kategori / keperluan'),
                items: _kategoriList.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                onChanged: (value) => setState(() {
                  _kategori = value ?? _kategoriList.first;
                  if (!_isIuranKas) _selectedAnggotaId = null;
                  if (_isIuranKas && _selectedAnggotaId == null && _anggota.isNotEmpty) {
                    _selectedAnggotaId = _anggota.first.id;
                  }
                }),
              ),
              const SizedBox(height: 10),
              if (_isIuranKas) ...[
                DropdownButtonFormField<int>(
                  initialValue: _selectedAnggotaId,
                  decoration: const InputDecoration(labelText: 'Nama anggota pembayar kas'),
                  items: _anggota.where((a) => a.id != null).map((a) => DropdownMenuItem(value: a.id, child: Text(a.nama))).toList(),
                  onChanged: (value) => setState(() => _selectedAnggotaId = value),
                  validator: (v) => v == null ? 'Pilih anggota' : null,
                ),
                const SizedBox(height: 8),
                Text('Catatan: sistem menolak iuran kas anggota yang sama pada bulan yang sama.', style: TextStyle(color: Colors.grey.shade700, fontSize: 12)),
                const SizedBox(height: 10),
              ],
              DatePickerField(controller: _tanggal, labelText: 'Tanggal transaksi'),
              const SizedBox(height: 10),
              TextFormField(controller: _nominal, decoration: const InputDecoration(labelText: 'Nominal'), keyboardType: TextInputType.number, validator: (v) => AppFormatters.parseNumber(v ?? '') <= 0 ? 'Nominal wajib lebih dari 0' : null),
              const SizedBox(height: 10),
              TextFormField(controller: _keterangan, decoration: const InputDecoration(labelText: 'Keterangan / pengeluaran untuk apa'), minLines: 1, maxLines: 3, validator: (v) => v == null || v.trim().isEmpty ? 'Keterangan wajib diisi' : null),
              const SizedBox(height: 10),
              TextFormField(controller: _pj, decoration: const InputDecoration(labelText: 'Penanggung jawab')),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Simpan'))),
            ],
          ),
        ),
      ),
    );
  }
}
