import 'package:flutter/material.dart';

import '../core/database/database_helper.dart';
import '../core/utils/formatters.dart';
import '../models/anggota_model.dart';
import '../models/pemenang_model.dart';
import '../models/periode_model.dart';
import '../widgets/date_picker_field.dart';

class PemenangScreen extends StatefulWidget {
  const PemenangScreen({super.key});

  @override
  State<PemenangScreen> createState() => _PemenangScreenState();
}

class _PemenangScreenState extends State<PemenangScreen> {
  List<Map<String, dynamic>> _data = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final data = await DatabaseHelper.instance.getPemenangDetail();
    if (!mounted) return;
    setState(() {
      _data = data;
      _loading = false;
    });
  }

  Future<void> _openForm() async {
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (context) => const _PemenangForm(),
    );
    if (saved == true) _load();
  }

  Future<void> _delete(int id) async {
    await DatabaseHelper.instance.deletePemenang(id);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openForm,
        icon: const Icon(Icons.add),
        label: const Text('Tambah'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _data.isEmpty
              ? const Center(child: Text('Belum ada pemenang arisan'))
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
                  itemCount: _data.length,
                  itemBuilder: (context, index) {
                    final item = _data[index];
                    return Card(
                      child: ListTile(
                        leading: const Icon(Icons.emoji_events),
                        title: Text(item['nama']?.toString() ?? '-', style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text('${item['nama_periode']} • ${item['tanggal_menang']}\n${AppFormatters.rupiah((item['nominal_diterima'] as num?) ?? 0)} • ${item['status_penerimaan']}'),
                        isThreeLine: true,
                        trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => _delete(item['id'] as int)),
                      ),
                    );
                  },
                ),
    );
  }
}

class _PemenangForm extends StatefulWidget {
  const _PemenangForm();

  @override
  State<_PemenangForm> createState() => _PemenangFormState();
}

class _PemenangFormState extends State<_PemenangForm> {
  final _formKey = GlobalKey<FormState>();
  final _tanggal = TextEditingController(text: AppFormatters.today());
  final _nominal = TextEditingController(text: '0');
  final _catatan = TextEditingController();
  String _status = 'Sudah Diterima';
  List<PeriodeArisan> _periode = [];
  List<Anggota> _anggota = [];
  PeriodeArisan? _selectedPeriode;
  Anggota? _selectedAnggota;
  double _totalIuran = 0;
  double _totalPencairan = 0;

  @override
  void initState() {
    super.initState();
    _loadMaster();
  }

  Future<void> _loadMaster() async {
    final periode = await DatabaseHelper.instance.getPeriode();
    final anggota = await DatabaseHelper.instance.getAnggota(status: 'Aktif');
    if (!mounted) return;
    setState(() {
      _periode = periode;
      _anggota = anggota;
      if (periode.isNotEmpty) _selectedPeriode = periode.first;
      if (anggota.isNotEmpty) _selectedAnggota = anggota.first;
    });
    await _refreshNominalFromPeriode();
  }

  Future<void> _refreshNominalFromPeriode() async {
    final periode = _selectedPeriode;
    if (periode == null || periode.id == null) return;
    final totalIuran = await DatabaseHelper.instance.totalIuranPeriode(periode.id!);
    final totalPencairan = await DatabaseHelper.instance.totalPencairanPeriode(periode.id!);
    final saldo = totalIuran - totalPencairan;
    if (!mounted) return;
    setState(() {
      _totalIuran = totalIuran;
      _totalPencairan = totalPencairan;
      _nominal.text = (saldo > 0 ? saldo : periode.nominalIuran).toStringAsFixed(0);
    });
  }

  @override
  void dispose() {
    _tanggal.dispose();
    _nominal.dispose();
    _catatan.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedAnggota?.id == null || _selectedPeriode?.id == null) return;
    final nominal = AppFormatters.parseNumber(_nominal.text);
    final saldo = _totalIuran - _totalPencairan;
    if (_status == 'Sudah Diterima' && saldo > 0 && nominal > saldo) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Nominal diterima melebihi saldo arisan periode ini: ${AppFormatters.rupiah(saldo)}')));
      return;
    }
    final pemenang = PemenangArisan(
      idPeriode: _selectedPeriode!.id!,
      idAnggota: _selectedAnggota!.id!,
      tanggalMenang: _tanggal.text.trim(),
      nominalDiterima: nominal,
      statusPenerimaan: _status,
      catatan: _catatan.text.trim(),
    );
    await DatabaseHelper.instance.insertPemenang(pemenang);
    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final saldo = _totalIuran - _totalPencairan;
    return Padding(
      padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(context).viewInsets.bottom + 16),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Tambah Pemenang Arisan', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              DropdownButtonFormField<PeriodeArisan>(
                initialValue: _selectedPeriode,
                decoration: const InputDecoration(labelText: 'Periode'),
                items: _periode.map((p) => DropdownMenuItem(value: p, child: Text(p.namaPeriode))).toList(),
                onChanged: (value) async {
                  setState(() => _selectedPeriode = value);
                  await _refreshNominalFromPeriode();
                },
                validator: (v) => v == null ? 'Pilih periode' : null,
              ),
              const SizedBox(height: 10),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Saldo Arisan Periode', style: TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      Text('Total iuran: ${AppFormatters.rupiah(_totalIuran)}'),
                      Text('Pencairan sebelumnya: ${AppFormatters.rupiah(_totalPencairan)}'),
                      Text('Saldo setelah undian: ${AppFormatters.rupiah(saldo)}', style: const TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<Anggota>(
                initialValue: _selectedAnggota,
                decoration: const InputDecoration(labelText: 'Pemenang'),
                items: _anggota.map((a) => DropdownMenuItem(value: a, child: Text(a.nama))).toList(),
                onChanged: (value) => setState(() => _selectedAnggota = value),
                validator: (v) => v == null ? 'Pilih anggota' : null,
              ),
              const SizedBox(height: 10),
              DatePickerField(controller: _tanggal, labelText: 'Tanggal menang'),
              const SizedBox(height: 10),
              TextFormField(
                controller: _nominal,
                decoration: const InputDecoration(labelText: 'Nominal diterima'),
                keyboardType: TextInputType.number,
                validator: (v) => AppFormatters.parseNumber(v ?? '') <= 0 ? 'Nominal wajib lebih dari 0' : null,
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                initialValue: _status,
                decoration: const InputDecoration(labelText: 'Status penerimaan'),
                items: const ['Sudah Diterima', 'Belum Diterima'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                onChanged: (value) => setState(() => _status = value ?? 'Sudah Diterima'),
              ),
              const SizedBox(height: 10),
              TextFormField(controller: _catatan, decoration: const InputDecoration(labelText: 'Catatan'), maxLines: 2),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Simpan'))),
            ],
          ),
        ),
      ),
    );
  }
}
