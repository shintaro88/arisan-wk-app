import 'package:flutter/material.dart';

import '../core/database/database_helper.dart';
import '../core/utils/formatters.dart';
import '../models/anggota_model.dart';
import '../widgets/date_picker_field.dart';

class AnggotaScreen extends StatefulWidget {
  const AnggotaScreen({super.key});

  @override
  State<AnggotaScreen> createState() => _AnggotaScreenState();
}

class _AnggotaScreenState extends State<AnggotaScreen> {
  final _searchController = TextEditingController();
  String _status = 'Semua';
  List<Anggota> _anggota = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final data = await DatabaseHelper.instance.getAnggota(keyword: _searchController.text, status: _status);
    if (!mounted) return;
    setState(() {
      _anggota = data;
      _loading = false;
    });
  }

  Future<void> _delete(Anggota anggota) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus anggota?'),
        content: Text('Data ${anggota.nama} akan dihapus.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus')),
        ],
      ),
    );
    if (ok == true && anggota.id != null) {
      await DatabaseHelper.instance.deleteAnggota(anggota.id!);
      await _load();
    }
  }

  Future<void> _openForm({Anggota? anggota}) async {
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (context) => _AnggotaForm(anggota: anggota),
    );
    if (saved == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openForm(),
        icon: const Icon(Icons.add),
        label: const Text('Tambah'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                TextField(
                  controller: _searchController,
                  decoration: const InputDecoration(prefixIcon: Icon(Icons.search), labelText: 'Cari nama anggota'),
                  onChanged: (_) => _load(),
                ),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  initialValue: _status,
                  decoration: const InputDecoration(labelText: 'Filter status'),
                  items: const ['Semua', 'Aktif', 'Nonaktif'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                  onChanged: (value) {
                    setState(() => _status = value ?? 'Semua');
                    _load();
                  },
                ),
              ],
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _anggota.isEmpty
                    ? const Center(child: Text('Belum ada data anggota'))
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 90),
                        itemCount: _anggota.length,
                        itemBuilder: (context, index) {
                          final item = _anggota[index];
                          return Card(
                            child: ListTile(
                              leading: CircleAvatar(child: Text(item.nama.isEmpty ? '?' : item.nama[0].toUpperCase())),
                              title: Text(item.nama, style: const TextStyle(fontWeight: FontWeight.bold)),
                              subtitle: Text('${item.wilayah} • ${item.noHp}\nStatus: ${item.status} • ${item.tipeKeikutsertaan}'),
                              isThreeLine: true,
                              trailing: PopupMenuButton<String>(
                                onSelected: (value) {
                                  if (value == 'edit') _openForm(anggota: item);
                                  if (value == 'delete') _delete(item);
                                },
                                itemBuilder: (context) => const [
                                  PopupMenuItem(value: 'edit', child: Text('Edit')),
                                  PopupMenuItem(value: 'delete', child: Text('Hapus')),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}

class _AnggotaForm extends StatefulWidget {
  final Anggota? anggota;

  const _AnggotaForm({this.anggota});

  @override
  State<_AnggotaForm> createState() => _AnggotaFormState();
}

class _AnggotaFormState extends State<_AnggotaForm> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nama;
  late final TextEditingController _hp;
  late final TextEditingController _alamat;
  late final TextEditingController _wilayah;
  late final TextEditingController _tanggal;
  late final TextEditingController _catatan;
  String _status = 'Aktif';
  bool _ikutArisan = true;
  bool _ikutKas = true;

  @override
  void initState() {
    super.initState();
    final a = widget.anggota;
    _nama = TextEditingController(text: a?.nama ?? '');
    _hp = TextEditingController(text: a?.noHp ?? '');
    _alamat = TextEditingController(text: a?.alamat ?? '');
    _wilayah = TextEditingController(text: a?.wilayah ?? '');
    _tanggal = TextEditingController(text: a?.tanggalBergabung ?? AppFormatters.today());
    _catatan = TextEditingController(text: a?.catatan ?? '');
    _status = a?.status ?? 'Aktif';
    _ikutArisan = a?.ikutArisan ?? true;
    _ikutKas = a?.ikutKas ?? true;
  }

  @override
  void dispose() {
    _nama.dispose();
    _hp.dispose();
    _alamat.dispose();
    _wilayah.dispose();
    _tanggal.dispose();
    _catatan.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final namaAnggota = _nama.text.trim();
    final namaSudahAda = await DatabaseHelper.instance.existsAnggotaNama(namaAnggota, exceptId: widget.anggota?.id);
    if (namaSudahAda) {
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Nama anggota sudah ada'),
          content: Text('Nama "$namaAnggota" sudah terdaftar. Data tidak disimpan agar tidak ada anggota dengan nama persis sama.'),
          actions: [
            FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Mengerti')),
          ],
        ),
      );
      return;
    }

    final anggota = Anggota(
      id: widget.anggota?.id,
      nama: namaAnggota,
      noHp: _hp.text.trim(),
      alamat: _alamat.text.trim(),
      wilayah: _wilayah.text.trim(),
      status: _status,
      tanggalBergabung: _tanggal.text.trim(),
      catatan: _catatan.text.trim(),
      ikutArisan: _ikutArisan,
      ikutKas: _ikutKas,
    );
    if (widget.anggota == null) {
      await DatabaseHelper.instance.insertAnggota(anggota);
    } else {
      await DatabaseHelper.instance.updateAnggota(anggota);
    }
    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(context).viewInsets.bottom + 16),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(widget.anggota == null ? 'Tambah Anggota' : 'Edit Anggota', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              TextFormField(controller: _nama, decoration: const InputDecoration(labelText: 'Nama anggota'), validator: (v) => v == null || v.trim().isEmpty ? 'Nama wajib diisi' : null),
              const SizedBox(height: 10),
              TextFormField(controller: _hp, decoration: const InputDecoration(labelText: 'Nomor HP'), keyboardType: TextInputType.phone),
              const SizedBox(height: 10),
              TextFormField(controller: _wilayah, decoration: const InputDecoration(labelText: 'Wilayah / Lingkungan')),
              const SizedBox(height: 10),
              TextFormField(controller: _alamat, decoration: const InputDecoration(labelText: 'Alamat'), minLines: 1, maxLines: 2),
              const SizedBox(height: 10),
              DatePickerField(controller: _tanggal, labelText: 'Tanggal bergabung'),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                initialValue: _status,
                decoration: const InputDecoration(labelText: 'Status'),
                items: const ['Aktif', 'Nonaktif'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                onChanged: (value) => setState(() => _status = value ?? 'Aktif'),
              ),
              const SizedBox(height: 10),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Keikutsertaan Anggota', style: TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      CheckboxListTile(
                        contentPadding: EdgeInsets.zero,
                        value: _ikutKas,
                        onChanged: (value) => setState(() => _ikutKas = value ?? false),
                        title: const Text('Ikut Kas WK'),
                        subtitle: const Text('Dicatat sebagai anggota wajib iuran kas.'),
                      ),
                      CheckboxListTile(
                        contentPadding: EdgeInsets.zero,
                        value: _ikutArisan,
                        onChanged: (value) => setState(() => _ikutArisan = value ?? false),
                        title: const Text('Ikut Arisan'),
                        subtitle: const Text('Nama akan muncul di daftar peserta arisan yang belum bayar.'),
                      ),
                      const Text('Contoh: jika hanya ikut kas saja, centang Ikut Kas WK dan kosongkan Ikut Arisan.', style: TextStyle(fontSize: 12, color: Colors.black54)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              TextFormField(controller: _catatan, decoration: const InputDecoration(labelText: 'Catatan'), minLines: 1, maxLines: 3),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Simpan'))),
            ],
          ),
        ),
      ),
    );
  }
}
