import 'package:flutter/material.dart';

import '../core/database/database_helper.dart';
import '../core/utils/formatters.dart';
import '../services/download_storage_service.dart';
import '../services/pdf_service.dart';

class BuktiIuranScreen extends StatefulWidget {
  const BuktiIuranScreen({super.key});

  @override
  State<BuktiIuranScreen> createState() => _BuktiIuranScreenState();
}

class _BuktiIuranScreenState extends State<BuktiIuranScreen> {
  List<Map<String, dynamic>> _data = [];
  bool _loading = true;
  bool _processing = false;
  String? _lastPath;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final data = await DatabaseHelper.instance.getSemuaBuktiIuran();
    if (!mounted) return;
    setState(() {
      _data = data;
      _loading = false;
    });
  }

  Future<void> _buatBukti(Map<String, dynamic> item) async {
    setState(() => _processing = true);
    try {
      final pengaturan = await DatabaseHelper.instance.getPengaturan();
      final location = await PdfService().exportBuktiPembayaran(pembayaran: item, pengaturan: pengaturan);
      if (!mounted) return;
      setState(() => _lastPath = location);
      final jenis = item['jenis_bukti']?.toString() ?? 'Iuran';
      await _showBuktiDialog(title: 'Bukti Pembayaran Iuran $jenis', location: location);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal membuat bukti: $e')));
    } finally {
      if (mounted) setState(() => _processing = false);
    }
  }

  Future<void> _showBuktiDialog({required String title, required String location}) async {
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Bukti PDF berhasil dibuat'),
        content: Text('$title sudah tersimpan di ${DownloadStorageService.reportLocationLabel}.\n\nBukti bisa langsung dibuka atau dibagikan.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Tutup')),
          OutlinedButton.icon(
            icon: const Icon(Icons.visibility_outlined),
            label: const Text('Lihat PDF'),
            onPressed: () async {
              try {
                await DownloadStorageService.openFile(location);
              } catch (e) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
                }
              }
            },
          ),
          FilledButton.icon(
            icon: const Icon(Icons.share_outlined),
            label: const Text('Bagikan'),
            onPressed: () async {
              try {
                await DownloadStorageService.shareFile(location, title: title);
              } catch (e) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
                }
              }
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Bukti Pembayaran Iuran', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text('Pilih transaksi iuran kas atau arisan, lalu buat bukti PDF. Setelah dibuat, bukti bisa langsung dilihat atau dibagikan. Nomor bukti dan kode validasi tetap menjadi penanda keaslian transaksi.'),
                if (_processing) ...[
                  const SizedBox(height: 12),
                  const LinearProgressIndicator(),
                ],
                if (_lastPath != null) ...[
                  const SizedBox(height: 12),
                  Text('File terakhir: $_lastPath', style: const TextStyle(fontSize: 12, color: Colors.black54)),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (_data.isEmpty)
          const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('Belum ada pembayaran iuran yang bisa dibuatkan bukti.')))
        else
          ..._data.map((item) {
            final nominal = (item['nominal_bayar'] as num?)?.toDouble() ?? 0;
            final jenis = item['jenis_bukti']?.toString() ?? 'Arisan';
            final talangan = item['sumber_bayar'] == 'Ditalangi Kas WK' ? ' • Ditalangi Kas WK' : '';
            return Card(
              child: ListTile(
                leading: Icon(jenis == 'Kas' ? Icons.account_balance_wallet_outlined : Icons.receipt_long_outlined),
                title: Text('$jenis - ${item['nama']?.toString() ?? '-'}', style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('${item['nama_periode']} • ${item['tanggal_bayar']}\n${AppFormatters.rupiah(nominal)} • ${item['status_bayar']}$talangan'),
                isThreeLine: true,
                trailing: IconButton(
                  icon: const Icon(Icons.picture_as_pdf_outlined),
                  tooltip: 'Buat Bukti PDF',
                  onPressed: _processing ? null : () => _buatBukti(item),
                ),
              ),
            );
          }),
      ],
    );
  }
}
