import 'package:flutter/material.dart';

import '../core/database/database_helper.dart';
import '../core/utils/formatters.dart';
import '../models/pengaturan_model.dart';

class PengaturanScreen extends StatefulWidget {
  const PengaturanScreen({super.key});

  @override
  State<PengaturanScreen> createState() => _PengaturanScreenState();
}

class _PengaturanScreenState extends State<PengaturanScreen> {
  final _formKey = GlobalKey<FormState>();
  final _organisasi = TextEditingController();
  final _ketua = TextEditingController();
  final _bendahara = TextEditingController();
  final _sekretaris = TextEditingController();
  final _iuranArisan = TextEditingController();
  final _iuranKas = TextEditingController();
  Pengaturan? _current;
  bool _loading = true;
  bool _processingBackup = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _organisasi.dispose();
    _ketua.dispose();
    _bendahara.dispose();
    _sekretaris.dispose();
    _iuranArisan.dispose();
    _iuranKas.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final p = await DatabaseHelper.instance.getPengaturan();
    if (!mounted) return;
    setState(() {
      _current = p;
      _organisasi.text = p.namaOrganisasi;
      _ketua.text = p.namaKetua;
      _bendahara.text = p.namaBendahara;
      _sekretaris.text = p.namaSekretaris;
      _iuranArisan.text = p.defaultIuranArisan.toStringAsFixed(0);
      _iuranKas.text = p.defaultIuranKas.toStringAsFixed(0);
      _loading = false;
    });
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final p = Pengaturan(
      id: _current?.id,
      namaOrganisasi: _organisasi.text.trim(),
      namaKetua: _ketua.text.trim(),
      namaBendahara: _bendahara.text.trim(),
      namaSekretaris: _sekretaris.text.trim(),
      defaultIuranArisan: AppFormatters.parseNumber(_iuranArisan.text),
      defaultIuranKas: AppFormatters.parseNumber(_iuranKas.text),
    );
    await DatabaseHelper.instance.updatePengaturan(p);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pengaturan berhasil disimpan.')));
    _load();
  }

  Future<void> _backupDatabase() async {
    setState(() => _processingBackup = true);
    try {
      final path = await DatabaseHelper.instance.backupDatabase();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Backup berhasil dibuat: $path')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Backup gagal: ${e.toString()}')));
    } finally {
      if (mounted) setState(() => _processingBackup = false);
    }
  }

  Future<void> _restoreDatabase() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Restore database?'),
        content: const Text('Data saat ini akan diganti dengan file backup terbaru. Pastikan sudah membuat backup sebelum melakukan restore.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Restore')),
        ],
      ),
    );
    if (ok != true) return;

    setState(() => _processingBackup = true);
    try {
      final path = await DatabaseHelper.instance.restoreLatestBackup();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Restore berhasil dari: $path')));
      await _load();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Restore gagal: ${e.toString()}')));
    } finally {
      if (mounted) setState(() => _processingBackup = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    return Form(
      key: _formKey,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Card(
            child: Padding(
              padding: EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Pengaturan Organisasi', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  Text('Data ini digunakan untuk judul laporan dan area tanda tangan Excel.'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          TextFormField(controller: _organisasi, decoration: const InputDecoration(labelText: 'Nama organisasi'), validator: (v) => v == null || v.trim().isEmpty ? 'Nama organisasi wajib diisi' : null),
          const SizedBox(height: 10),
          TextFormField(controller: _ketua, decoration: const InputDecoration(labelText: 'Nama ketua')),
          const SizedBox(height: 10),
          TextFormField(controller: _bendahara, decoration: const InputDecoration(labelText: 'Nama bendahara')),
          const SizedBox(height: 10),
          TextFormField(controller: _sekretaris, decoration: const InputDecoration(labelText: 'Nama sekretaris')),
          const SizedBox(height: 10),
          TextFormField(controller: _iuranArisan, decoration: const InputDecoration(labelText: 'Default iuran arisan'), keyboardType: TextInputType.number),
          const SizedBox(height: 10),
          TextFormField(controller: _iuranKas, decoration: const InputDecoration(labelText: 'Default iuran kas'), keyboardType: TextInputType.number),
          const SizedBox(height: 16),
          FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Simpan Pengaturan')),
          const SizedBox(height: 20),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Backup & Restore Database', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text('Gunakan backup sebelum update aplikasi. Restore akan mengambil file backup terbaru dari folder Download/Arisan WK/Backup Database jika tersedia.'),
                  const SizedBox(height: 14),
                  if (_processingBackup) const LinearProgressIndicator(),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _processingBackup ? null : _backupDatabase,
                      icon: const Icon(Icons.backup_outlined),
                      label: const Text('Backup Database'),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: _processingBackup ? null : _restoreDatabase,
                      icon: const Icon(Icons.restore),
                      label: const Text('Restore Database Terbaru'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
