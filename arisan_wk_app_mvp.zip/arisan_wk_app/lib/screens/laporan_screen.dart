import 'package:flutter/material.dart';

import '../core/database/database_helper.dart';
import '../services/pdf_service.dart';
import '../services/download_storage_service.dart';

class LaporanScreen extends StatefulWidget {
  const LaporanScreen({super.key});

  @override
  State<LaporanScreen> createState() => _LaporanScreenState();
}

class _LaporanScreenState extends State<LaporanScreen> {
  bool _loading = false;
  String? _lastPath;

  Future<void> _runExport(Future<String> Function() task) async {
    setState(() => _loading = true);
    try {
      final path = await task();
      if (!mounted) return;
      setState(() => _lastPath = path);
      final fileName = _fileNameFromPath(path);
      await _showPdfReadyDialog(fileName: fileName, path: path);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal export PDF: $e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _fileNameFromPath(String path) {
    final normalized = path.replaceAll('\\', '/');
    final parts = normalized.split('/').where((part) => part.trim().isNotEmpty).toList();
    return parts.isEmpty ? path : parts.last;
  }

  Future<void> _showPdfReadyDialog({required String fileName, required String path}) async {
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Laporan PDF berhasil dibuat'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(fileName, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('Tersimpan di: $path', style: const TextStyle(fontSize: 12, color: Colors.black54)),
            const SizedBox(height: 12),
            const Text('Bisa langsung dibuka atau dibagikan tanpa mencari manual di File Manager.'),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Tutup')),
          OutlinedButton.icon(
            onPressed: () async {
              try {
                await DownloadStorageService.openReportFile(fileName: fileName, mimeType: 'application/pdf');
              } catch (e) {
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal membuka PDF: $e')));
              }
            },
            icon: const Icon(Icons.visibility_outlined),
            label: const Text('Lihat'),
          ),
          FilledButton.icon(
            onPressed: () async {
              try {
                await DownloadStorageService.shareReportFile(fileName: fileName, mimeType: 'application/pdf');
              } catch (e) {
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal membagikan PDF: $e')));
              }
            },
            icon: const Icon(Icons.share_outlined),
            label: const Text('Share'),
          ),
        ],
      ),
    );
  }

  Future<String> _exportAnggota() async {
    final db = DatabaseHelper.instance;
    final data = await db.getAnggota();
    final pengaturan = await db.getPengaturan();
    return PdfService().exportGenericReport(
      title: 'Laporan Data Anggota',
      headers: ['No', 'Nama', 'Status', 'Ikut Kas', 'Ikut Arisan', 'Tanggal Bergabung'],
      rows: [
        for (var i = 0; i < data.length; i++)
          [i + 1, data[i].nama, data[i].status, data[i].ikutKas ? 'Ya' : 'Tidak', data[i].ikutArisan ? 'Ya' : 'Tidak', data[i].tanggalBergabung]
      ],
      pengaturan: pengaturan,
      fileName: 'Laporan_Anggota_WK.pdf',
    );
  }

  Future<String> _exportKas() async {
    final db = DatabaseHelper.instance;
    final data = await db.getKas();
    final pengaturan = await db.getPengaturan();
    return PdfService().exportKas(transaksi: data, pengaturan: pengaturan);
  }

  Future<String> _exportPemenang() async {
    final db = DatabaseHelper.instance;
    final data = await db.getPemenangDetail();
    final pengaturan = await db.getPengaturan();
    return PdfService().exportGenericReport(
      title: 'Laporan Penerima Arisan',
      headers: ['No', 'Periode', 'Nama', 'Tanggal', 'Nominal', 'Status'],
      rows: [
        for (var i = 0; i < data.length; i++)
          [i + 1, data[i]['nama_periode'], data[i]['nama'], data[i]['tanggal_menang'], data[i]['nominal_diterima'], data[i]['status_penerimaan']]
      ],
      pengaturan: pengaturan,
      fileName: 'Laporan_Penerima_Arisan_WK.pdf',
    );
  }

  Future<String> _exportPembayaranAktif() async {
    final db = DatabaseHelper.instance;
    final periode = await db.getPeriodeTagihanArisan();
    if (periode == null || periode.id == null) throw Exception('Belum ada periode aktif.');
    final data = await db.getPembayaranDetail(periode.id!);
    final pengaturan = await db.getPengaturan();
    return PdfService().exportGenericReport(
      title: 'Laporan Pembayaran Iuran ${periode.namaPeriode}',
      headers: ['No', 'Nama', 'Tanggal Bayar', 'Metode', 'Nominal', 'Status'],
      rows: [
        for (var i = 0; i < data.length; i++)
          [i + 1, data[i]['nama'], data[i]['tanggal_bayar'], data[i]['metode_bayar'], data[i]['nominal_bayar'], data[i]['status_bayar']]
      ],
      pengaturan: pengaturan,
      fileName: 'Laporan_Pembayaran_Iuran_WK.pdf',
    );
  }

  Future<String> _exportBelumBayarAktif() async {
    final db = DatabaseHelper.instance;
    final periode = await db.getPeriodeTagihanArisan();
    if (periode == null || periode.id == null) throw Exception('Belum ada periode aktif.');
    final data = await db.getAnggotaBelumBayarDetail(periode.id!);
    final pengaturan = await db.getPengaturan();
    return PdfService().exportGenericReport(
      title: 'Laporan Anggota Belum Bayar ${periode.namaPeriode}',
      headers: ['No', 'Nama', 'Nominal Iuran', 'Status'],
      rows: [
        for (var i = 0; i < data.length; i++) [i + 1, data[i]['nama'], periode.nominalIuran, 'Belum Bayar']
      ],
      pengaturan: pengaturan,
      fileName: 'Laporan_Belum_Bayar_Arisan_WK.pdf',
    );
  }

  Future<String> _exportArisanLengkap() async {
    final db = DatabaseHelper.instance;
    final data = await db.getRingkasanArisan();
    final pengaturan = await db.getPengaturan();
    return PdfService().exportGenericReport(
      title: 'Laporan Ringkasan Arisan WK',
      headers: ['No', 'Periode', 'Tanggal', 'Status', 'Peserta Bayar', 'Nominal Iuran', 'Target Peserta', 'Total Iuran', 'Pencairan', 'Saldo Arisan', 'Penerima'],
      rows: [
        for (var i = 0; i < data.length; i++)
          [
            i + 1,
            data[i]['nama_periode'],
            data[i]['tanggal_arisan'],
            data[i]['status'],
            data[i]['jumlah_peserta'],
            data[i]['nominal_iuran'],
            ((data[i]['jumlah_peserta'] as num?)?.toDouble() ?? 0) * ((data[i]['nominal_iuran'] as num?)?.toDouble() ?? 0),
            data[i]['total_iuran'],
            data[i]['total_pencairan'],
            ((data[i]['total_iuran'] as num?)?.toDouble() ?? 0) - ((data[i]['total_pencairan'] as num?)?.toDouble() ?? 0),
            data[i]['pemenang'],
          ]
      ],
      pengaturan: pengaturan,
      fileName: 'Laporan_Ringkasan_Arisan_WK.pdf',
    );
  }


  Future<String> _exportTalanganAktif() async {
    final db = DatabaseHelper.instance;
    final data = await db.getTalanganAktif();
    final pengaturan = await db.getPengaturan();
    return PdfService().exportGenericReport(
      title: 'Laporan Talangan Kas WK Aktif',
      headers: ['No', 'Periode', 'Nama', 'Tanggal', 'Nominal', 'Status Talangan', 'Catatan'],
      rows: [
        for (var i = 0; i < data.length; i++)
          [i + 1, data[i]['nama_periode'], data[i]['nama'], data[i]['tanggal_bayar'], data[i]['nominal_bayar'], data[i]['status_talangan'], data[i]['catatan']]
      ],
      pengaturan: pengaturan,
      fileName: 'Laporan_Talangan_Kas_WK_Aktif.pdf',
    );
  }

  Future<String> _exportTunggakanArisanBulanan() async {
    final db = DatabaseHelper.instance;
    final data = await db.getTunggakanArisan();
    final pengaturan = await db.getPengaturan();
    final pivotRows = _buildTunggakanPivotRows(data);
    return PdfService().exportTunggakanPivotReport(
      title: 'Laporan Belum Bayar Arisan',
      jenisIuran: 'Arisan',
      rows: pivotRows,
      pengaturan: pengaturan,
      fileName: 'Laporan_Belum_Bayar_Arisan_WK.pdf',
    );
  }

  Future<String> _exportTunggakanKasBulanan() async {
    final db = DatabaseHelper.instance;
    final data = await db.getTunggakanKas();
    final pengaturan = await db.getPengaturan();
    final pivotRows = _buildTunggakanPivotRows(data);
    return PdfService().exportTunggakanPivotReport(
      title: 'Laporan Belum Bayar Kas',
      jenisIuran: 'Kas',
      rows: pivotRows,
      pengaturan: pengaturan,
      fileName: 'Laporan_Belum_Bayar_Kas_WK.pdf',
    );
  }

  List<Map<String, dynamic>> _buildTunggakanPivotRows(List<Map<String, dynamic>> data) {
    final grouped = <String, _TunggakanGroup>{};
    for (final item in data) {
      final nama = (item['nama'] ?? '-').toString();
      final key = nama.trim().toLowerCase();
      final group = grouped.putIfAbsent(
        key,
        () => _TunggakanGroup(
          nama: nama,
        ),
      );
      final bulan = (item['bulan'] ?? '').toString();
      final nominal = (item['nominal'] as num?)?.toDouble() ?? 0;
      final status = (item['status'] ?? item['keterangan'] ?? '').toString().toLowerCase();
      final isTalangan = status.contains('talang');
      if (bulan.isNotEmpty) {
        final added = group.months.add(bulan);
        if (isTalangan) group.talanganMonths.add(bulan);
        if (added || isTalangan) group.totalNominal += nominal;
      } else {
        group.totalNominal += nominal;
      }
    }

    final groups = grouped.values.toList()
      ..sort((a, b) => a.nama.toLowerCase().compareTo(b.nama.toLowerCase()));

    return [
      for (final group in groups)
        {
          'nama': group.nama,
          'bulan_ringkas': _compactMonthRanges(group.months.toList()..sort()),
          'jumlah_bulan': group.months.length,
          'total_nominal': group.totalNominal,
          'keterangan': group.keteranganRingkas(_compactMonthRanges),
        }
    ];
  }

  String _compactMonthRanges(List<String> monthKeys) {
    if (monthKeys.isEmpty) return '-';
    final unique = monthKeys.toSet().toList()..sort();
    final values = unique.map(_monthNumber).where((value) => value > 0).toList()..sort();
    if (values.isEmpty) return unique.map(_monthNameFromKey).join(', ');

    final parts = <String>[];
    var start = values.first;
    var previous = values.first;

    void flushRange() {
      if (start == previous) {
        parts.add(_monthNameFromNumber(start));
      } else {
        parts.add('${_monthNameFromNumber(start)} - ${_monthNameFromNumber(previous)}');
      }
    }

    for (final value in values.skip(1)) {
      if (value == previous + 1) {
        previous = value;
      } else {
        flushRange();
        start = value;
        previous = value;
      }
    }
    flushRange();
    return parts.join(', ');
  }

  int _monthNumber(String monthKey) {
    if (monthKey.length < 7) return 0;
    final year = int.tryParse(monthKey.substring(0, 4)) ?? 0;
    final month = int.tryParse(monthKey.substring(5, 7)) ?? 0;
    if (year <= 0 || month <= 0 || month > 12) return 0;
    return year * 12 + month;
  }

  String _monthNameFromNumber(int value) {
    final month = ((value - 1) % 12) + 1;
    return _monthNames[month - 1];
  }

  String _monthNameFromKey(String monthKey) {
    final value = _monthNumber(monthKey);
    return value == 0 ? monthKey : _monthNameFromNumber(value);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Export Laporan PDF', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text('Laporan dibuat dalam format PDF resmi dan rapi. File disimpan ke folder Download/Arisan WK.'),
                if (_lastPath != null) ...[
                  const SizedBox(height: 12),
                  Text('File terakhir: $_lastPath', style: const TextStyle(fontSize: 12, color: Colors.black54)),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (_loading) const LinearProgressIndicator(),
        _ReportTile(title: 'Laporan Ringkasan Arisan', subtitle: 'Rekap periode, peserta bayar, total iuran, pencairan penerima arisan, dan saldo arisan.', icon: Icons.event_available, onTap: () => _runExport(_exportArisanLengkap)),
        _ReportTile(title: 'Laporan Pembayaran Iuran', subtitle: 'PDF pembayaran arisan pada periode aktif.', icon: Icons.payments, onTap: () => _runExport(_exportPembayaranAktif)),
        _ReportTile(title: 'Laporan Belum Bayar Arisan', subtitle: 'Format ringkas: contoh Natalia: Mei - Juni, total nominal, dan keterangan talangan jika ada.', icon: Icons.fact_check_outlined, onTap: () => _runExport(_exportTunggakanArisanBulanan)),
        _ReportTile(title: 'Laporan Belum Bayar Kas', subtitle: 'Format simpel: contoh Natalia: Mei - Juni, total nominal, dan keterangan singkat.', icon: Icons.receipt_long, onTap: () => _runExport(_exportTunggakanKasBulanan)),
        _ReportTile(title: 'Laporan Talangan Kas WK Aktif', subtitle: 'Daftar anggota yang iuran arisannya sudah lunas karena ditalangi Kas WK.', icon: Icons.account_balance, onTap: () => _runExport(_exportTalanganAktif)),
        _ReportTile(title: 'Laporan Penerima Arisan', subtitle: 'PDF riwayat penerima arisan.', icon: Icons.emoji_events, onTap: () => _runExport(_exportPemenang)),
        _ReportTile(title: 'Laporan Kas WK', subtitle: 'PDF mutasi kas, pemasukan, pengeluaran, dan saldo akhir.', icon: Icons.account_balance_wallet, onTap: () => _runExport(_exportKas)),
        _ReportTile(title: 'Laporan Data Anggota', subtitle: 'PDF data anggota tanpa kolom kontak dan wilayah.', icon: Icons.people, onTap: () => _runExport(_exportAnggota)),
      ],
    );
  }
}

class _ReportTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;

  const _ReportTile({required this.title, required this.subtitle, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.picture_as_pdf_outlined),
        onTap: onTap,
      ),
    );
  }
}


const _monthNames = <String>[
  'Januari',
  'Februari',
  'Maret',
  'April',
  'Mei',
  'Juni',
  'Juli',
  'Agustus',
  'September',
  'Oktober',
  'November',
  'Desember',
];

class _TunggakanGroup {
  final String nama;
  final Set<String> months = <String>{};
  final Set<String> talanganMonths = <String>{};
  double totalNominal = 0;

  _TunggakanGroup({required this.nama});

  String keteranganRingkas(String Function(List<String>) compactMonths) {
    if (talanganMonths.isEmpty) return 'Belum bayar';
    final talanganText = compactMonths(talanganMonths.toList()..sort());
    return 'Termasuk ditalangi Kas WK: $talanganText';
  }
}
