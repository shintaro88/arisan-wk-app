import 'package:flutter/material.dart';

import '../core/database/database_helper.dart';
import '../services/excel_service.dart';

class LaporanScreen extends StatefulWidget {
  const LaporanScreen({super.key});

  @override
  State<LaporanScreen> createState() => _LaporanScreenState();
}

class _LaporanScreenState extends State<LaporanScreen> {
  bool _loading = false;
  String? _lastPath;

  Future<void> _runExport(Future<String> Function() task) async {
    setState(() => _loading = true);
    try {
      final path = await task();
      if (!mounted) return;
      setState(() => _lastPath = path);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Excel berhasil dibuat: $path')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal export: $e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<String> _exportAnggota() async {
    final db = DatabaseHelper.instance;
    final data = await db.getAnggota();
    final pengaturan = await db.getPengaturan();
    return ExcelService().exportAnggota(anggota: data, pengaturan: pengaturan);
  }

  Future<String> _exportKas() async {
    final db = DatabaseHelper.instance;
    final data = await db.getKas();
    final pengaturan = await db.getPengaturan();
    return ExcelService().exportKas(transaksi: data, pengaturan: pengaturan);
  }

  Future<String> _exportPemenang() async {
    final db = DatabaseHelper.instance;
    final data = await db.getPemenangDetail();
    final pengaturan = await db.getPengaturan();
    return ExcelService().exportGenericReport(
      sheetName: 'Pemenang',
      title: 'Laporan Pemenang Arisan',
      headers: ['No', 'Periode', 'Nama', 'Tanggal', 'Nominal', 'Status'],
      rows: [
        for (var i = 0; i < data.length; i++)
          [
            i + 1,
            data[i]['nama_periode'],
            data[i]['nama'],
            data[i]['tanggal_menang'],
            data[i]['nominal_diterima'],
            data[i]['status_penerimaan'],
          ]
      ],
      pengaturan: pengaturan,
      fileName: 'Laporan_Pemenang_Arisan_WK.xlsx',
    );
  }

  Future<String> _exportPembayaranAktif() async {
    final db = DatabaseHelper.instance;
    final periode = await db.getPeriodeAktif();
    if (periode == null || periode.id == null) throw Exception('Belum ada periode aktif.');
    final data = await db.getPembayaranDetail(periode.id!);
    final pengaturan = await db.getPengaturan();
    return ExcelService().exportGenericReport(
      sheetName: 'Pembayaran',
      title: 'Laporan Pembayaran Iuran ${periode.namaPeriode}',
      headers: ['No', 'Nama', 'No HP', 'Wilayah', 'Tanggal Bayar', 'Metode', 'Nominal', 'Status'],
      rows: [
        for (var i = 0; i < data.length; i++)
          [
            i + 1,
            data[i]['nama'],
            data[i]['no_hp'],
            data[i]['wilayah'],
            data[i]['tanggal_bayar'],
            data[i]['metode_bayar'],
            data[i]['nominal_bayar'],
            data[i]['status_bayar'],
          ]
      ],
      pengaturan: pengaturan,
      fileName: 'Laporan_Pembayaran_Iuran_WK.xlsx',
    );
  }

  Future<String> _exportBelumBayarAktif() async {
    final db = DatabaseHelper.instance;
    final periode = await db.getPeriodeAktif();
    if (periode == null || periode.id == null) throw Exception('Belum ada periode aktif.');
    final data = await db.getAnggotaBelumBayarDetail(periode.id!);
    final pengaturan = await db.getPengaturan();
    return ExcelService().exportGenericReport(
      sheetName: 'Belum Bayar',
      title: 'Laporan Anggota Belum Bayar ${periode.namaPeriode}',
      headers: ['No', 'Nama', 'No HP', 'Wilayah', 'Nominal Iuran', 'Status'],
      rows: [
        for (var i = 0; i < data.length; i++)
          [
            i + 1,
            data[i]['nama'],
            data[i]['no_hp'],
            data[i]['wilayah'],
            periode.nominalIuran,
            'Belum Bayar',
          ]
      ],
      pengaturan: pengaturan,
      fileName: 'Laporan_Belum_Bayar_Arisan_WK.xlsx',
    );
  }

  Future<String> _exportArisanLengkap() async {
    final db = DatabaseHelper.instance;
    final data = await db.getRingkasanArisan();
    final pengaturan = await db.getPengaturan();
    return ExcelService().exportGenericReport(
      sheetName: 'Ringkasan Arisan',
      title: 'Laporan Ringkasan Arisan WK',
      headers: [
        'No',
        'Periode',
        'Tanggal',
        'Lokasi',
        'Status',
        'Peserta Bayar',
        'Nominal Iuran',
        'Target Peserta',
        'Total Iuran',
        'Pencairan Pemenang',
        'Saldo Arisan',
        'Pemenang',
      ],
      rows: [
        for (var i = 0; i < data.length; i++)
          [
            i + 1,
            data[i]['nama_periode'],
            data[i]['tanggal_arisan'],
            data[i]['lokasi'],
            data[i]['status'],
            data[i]['jumlah_peserta'],
            data[i]['nominal_iuran'],
            ((data[i]['jumlah_peserta'] as num?)?.toDouble() ?? 0) * ((data[i]['nominal_iuran'] as num?)?.toDouble() ?? 0),
            data[i]['total_iuran'],
            data[i]['total_pencairan'],
            ((data[i]['total_iuran'] as num?)?.toDouble() ?? 0) - ((data[i]['total_pencairan'] as num?)?.toDouble() ?? 0),
            data[i]['pemenang'],
          ]
      ],
      pengaturan: pengaturan,
      fileName: 'Laporan_Ringkasan_Arisan_WK.xlsx',
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Export Laporan Excel', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text('File Excel akan disimpan ke folder Download/Arisan WK jika perangkat mengizinkan. Jika tidak, aplikasi otomatis memakai folder aman di penyimpanan aplikasi.'),
                if (_lastPath != null) ...[
                  const SizedBox(height: 12),
                  Text('File terakhir: $_lastPath', style: const TextStyle(fontSize: 12, color: Colors.black54)),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (_loading) const LinearProgressIndicator(),
        _ReportTile(
          title: 'Laporan Ringkasan Arisan',
          subtitle: 'Rekap periode, peserta bayar, total iuran, pencairan pemenang, dan saldo arisan.',
          icon: Icons.event_available,
          onTap: () => _runExport(_exportArisanLengkap),
        ),
        _ReportTile(
          title: 'Laporan Pembayaran Iuran',
          subtitle: 'Export pembayaran arisan pada periode aktif.',
          icon: Icons.payments,
          onTap: () => _runExport(_exportPembayaranAktif),
        ),
        _ReportTile(
          title: 'Laporan Belum Bayar Arisan',
          subtitle: 'Export anggota aktif yang belum tercatat membayar pada periode aktif.',
          icon: Icons.warning_amber,
          onTap: () => _runExport(_exportBelumBayarAktif),
        ),
        _ReportTile(
          title: 'Laporan Pemenang Arisan',
          subtitle: 'Export riwayat pemenang arisan.',
          icon: Icons.emoji_events,
          onTap: () => _runExport(_exportPemenang),
        ),
        _ReportTile(
          title: 'Laporan Kas WK',
          subtitle: 'Export seluruh mutasi kas, detail pengeluaran, pemasukan, dan saldo akhir.',
          icon: Icons.account_balance_wallet,
          onTap: () => _runExport(_exportKas),
        ),
        _ReportTile(
          title: 'Laporan Data Anggota',
          subtitle: 'Export seluruh data anggota aktif dan nonaktif.',
          icon: Icons.people,
          onTap: () => _runExport(_exportAnggota),
        ),
      ],
    );
  }
}

class _ReportTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;

  const _ReportTile({required this.title, required this.subtitle, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.file_download_outlined),
        onTap: onTap,
      ),
    );
  }
}
