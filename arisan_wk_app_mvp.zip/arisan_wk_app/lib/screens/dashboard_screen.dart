import 'package:flutter/material.dart';

import '../core/database/database_helper.dart';
import '../core/utils/formatters.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int aktif = 0;
  int nonAktif = 0;
  double saldoKas = 0;
  double totalPemasukan = 0;
  double totalPengeluaran = 0;
  String periodeAktif = '-';
  String pemenangTerakhir = '-';
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = DatabaseHelper.instance;
    final pa = await db.getPeriodeAktif();
    final pt = await db.getPemenangTerakhir();
    setState(() {
      loading = false;
      periodeAktif = pa?.namaPeriode ?? '-';
      pemenangTerakhir = pt == null ? '-' : '${pt['nama']} / ${pt['nama_periode']}';
    });
    final result = await Future.wait([
      db.countAnggota('Aktif'),
      db.countAnggota('Nonaktif'),
      db.getSaldoKas(),
      db.totalKasByJenis('Pemasukan'),
      db.totalKasByJenis('Pengeluaran'),
    ]);
    if (!mounted) return;
    setState(() {
      aktif = result[0] as int;
      nonAktif = result[1] as int;
      saldoKas = result[2] as double;
      totalPemasukan = result[3] as double;
      totalPengeluaran = result[4] as double;
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Ringkasan WK', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text('Periode aktif: $periodeAktif'),
                  Text('Pemenang terakhir: $pemenangTerakhir'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: MediaQuery.of(context).size.width > 600 ? 3 : 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.25,
            children: [
              _InfoCard(title: 'Anggota Aktif', value: '$aktif', icon: Icons.people),
              _InfoCard(title: 'Anggota Nonaktif', value: '$nonAktif', icon: Icons.person_off),
              _InfoCard(title: 'Saldo Kas', value: AppFormatters.rupiah(saldoKas), icon: Icons.account_balance_wallet),
              _InfoCard(title: 'Pemasukan', value: AppFormatters.rupiah(totalPemasukan), icon: Icons.trending_up),
              _InfoCard(title: 'Pengeluaran', value: AppFormatters.rupiah(totalPengeluaran), icon: Icons.trending_down),
            ],
          ),
          const SizedBox(height: 16),
          const Text(
            'Catatan: tarik layar ke bawah untuk refresh data dashboard.',
            style: TextStyle(color: Colors.black54),
          ),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _InfoCard({required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Icon(icon, size: 32, color: Theme.of(context).colorScheme.primary),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                Text(title, style: const TextStyle(color: Colors.black54)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
