import 'package:flutter/material.dart';

import '../core/database/database_helper.dart';
import '../core/utils/formatters.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int aktif = 0;
  int nonAktif = 0;
  int ikutArisan = 0;
  int ikutKas = 0;
  int sudahBayarArisan = 0;
  int belumBayarArisan = 0;
  double saldoKas = 0;
  double totalPemasukan = 0;
  double totalPengeluaran = 0;
  double totalIuranAktif = 0;
  double pencairanAktif = 0;
  String periodeAktif = '-';
  String pemenangTerakhir = '-';
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = DatabaseHelper.instance;
    final pa = await db.getPeriodeAktif();
    final pt = await db.getPemenangTerakhir();
    var sudah = 0;
    var belum = 0;
    var iuran = 0.0;
    var pencairan = 0.0;
    if (pa?.id != null) {
      sudah = await db.countPembayaranStatus(pa!.id!, 'Sudah Bayar');
      final belumList = await db.getAnggotaBelumBayar(pa.id!);
      belum = belumList.length;
      iuran = await db.totalIuranPeriode(pa.id!);
      pencairan = await db.totalPencairanPeriode(pa.id!);
    }

    final result = await Future.wait([
      db.countAnggota('Aktif'),
      db.countAnggota('Nonaktif'),
      db.countAnggotaIkut(jenis: 'arisan'),
      db.countAnggotaIkut(jenis: 'kas'),
      db.getSaldoKas(),
      db.totalKasByJenis('Pemasukan'),
      db.totalKasByJenis('Pengeluaran'),
    ]);
    if (!mounted) return;
    setState(() {
      aktif = result[0] as int;
      nonAktif = result[1] as int;
      ikutArisan = result[2] as int;
      ikutKas = result[3] as int;
      saldoKas = result[4] as double;
      totalPemasukan = result[5] as double;
      totalPengeluaran = result[6] as double;
      sudahBayarArisan = sudah;
      belumBayarArisan = belum;
      totalIuranAktif = iuran;
      pencairanAktif = pencairan;
      periodeAktif = pa?.namaPeriode ?? '-';
      pemenangTerakhir = pt == null ? '-' : '${pt['nama']} / ${pt['nama_periode']}';
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());
    final saldoArisan = totalIuranAktif - pencairanAktif;
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Ringkasan WK', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text('Periode aktif: $periodeAktif'),
                  Text('Pemenang terakhir: $pemenangTerakhir'),
                  const SizedBox(height: 8),
                  const Text('Angka dashboard otomatis mengikuti data anggota, pembayaran iuran, kas, dan pemenang arisan.', style: TextStyle(fontSize: 12, color: Colors.black54)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: MediaQuery.of(context).size.width > 600 ? 3 : 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.25,
            children: [
              _InfoCard(title: 'Anggota Aktif', value: '$aktif', icon: Icons.people),
              _InfoCard(title: 'Ikut Arisan', value: '$ikutArisan', icon: Icons.groups),
              _InfoCard(title: 'Ikut Kas', value: '$ikutKas', icon: Icons.savings),
              _InfoCard(title: 'Sudah Bayar Arisan', value: '$sudahBayarArisan', icon: Icons.check_circle),
              _InfoCard(title: 'Belum Bayar Arisan', value: '$belumBayarArisan', icon: Icons.warning_amber),
              _InfoCard(title: 'Total Iuran Arisan', value: AppFormatters.rupiah(totalIuranAktif), icon: Icons.payments),
              _InfoCard(title: 'Saldo Arisan Aktif', value: AppFormatters.rupiah(saldoArisan), icon: Icons.event_available),
              _InfoCard(title: 'Saldo Kas', value: AppFormatters.rupiah(saldoKas), icon: Icons.account_balance_wallet),
              _InfoCard(title: 'Pemasukan Kas', value: AppFormatters.rupiah(totalPemasukan), icon: Icons.trending_up),
              _InfoCard(title: 'Pengeluaran Kas', value: AppFormatters.rupiah(totalPengeluaran), icon: Icons.trending_down),
              _InfoCard(title: 'Anggota Nonaktif', value: '$nonAktif', icon: Icons.person_off),
            ],
          ),
          const SizedBox(height: 16),
          const Text('Tarik layar ke bawah untuk refresh data dashboard.', style: TextStyle(color: Colors.black54)),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _InfoCard({required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Icon(icon, size: 32, color: Theme.of(context).colorScheme.primary),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis),
                Text(title, style: const TextStyle(color: Colors.black54), maxLines: 2),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
