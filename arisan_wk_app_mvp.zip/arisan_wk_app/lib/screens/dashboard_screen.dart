import 'package:flutter/material.dart';

import '../core/database/database_helper.dart';
import '../core/utils/formatters.dart';
import '../models/anggota_model.dart';
import '../models/kas_model.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int aktif = 0;
  int nonAktif = 0;
  int ikutArisan = 0;
  int ikutKas = 0;
  int sudahBayarArisan = 0;
  int belumBayarArisan = 0;
  double saldoKas = 0;
  double totalPemasukan = 0;
  double totalPengeluaran = 0;
  double totalIuranAktif = 0;
  double pencairanAktif = 0;
  String periodeAktif = '-';
  String penerimaArisanTerakhir = '-';
  int? periodeAktifId;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = DatabaseHelper.instance;
    final pa = await db.getPeriodeAktif();
    final pt = await db.getPemenangTerakhir();
    var sudah = 0;
    var belum = 0;
    var iuran = 0.0;
    var pencairan = 0.0;
    if (pa?.id != null) {
      sudah = await db.countPembayaranStatus(pa!.id!, 'Sudah Bayar');
      final belumList = await db.getAnggotaBelumBayar(pa.id!);
      belum = belumList.length;
      iuran = await db.totalIuranPeriode(pa.id!);
      pencairan = await db.totalPencairanPeriode(pa.id!);
    }

    final result = await Future.wait([
      db.countAnggota('Aktif'),
      db.countAnggota('Nonaktif'),
      db.countAnggotaIkut(jenis: 'arisan'),
      db.countAnggotaIkut(jenis: 'kas'),
      db.getSaldoKas(),
      db.totalKasByJenis('Pemasukan'),
      db.totalKasByJenis('Pengeluaran'),
    ]);
    if (!mounted) return;
    setState(() {
      aktif = result[0] as int;
      nonAktif = result[1] as int;
      ikutArisan = result[2] as int;
      ikutKas = result[3] as int;
      saldoKas = result[4] as double;
      totalPemasukan = result[5] as double;
      totalPengeluaran = result[6] as double;
      sudahBayarArisan = sudah;
      belumBayarArisan = belum;
      totalIuranAktif = iuran;
      pencairanAktif = pencairan;
      periodeAktif = pa?.namaPeriode ?? '-';
      periodeAktifId = pa?.id;
      penerimaArisanTerakhir = pt == null ? '-' : '${pt['nama']} / ${pt['nama_periode']}';
      loading = false;
    });
  }

  String _memberLines(List<Anggota> members) {
    if (members.isEmpty) return 'Tidak ada data.';
    return members.map((a) => '• ${a.nama}${a.wilayah.isNotEmpty ? ' - ${a.wilayah}' : ''}').join('
');
  }

  String _paymentLines(List<Map<String, dynamic>> payments) {
    if (payments.isEmpty) return 'Tidak ada data pembayaran pada periode aktif.';
    return payments.map((p) {
      final nama = p['nama'] ?? '-';
      final status = p['status_bayar'] ?? '-';
      final nominal = AppFormatters.rupiah((p['nominal_bayar'] as num?)?.toDouble() ?? 0);
      return '• $nama - $status - $nominal';
    }).join('
');
  }

  String _kasLines(List<KasTransaksi> transaksi, String jenis) {
    final filtered = transaksi.where((k) => k.jenisTransaksi == jenis).toList();
    if (filtered.isEmpty) return 'Belum ada transaksi $jenis.';
    return filtered.take(20).map((k) {
      return '• ${k.tanggalTransaksi} - ${k.kategori} - ${AppFormatters.rupiah(k.nominal)}
  ${k.keterangan}';
    }).join('
');
  }

  Future<void> _showDetail(String title, Future<String> Function() contentBuilder) async {
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (context) => const AlertDialog(
        content: Row(
          children: [
            SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2)),
            SizedBox(width: 16),
            Expanded(child: Text('Mengambil detail data...')),
          ],
        ),
      ),
    );

    String content;
    try {
      content = await contentBuilder();
    } catch (e) {
      content = 'Detail gagal dimuat: ${e.toString()}';
    }

    if (!mounted) return;
    Navigator.pop(context);
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 520),
          child: SingleChildScrollView(child: Text(content)),
        ),
        actions: [
          FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Tutup')),
        ],
      ),
    );
  }

  Future<String> _detailAnggotaAktif() async {
    final members = await DatabaseHelper.instance.getAnggota(status: 'Aktif');
    return 'Total anggota aktif: $aktif

Daftar anggota:
${_memberLines(members)}';
  }

  Future<String> _detailAnggotaNonAktif() async {
    final members = await DatabaseHelper.instance.getAnggota(status: 'Nonaktif');
    return 'Total anggota nonaktif: $nonAktif

Daftar anggota:
${_memberLines(members)}';
  }

  Future<String> _detailIkutArisan() async {
    final members = await DatabaseHelper.instance.getAnggotaIkutArisan();
    return 'Total anggota ikut arisan: $ikutArisan

Daftar anggota:
${_memberLines(members)}';
  }

  Future<String> _detailIkutKas() async {
    final members = await DatabaseHelper.instance.getAnggotaIkutKas();
    return 'Total anggota ikut kas: $ikutKas

Daftar anggota:
${_memberLines(members)}';
  }

  Future<String> _detailPembayaran() async {
    if (periodeAktifId == null) return 'Belum ada periode arisan aktif.';
    final payments = await DatabaseHelper.instance.getPembayaranDetail(periodeAktifId!);
    return 'Periode aktif: $periodeAktif
Total sudah bayar: $sudahBayarArisan
Total iuran masuk: ${AppFormatters.rupiah(totalIuranAktif)}

Daftar pembayaran:
${_paymentLines(payments)}';
  }

  Future<String> _detailBelumBayar() async {
    if (periodeAktifId == null) return 'Belum ada periode arisan aktif.';
    final members = await DatabaseHelper.instance.getAnggotaBelumBayar(periodeAktifId!);
    return 'Periode aktif: $periodeAktif
Total belum bayar: $belumBayarArisan

Daftar belum bayar:
${_memberLines(members)}';
  }

  Future<String> _detailSaldoArisan() async {
    final saldoArisan = totalIuranAktif - pencairanAktif;
    return 'Periode aktif: $periodeAktif

Total iuran terkumpul: ${AppFormatters.rupiah(totalIuranAktif)}
Total pencairan penerima arisan: ${AppFormatters.rupiah(pencairanAktif)}
Saldo arisan aktif: ${AppFormatters.rupiah(saldoArisan)}

Catatan: saldo arisan otomatis berkurang setelah penerima arisan dicatat dengan status penerimaan Sudah Diterima.';
  }

  Future<String> _detailKas(String jenis) async {
    final transaksi = await DatabaseHelper.instance.getKas();
    final total = jenis == 'Pemasukan' ? totalPemasukan : totalPengeluaran;
    return 'Total $jenis kas: ${AppFormatters.rupiah(total)}
Saldo kas saat ini: ${AppFormatters.rupiah(saldoKas)}

Transaksi terbaru:
${_kasLines(transaksi, jenis)}';
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());
    final saldoArisan = totalIuranAktif - pencairanAktif;
    final width = MediaQuery.of(context).size.width;
    final crossAxisCount = width >= 1200 ? 4 : width >= 800 ? 3 : 2;
    final childRatio = width >= 1200 ? 1.85 : width >= 800 ? 1.6 : 1.35;
    final arisanProgress = ikutArisan == 0 ? 0.0 : (sudahBayarArisan / ikutArisan).clamp(0.0, 1.0);
    final kasProgress = ikutKas == 0 ? 0.0 : ((ikutKas - belumBayarArisan) / ikutKas).clamp(0.0, 1.0);

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _DashboardHeader(
            periodeAktif: periodeAktif,
            penerimaTerakhir: penerimaArisanTerakhir,
            saldoKas: saldoKas,
            saldoArisan: saldoArisan,
            arisanProgress: arisanProgress,
            kasProgress: kasProgress,
          ),
          const SizedBox(height: 14),
          GridView.count(
            crossAxisCount: crossAxisCount,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: childRatio,
            children: [
              _InfoCard(title: 'Anggota Aktif', value: '$aktif', icon: Icons.people, accent: const Color(0xFF7E57C2), subtitle: 'Total aktif', onTap: () => _showDetail('Detail Anggota Aktif', _detailAnggotaAktif)),
              _InfoCard(title: 'Ikut Arisan', value: '$ikutArisan', icon: Icons.groups, accent: const Color(0xFF5C6BC0), subtitle: 'Peserta arisan', onTap: () => _showDetail('Detail Anggota Ikut Arisan', _detailIkutArisan)),
              _InfoCard(title: 'Ikut Kas', value: '$ikutKas', icon: Icons.savings, accent: const Color(0xFF42A5F5), subtitle: 'Peserta kas', onTap: () => _showDetail('Detail Anggota Ikut Kas', _detailIkutKas)),
              _InfoCard(title: 'Belum Bayar Arisan', value: '$belumBayarArisan', icon: Icons.warning_amber_rounded, accent: const Color(0xFFF9A825), subtitle: periodeAktif, onTap: () => _showDetail('Detail Belum Bayar Arisan', _detailBelumBayar)),
              _InfoCard(title: 'Total Iuran Arisan', value: AppFormatters.rupiah(totalIuranAktif), icon: Icons.payments, accent: const Color(0xFF8E24AA), subtitle: 'Masuk periode aktif', onTap: () => _showDetail('Detail Total Iuran Arisan', _detailPembayaran)),
              _InfoCard(title: 'Saldo Arisan Aktif', value: AppFormatters.rupiah(saldoArisan), icon: Icons.event_available, accent: const Color(0xFF6D4C41), subtitle: 'Setelah pencairan', onTap: () => _showDetail('Detail Saldo Arisan Aktif', _detailSaldoArisan)),
              _InfoCard(title: 'Saldo Kas', value: AppFormatters.rupiah(saldoKas), icon: Icons.account_balance_wallet, accent: const Color(0xFF26A69A), subtitle: 'Kas berjalan', onTap: () => _showDetail('Detail Saldo Kas', () => _detailKas('Pemasukan'))),
              _InfoCard(title: 'Pemasukan Kas', value: AppFormatters.rupiah(totalPemasukan), icon: Icons.trending_up, accent: const Color(0xFF66BB6A), subtitle: 'Total pemasukan', onTap: () => _showDetail('Detail Pemasukan Kas', () => _detailKas('Pemasukan'))),
              _InfoCard(title: 'Pengeluaran Kas', value: AppFormatters.rupiah(totalPengeluaran), icon: Icons.trending_down, accent: const Color(0xFFEF5350), subtitle: 'Total pengeluaran', onTap: () => _showDetail('Detail Pengeluaran Kas', () => _detailKas('Pengeluaran'))),
              _InfoCard(title: 'Anggota Nonaktif', value: '$nonAktif', icon: Icons.person_off, accent: const Color(0xFF90A4AE), subtitle: 'Tidak aktif', onTap: () => _showDetail('Detail Anggota Nonaktif', _detailAnggotaNonAktif)),
            ],
          ),
          const SizedBox(height: 12),
          const Text(
            'Dashboard dibuat lebih ringkas supaya tidak terlalu panjang di-scroll. Ketuk setiap kartu untuk melihat detail.',
            style: TextStyle(color: Colors.black54),
          ),
        ],
      ),
    );
  }
}

class _DashboardHeader extends StatelessWidget {
  final String periodeAktif;
  final String penerimaTerakhir;
  final double saldoKas;
  final double saldoArisan;
  final double arisanProgress;
  final double kasProgress;

  const _DashboardHeader({
    required this.periodeAktif,
    required this.penerimaTerakhir,
    required this.saldoKas,
    required this.saldoArisan,
    required this.arisanProgress,
    required this.kasProgress,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF7B61C9), Color(0xFFA48BD8)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Dashboard Arisan WK',
            style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          Text('Periode aktif: $periodeAktif', style: const TextStyle(color: Colors.white70)),
          Text('Penerima arisan terakhir: $penerimaTerakhir', style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _MiniSummaryCard(
                  title: 'Saldo Kas',
                  value: AppFormatters.rupiah(saldoKas),
                  icon: Icons.account_balance_wallet_outlined,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _MiniSummaryCard(
                  title: 'Saldo Arisan',
                  value: AppFormatters.rupiah(saldoArisan),
                  icon: Icons.event_available_outlined,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _ProgressInfo(label: 'Progress Arisan', value: arisanProgress),
          const SizedBox(height: 8),
          _ProgressInfo(label: 'Progress Kas', value: kasProgress),
        ],
      ),
    );
  }
}

class _MiniSummaryCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _MiniSummaryCard({required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withValues(alpha: 0.18)),
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.white, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.white70, fontSize: 12)),
                const SizedBox(height: 2),
                Text(value, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700), maxLines: 1, overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ProgressInfo extends StatelessWidget {
  final String label;
  final double value;

  const _ProgressInfo({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
            Text('${(value * 100).toStringAsFixed(0)}%', style: const TextStyle(color: Colors.white70)),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(99),
          child: LinearProgressIndicator(
            value: value,
            minHeight: 8,
            backgroundColor: Colors.white.withValues(alpha: 0.18),
            valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
          ),
        ),
      ],
    );
  }
}

class _InfoCard extends StatelessWidget {
  final String title;
  final String value;
  final String subtitle;
  final IconData icon;
  final Color accent;
  final VoidCallback? onTap;

  const _InfoCard({required this.title, required this.value, required this.icon, required this.accent, required this.subtitle, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.zero,
      elevation: 1.5,
      shadowColor: Colors.black.withValues(alpha: 0.06),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [accent.withValues(alpha: 0.14), Colors.white],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: accent.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(icon, size: 20, color: accent),
                    ),
                    const Spacer(),
                    Icon(Icons.touch_app_outlined, size: 16, color: Colors.grey.shade500),
                  ],
                ),
                const Spacer(),
                Text(
                  value,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(title, style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600), maxLines: 2),
                const SizedBox(height: 2),
                Text(subtitle, style: const TextStyle(color: Colors.black54, fontSize: 11.5), maxLines: 1, overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
