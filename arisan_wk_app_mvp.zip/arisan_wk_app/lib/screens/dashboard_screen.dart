import 'package:flutter/material.dart';

import '../core/database/database_helper.dart';
import '../core/utils/formatters.dart';
import '../models/anggota_model.dart';
import '../models/kas_model.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int aktif = 0;
  int nonAktif = 0;
  int ikutArisan = 0;
  int ikutKas = 0;
  int sudahBayarArisan = 0;
  int belumBayarArisan = 0;
  int sudahBayarKasBulanIni = 0;
  int belumBayarKasBulanIni = 0;
  int talanganAktifCount = 0;
  double saldoKas = 0;
  double totalPemasukan = 0;
  double totalPengeluaran = 0;
  double totalIuranAktif = 0;
  double pencairanAktif = 0;
  double talanganAktifTotal = 0;
  String periodeAktif = '-';
  String penerimaArisanTerakhir = '-';
  int? periodeAktifId;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = DatabaseHelper.instance;
    final pa = await db.getPeriodeAktif();
    final pt = await db.getPemenangTerakhir();
    final today = DateTime.now().toIso8601String().substring(0, 10);

    var sudahArisan = 0;
    var belumArisan = 0;
    var iuran = 0.0;
    var pencairan = 0.0;
    if (pa?.id != null) {
      sudahArisan = await db.countPembayaranStatus(pa!.id!, 'Sudah Bayar');
      final belumList = await db.getAnggotaBelumBayar(pa.id!);
      belumArisan = belumList.length;
      iuran = await db.totalIuranPeriode(pa.id!);
      pencairan = await db.totalPencairanPeriode(pa.id!);
    }

    final result = await Future.wait<dynamic>([
      db.countAnggota('Aktif'),
      db.countAnggota('Nonaktif'),
      db.countAnggotaIkut(jenis: 'arisan'),
      db.countAnggotaIkut(jenis: 'kas'),
      db.getSaldoKas(),
      db.totalKasByJenis('Pemasukan'),
      db.totalKasByJenis('Pengeluaran'),
      db.getPembayaranKasDetail(today),
      db.getAnggotaBelumBayarKas(today),
      db.getTalanganAktif(),
    ]);

    final bayarKas = result[7] as List<Map<String, dynamic>>;
    final belumKas = result[8] as List<Anggota>;
    final talangan = result[9] as List<Map<String, dynamic>>;
    final totalTalangan = talangan.fold<double>(0, (sum, item) => sum + ((item['nominal_bayar'] as num?)?.toDouble() ?? 0));

    if (!mounted) return;
    setState(() {
      aktif = result[0] as int;
      nonAktif = result[1] as int;
      ikutArisan = result[2] as int;
      ikutKas = result[3] as int;
      saldoKas = result[4] as double;
      totalPemasukan = result[5] as double;
      totalPengeluaran = result[6] as double;
      sudahBayarKasBulanIni = bayarKas.length;
      belumBayarKasBulanIni = belumKas.length;
      talanganAktifCount = talangan.length;
      talanganAktifTotal = totalTalangan;
      sudahBayarArisan = sudahArisan;
      belumBayarArisan = belumArisan;
      totalIuranAktif = iuran;
      pencairanAktif = pencairan;
      periodeAktif = pa?.namaPeriode ?? '-';
      periodeAktifId = pa?.id;
      penerimaArisanTerakhir = pt == null ? '-' : '${pt['nama']} / ${pt['nama_periode']}';
      loading = false;
    });
  }

  String _memberLines(List<Anggota> members) {
    if (members.isEmpty) return 'Tidak ada data.';
    return members.map((a) => '• ${a.nama}${a.wilayah.isNotEmpty ? ' - ${a.wilayah}' : ''}').join('\n');
  }

  String _paymentLines(List<Map<String, dynamic>> payments) {
    if (payments.isEmpty) return 'Tidak ada data pembayaran pada periode aktif.';
    return payments.map((p) {
      final nama = p['nama'] ?? '-';
      final status = p['status_bayar'] ?? '-';
      final nominal = AppFormatters.rupiah((p['nominal_bayar'] as num?)?.toDouble() ?? 0);
      final sumber = p['sumber_bayar']?.toString() ?? 'Pribadi';
      return '• $nama - $status - $nominal${sumber == 'Ditalangi Kas WK' ? ' - Ditalangi Kas WK' : ''}';
    }).join('\n');
  }

  String _kasLines(List<KasTransaksi> transaksi, String jenis) {
    final filtered = transaksi.where((k) => k.jenisTransaksi == jenis).toList();
    if (filtered.isEmpty) return 'Belum ada transaksi $jenis.';
    return filtered.take(20).map((k) {
      return '• ${k.tanggalTransaksi} - ${k.kategori} - ${AppFormatters.rupiah(k.nominal)}\n  ${k.keterangan}';
    }).join('\n');
  }

  String _talanganLines(List<Map<String, dynamic>> rows) {
    if (rows.isEmpty) return 'Tidak ada talangan aktif.';
    return rows.map((r) {
      final nominal = AppFormatters.rupiah((r['nominal_bayar'] as num?)?.toDouble() ?? 0);
      return '• ${r['nama']} - ${r['nama_periode']} - $nominal';
    }).join('\n');
  }

  Future<void> _showDetail(String title, Future<String> Function() contentBuilder) async {
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (context) => const AlertDialog(
        content: Row(
          children: [
            SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2)),
            SizedBox(width: 16),
            Expanded(child: Text('Mengambil detail data...')),
          ],
        ),
      ),
    );

    String content;
    try {
      content = await contentBuilder();
    } catch (e) {
      content = 'Detail gagal dimuat: ${e.toString()}';
    }

    if (!mounted) return;
    Navigator.pop(context);
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 540),
          child: SingleChildScrollView(child: Text(content)),
        ),
        actions: [
          FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Tutup')),
        ],
      ),
    );
  }

  Future<String> _detailAnggotaAktif() async {
    final members = await DatabaseHelper.instance.getAnggota(status: 'Aktif');
    return 'Total anggota aktif: $aktif\n\nDaftar anggota:\n${_memberLines(members)}';
  }

  Future<String> _detailAnggotaNonAktif() async {
    final members = await DatabaseHelper.instance.getAnggota(status: 'Nonaktif');
    return 'Total anggota nonaktif: $nonAktif\n\nDaftar anggota:\n${_memberLines(members)}';
  }

  Future<String> _detailIkutArisan() async {
    final members = await DatabaseHelper.instance.getAnggotaIkutArisan();
    return 'Total anggota ikut arisan: $ikutArisan\n\nDaftar anggota:\n${_memberLines(members)}';
  }

  Future<String> _detailIkutKas() async {
    final members = await DatabaseHelper.instance.getAnggotaIkutKas();
    return 'Total anggota ikut kas: $ikutKas\n\nDaftar anggota:\n${_memberLines(members)}';
  }

  Future<String> _detailPembayaran() async {
    if (periodeAktifId == null) return 'Belum ada periode arisan aktif.';
    final payments = await DatabaseHelper.instance.getPembayaranDetail(periodeAktifId!);
    return 'Periode aktif: $periodeAktif\nTotal sudah bayar: $sudahBayarArisan\nTotal iuran masuk: ${AppFormatters.rupiah(totalIuranAktif)}\n\nDaftar pembayaran:\n${_paymentLines(payments)}';
  }

  Future<String> _detailBelumBayar() async {
    if (periodeAktifId == null) return 'Belum ada periode arisan aktif.';
    final members = await DatabaseHelper.instance.getAnggotaBelumBayar(periodeAktifId!);
    return 'Periode aktif: $periodeAktif\nTotal belum bayar arisan: $belumBayarArisan\n\nDaftar belum bayar:\n${_memberLines(members)}';
  }

  Future<String> _detailBelumBayarKas() async {
    final members = await DatabaseHelper.instance.getAnggotaBelumBayarKas(DateTime.now().toIso8601String().substring(0, 10));
    return 'Bulan berjalan\nTotal belum bayar kas: $belumBayarKasBulanIni\n\nDaftar belum bayar kas:\n${_memberLines(members)}';
  }

  Future<String> _detailTalanganAktif() async {
    final rows = await DatabaseHelper.instance.getTalanganAktif();
    return 'Total anggota masih ditalangi: $talanganAktifCount\nTotal nilai talangan aktif: ${AppFormatters.rupiah(talanganAktifTotal)}\n\nDaftar talangan aktif:\n${_talanganLines(rows)}';
  }

  Future<String> _detailSaldoArisan() async {
    final saldoArisan = totalIuranAktif - pencairanAktif;
    return 'Periode aktif: $periodeAktif\n\nTotal iuran terkumpul: ${AppFormatters.rupiah(totalIuranAktif)}\nTotal pencairan penerima arisan: ${AppFormatters.rupiah(pencairanAktif)}\nSaldo arisan aktif: ${AppFormatters.rupiah(saldoArisan)}\n\nCatatan: saldo arisan otomatis berkurang setelah penerima arisan dicatat dengan status penerimaan Sudah Diterima.';
  }

  Future<String> _detailKas(String jenis) async {
    final transaksi = await DatabaseHelper.instance.getKas();
    final total = jenis == 'Pemasukan' ? totalPemasukan : totalPengeluaran;
    return 'Total $jenis kas: ${AppFormatters.rupiah(total)}\nSaldo kas saat ini: ${AppFormatters.rupiah(saldoKas)}\n\nTransaksi terbaru:\n${_kasLines(transaksi, jenis)}';
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());
    final saldoArisan = totalIuranAktif - pencairanAktif;
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          _HeaderCard(periodeAktif: periodeAktif, penerimaArisanTerakhir: penerimaArisanTerakhir),
          const SizedBox(height: 12),
          RepaintBoundary(
            child: _DashboardGraphPanel(
              sudahBayarArisan: sudahBayarArisan,
              belumBayarArisan: belumBayarArisan,
              sudahBayarKas: sudahBayarKasBulanIni,
              belumBayarKas: belumBayarKasBulanIni,
              pemasukanKas: totalPemasukan,
              pengeluaranKas: totalPengeluaran,
              saldoKas: saldoKas,
              totalTalangan: talanganAktifTotal,
            ),
          ),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: MediaQuery.of(context).size.width > 680 ? 3 : 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: MediaQuery.of(context).size.width > 680 ? 1.35 : 1.18,
            children: [
              _InfoCard(title: 'Anggota Aktif', value: '$aktif', icon: Icons.people, onTap: () => _showDetail('Detail Anggota Aktif', _detailAnggotaAktif)),
              _InfoCard(title: 'Ikut Arisan', value: '$ikutArisan', icon: Icons.groups, onTap: () => _showDetail('Detail Anggota Ikut Arisan', _detailIkutArisan)),
              _InfoCard(title: 'Ikut Kas', value: '$ikutKas', icon: Icons.savings, onTap: () => _showDetail('Detail Anggota Ikut Kas', _detailIkutKas)),
              _InfoCard(title: 'Belum Bayar Arisan', value: '$belumBayarArisan', icon: Icons.warning_amber, onTap: () => _showDetail('Detail Belum Bayar Arisan', _detailBelumBayar)),
              _InfoCard(title: 'Belum Bayar Kas', value: '$belumBayarKasBulanIni', icon: Icons.pending_actions, onTap: () => _showDetail('Detail Belum Bayar Kas', _detailBelumBayarKas)),
              _InfoCard(title: 'Talangan Aktif', value: '$talanganAktifCount orang', icon: Icons.account_balance, onTap: () => _showDetail('Detail Talangan Aktif', _detailTalanganAktif)),
              _InfoCard(title: 'Total Iuran Arisan', value: AppFormatters.rupiah(totalIuranAktif), icon: Icons.payments, onTap: () => _showDetail('Detail Total Iuran Arisan', _detailPembayaran)),
              _InfoCard(title: 'Saldo Arisan Aktif', value: AppFormatters.rupiah(saldoArisan), icon: Icons.event_available, onTap: () => _showDetail('Detail Saldo Arisan Aktif', _detailSaldoArisan)),
              _InfoCard(title: 'Saldo Kas', value: AppFormatters.rupiah(saldoKas), icon: Icons.account_balance_wallet, onTap: () => _showDetail('Detail Saldo Kas', () => _detailKas('Pemasukan'))),
              _InfoCard(title: 'Pemasukan Kas', value: AppFormatters.rupiah(totalPemasukan), icon: Icons.trending_up, onTap: () => _showDetail('Detail Pemasukan Kas', () => _detailKas('Pemasukan'))),
              _InfoCard(title: 'Pengeluaran Kas', value: AppFormatters.rupiah(totalPengeluaran), icon: Icons.trending_down, onTap: () => _showDetail('Detail Pengeluaran Kas', () => _detailKas('Pengeluaran'))),
              _InfoCard(title: 'Anggota Nonaktif', value: '$nonAktif', icon: Icons.person_off, onTap: () => _showDetail('Detail Anggota Nonaktif', _detailAnggotaNonAktif)),
            ],
          ),
          const SizedBox(height: 16),
          const Text('Tarik layar ke bawah untuk refresh data dashboard.', style: TextStyle(color: Colors.black54)),
        ],
      ),
    );
  }
}

class _HeaderCard extends StatelessWidget {
  final String periodeAktif;
  final String penerimaArisanTerakhir;

  const _HeaderCard({required this.periodeAktif, required this.penerimaArisanTerakhir});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Dashboard Monitoring WK', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('Periode aktif: $periodeAktif'),
            Text('Penerima arisan terakhir: $penerimaArisanTerakhir'),
            const SizedBox(height: 8),
            const Text('Semua ringkasan utama ditampilkan di sini. Ketuk kotak untuk melihat detail.', style: TextStyle(fontSize: 12, color: Colors.black54)),
          ],
        ),
      ),
    );
  }
}

class _DashboardGraphPanel extends StatelessWidget {
  final int sudahBayarArisan;
  final int belumBayarArisan;
  final int sudahBayarKas;
  final int belumBayarKas;
  final double pemasukanKas;
  final double pengeluaranKas;
  final double saldoKas;
  final double totalTalangan;

  const _DashboardGraphPanel({
    required this.sudahBayarArisan,
    required this.belumBayarArisan,
    required this.sudahBayarKas,
    required this.belumBayarKas,
    required this.pemasukanKas,
    required this.pengeluaranKas,
    required this.saldoKas,
    required this.totalTalangan,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final twoColumns = constraints.maxWidth > 680;
        final children = [
          _GraphCard(
            title: 'Progress Pembayaran',
            subtitle: 'Arisan aktif dan kas bulan berjalan',
            child: Column(
              children: [
                _ProgressRow(label: 'Arisan lunas', done: sudahBayarArisan, pending: belumBayarArisan),
                const SizedBox(height: 12),
                _ProgressRow(label: 'Kas lunas', done: sudahBayarKas, pending: belumBayarKas),
              ],
            ),
          ),
          _GraphCard(
            title: 'Grafik Nilai Kas',
            subtitle: 'Pemasukan, pengeluaran, saldo, dan talangan aktif',
            child: _AmountBarChart(values: [
              _AmountItem('Masuk', pemasukanKas),
              _AmountItem('Keluar', pengeluaranKas),
              _AmountItem('Saldo', saldoKas < 0 ? 0 : saldoKas),
              _AmountItem('Talangan', totalTalangan),
            ]),
          ),
        ];
        if (!twoColumns) {
          return Column(children: [children[0], const SizedBox(height: 12), children[1]]);
        }
        return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(child: children[0]),
          const SizedBox(width: 12),
          Expanded(child: children[1]),
        ]);
      },
    );
  }
}

class _GraphCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;

  const _GraphCard({required this.title, required this.subtitle, required this.child});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 2),
            Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.black54)),
            const SizedBox(height: 14),
            child,
          ],
        ),
      ),
    );
  }
}

class _ProgressRow extends StatelessWidget {
  final String label;
  final int done;
  final int pending;

  const _ProgressRow({required this.label, required this.done, required this.pending});

  @override
  Widget build(BuildContext context) {
    final total = done + pending;
    final progress = total <= 0 ? 0.0 : done / total;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600))),
            Text('$done lunas • $pending belum', style: const TextStyle(fontSize: 12, color: Colors.black54)),
          ],
        ),
        const SizedBox(height: 7),
        ClipRRect(
          borderRadius: BorderRadius.circular(999),
          child: LinearProgressIndicator(
            value: progress,
            minHeight: 12,
            backgroundColor: Colors.orange.shade100,
            valueColor: AlwaysStoppedAnimation<Color>(Colors.green.shade400),
          ),
        ),
      ],
    );
  }
}

class _AmountItem {
  final String label;
  final double value;

  const _AmountItem(this.label, this.value);
}

class _AmountBarChart extends StatelessWidget {
  final List<_AmountItem> values;

  const _AmountBarChart({required this.values});

  @override
  Widget build(BuildContext context) {
    final maxValue = values.fold<double>(0, (max, item) => item.value > max ? item.value : max);
    return Column(
      children: values.map((item) {
        final pct = maxValue <= 0 ? 0.0 : (item.value / maxValue).clamp(0.0, 1.0);
        return Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Row(
            children: [
              SizedBox(width: 70, child: Text(item.label, style: const TextStyle(fontSize: 12))),
              Expanded(
                child: Stack(
                  children: [
                    Container(height: 20, decoration: BoxDecoration(color: Colors.blueGrey.shade50, borderRadius: BorderRadius.circular(999))),
                    FractionallySizedBox(
                      widthFactor: pct,
                      child: Container(height: 20, decoration: BoxDecoration(color: Colors.blue.shade200, borderRadius: BorderRadius.circular(999))),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              SizedBox(width: 96, child: Text(AppFormatters.rupiah(item.value), textAlign: TextAlign.right, style: const TextStyle(fontSize: 11))),
            ],
          ),
        );
      }).toList(),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final VoidCallback? onTap;

  const _InfoCard({required this.title, required this.value, required this.icon, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(icon, size: 30, color: Theme.of(context).colorScheme.primary),
                  Icon(Icons.touch_app_outlined, size: 17, color: Colors.grey.shade500),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(value, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis),
                  Text(title, style: const TextStyle(color: Colors.black54), maxLines: 2, overflow: TextOverflow.ellipsis),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
