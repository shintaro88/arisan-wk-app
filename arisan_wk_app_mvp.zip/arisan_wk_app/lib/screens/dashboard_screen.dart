import 'package:flutter/material.dart';

import '../core/database/database_helper.dart';
import '../core/utils/formatters.dart';
import '../models/anggota_model.dart';
import '../models/kas_model.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int aktif = 0;
  int nonAktif = 0;
  int ikutArisan = 0;
  int ikutKas = 0;
  int sudahBayarArisan = 0;
  int belumBayarArisan = 0;
  int sudahBayarKasBulanIni = 0;
  int belumBayarKasBulanIni = 0;
  int talanganAktifCount = 0;
  double saldoKas = 0;
  double totalPemasukan = 0;
  double totalPengeluaran = 0;
  double totalIuranAktif = 0;
  double pencairanAktif = 0;
  double totalIuranKasBulanIni = 0;
  double totalTalanganAktif = 0;
  String periodeAktif = '-';
  String penerimaArisanTerakhir = '-';
  String bulanKasAktif = '-';
  int? periodeAktifId;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  String _monthKey(DateTime date) => '${date.year}-${date.month.toString().padLeft(2, '0')}';

  Future<void> _load() async {
    final db = DatabaseHelper.instance;
    final now = DateTime.now();
    final monthKey = _monthKey(now);
    final monthDate = '$monthKey-01';
    final pa = await db.getPeriodeAktif();
    final pt = await db.getPemenangTerakhir();
    final talangan = await db.getTalanganAktif();
    var sudahArisan = 0;
    var belumArisan = 0;
    var iuranArisan = 0.0;
    var pencairanArisan = 0.0;
    if (pa?.id != null) {
      sudahArisan = await db.countPembayaranStatus(pa!.id!, 'Sudah Bayar');
      final belumList = await db.getAnggotaBelumBayar(pa.id!);
      belumArisan = belumList.length;
      iuranArisan = await db.totalIuranPeriode(pa.id!);
      pencairanArisan = await db.totalPencairanPeriode(pa.id!);
    }

    final sudahKas = await db.getPembayaranKasDetail(monthDate);
    final belumKas = await db.getAnggotaBelumBayarKas(monthDate);
    final talanganTotal = talangan.fold<double>(0, (sum, item) => sum + ((item['nominal_bayar'] as num?)?.toDouble() ?? 0));

    final result = await Future.wait([
      db.countAnggota('Aktif'),
      db.countAnggota('Nonaktif'),
      db.countAnggotaIkut(jenis: 'arisan'),
      db.countAnggotaIkut(jenis: 'kas'),
      db.getSaldoKas(),
      db.totalKasByJenis('Pemasukan'),
      db.totalKasByJenis('Pengeluaran'),
      db.totalIuranKasBulanan(monthDate),
    ]);
    if (!mounted) return;
    setState(() {
      aktif = result[0] as int;
      nonAktif = result[1] as int;
      ikutArisan = result[2] as int;
      ikutKas = result[3] as int;
      saldoKas = result[4] as double;
      totalPemasukan = result[5] as double;
      totalPengeluaran = result[6] as double;
      totalIuranKasBulanIni = result[7] as double;
      sudahBayarArisan = sudahArisan;
      belumBayarArisan = belumArisan;
      sudahBayarKasBulanIni = sudahKas.length;
      belumBayarKasBulanIni = belumKas.length;
      talanganAktifCount = talangan.length;
      totalTalanganAktif = talanganTotal;
      totalIuranAktif = iuranArisan;
      pencairanAktif = pencairanArisan;
      periodeAktif = pa?.namaPeriode ?? '-';
      periodeAktifId = pa?.id;
      penerimaArisanTerakhir = pt == null ? '-' : '${pt['nama']} / ${pt['nama_periode']}';
      bulanKasAktif = monthKey;
      loading = false;
    });
  }

  String _memberLines(List<Anggota> members) {
    if (members.isEmpty) return 'Tidak ada data.';
    return members.map((a) => '• ${a.nama}${a.wilayah.isNotEmpty ? ' - ${a.wilayah}' : ''}${a.noHp.isNotEmpty ? ' (${a.noHp})' : ''}').join('\n');
  }

  String _paymentLines(List<Map<String, dynamic>> payments) {
    if (payments.isEmpty) return 'Tidak ada data pembayaran pada periode aktif.';
    return payments.map((p) {
      final nama = p['nama'] ?? '-';
      final status = p['status_bayar'] ?? '-';
      final sumber = p['sumber_bayar'] ?? 'Pribadi';
      final nominal = AppFormatters.rupiah((p['nominal_bayar'] as num?)?.toDouble() ?? 0);
      return '• $nama - $status - $nominal - $sumber';
    }).join('\n');
  }

  String _kasPaymentLines(List<Map<String, dynamic>> payments) {
    if (payments.isEmpty) return 'Belum ada anggota yang tercatat bayar kas pada bulan ini.';
    return payments.map((p) {
      final nama = p['nama'] ?? '-';
      final nominal = AppFormatters.rupiah((p['nominal_bayar'] as num?)?.toDouble() ?? 0);
      final tanggal = p['tanggal_bayar'] ?? '-';
      return '• $nama - $nominal - $tanggal';
    }).join('\n');
  }

  String _talanganLines(List<Map<String, dynamic>> data) {
    if (data.isEmpty) return 'Tidak ada talangan aktif.';
    return data.map((item) {
      final nama = item['nama'] ?? '-';
      final periode = item['nama_periode'] ?? '-';
      final nominal = AppFormatters.rupiah((item['nominal_bayar'] as num?)?.toDouble() ?? 0);
      final tanggal = item['tanggal_bayar'] ?? '-';
      return '• $nama - $periode - $nominal - $tanggal';
    }).join('\n');
  }

  String _kasLines(List<KasTransaksi> transaksi, String jenis) {
    final filtered = transaksi.where((k) => k.jenisTransaksi == jenis).toList();
    if (filtered.isEmpty) return 'Belum ada transaksi $jenis.';
    return filtered.take(25).map((k) {
      return '• ${k.tanggalTransaksi} - ${k.kategori} - ${AppFormatters.rupiah(k.nominal)}\n  ${k.keterangan}';
    }).join('\n');
  }

  Future<void> _showDetail(String title, Future<String> Function() contentBuilder) async {
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (context) => const AlertDialog(
        content: Row(
          children: [
            SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2)),
            SizedBox(width: 16),
            Expanded(child: Text('Mengambil detail data...')),
          ],
        ),
      ),
    );

    String content;
    try {
      content = await contentBuilder();
    } catch (e) {
      content = 'Detail gagal dimuat: ${e.toString()}';
    }

    if (!mounted) return;
    Navigator.pop(context);
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 560),
          child: SingleChildScrollView(child: Text(content)),
        ),
        actions: [
          FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Tutup')),
        ],
      ),
    );
  }

  Future<String> _detailAnggotaAktif() async {
    final members = await DatabaseHelper.instance.getAnggota(status: 'Aktif');
    return 'Total anggota aktif: $aktif\n\nDaftar anggota:\n${_memberLines(members)}';
  }

  Future<String> _detailAnggotaNonAktif() async {
    final members = await DatabaseHelper.instance.getAnggota(status: 'Nonaktif');
    return 'Total anggota nonaktif: $nonAktif\n\nDaftar anggota:\n${_memberLines(members)}';
  }

  Future<String> _detailIkutArisan() async {
    final members = await DatabaseHelper.instance.getAnggotaIkutArisan();
    return 'Total anggota ikut arisan: $ikutArisan\n\nDaftar anggota:\n${_memberLines(members)}';
  }

  Future<String> _detailIkutKas() async {
    final members = await DatabaseHelper.instance.getAnggotaIkutKas();
    return 'Total anggota ikut kas: $ikutKas\n\nDaftar anggota:\n${_memberLines(members)}';
  }

  Future<String> _detailPembayaranArisan() async {
    if (periodeAktifId == null) return 'Belum ada periode arisan aktif.';
    final payments = await DatabaseHelper.instance.getPembayaranDetail(periodeAktifId!);
    return 'Periode aktif: $periodeAktif\nTotal sudah bayar: $sudahBayarArisan\nTotal iuran masuk: ${AppFormatters.rupiah(totalIuranAktif)}\n\nDaftar pembayaran:\n${_paymentLines(payments)}';
  }

  Future<String> _detailBelumBayarArisan() async {
    if (periodeAktifId == null) return 'Belum ada periode arisan aktif.';
    final members = await DatabaseHelper.instance.getAnggotaBelumBayar(periodeAktifId!);
    return 'Periode aktif: $periodeAktif\nTotal belum bayar arisan: $belumBayarArisan\n\nDaftar belum bayar:\n${_memberLines(members)}';
  }

  Future<String> _detailPembayaranKas() async {
    final paid = await DatabaseHelper.instance.getPembayaranKasDetail('$bulanKasAktif-01');
    return 'Bulan kas: $bulanKasAktif\nTotal sudah bayar kas: $sudahBayarKasBulanIni\nTotal iuran kas bulan ini: ${AppFormatters.rupiah(totalIuranKasBulanIni)}\n\nDaftar pembayaran kas:\n${_kasPaymentLines(paid)}';
  }

  Future<String> _detailBelumBayarKas() async {
    final members = await DatabaseHelper.instance.getAnggotaBelumBayarKas('$bulanKasAktif-01');
    return 'Bulan kas: $bulanKasAktif\nTotal belum bayar kas: $belumBayarKasBulanIni\n\nDaftar belum bayar kas:\n${_memberLines(members)}';
  }

  Future<String> _detailTalanganAktif() async {
    final data = await DatabaseHelper.instance.getTalanganAktif();
    return 'Total anggota masih ditalangi: $talanganAktifCount\nTotal nilai talangan aktif: ${AppFormatters.rupiah(totalTalanganAktif)}\n\nDaftar talangan aktif:\n${_talanganLines(data)}';
  }

  Future<String> _detailSaldoArisan() async {
    final saldoArisan = totalIuranAktif - pencairanAktif;
    return 'Periode aktif: $periodeAktif\n\nTotal iuran terkumpul: ${AppFormatters.rupiah(totalIuranAktif)}\nTotal pencairan penerima arisan: ${AppFormatters.rupiah(pencairanAktif)}\nSaldo arisan aktif: ${AppFormatters.rupiah(saldoArisan)}\n\nCatatan: saldo arisan otomatis berkurang setelah penerima arisan dicatat dengan status penerimaan Sudah Diterima.';
  }

  Future<String> _detailKas(String jenis) async {
    final transaksi = await DatabaseHelper.instance.getKas();
    final total = jenis == 'Pemasukan' ? totalPemasukan : totalPengeluaran;
    return 'Total $jenis kas: ${AppFormatters.rupiah(total)}\nSaldo kas saat ini: ${AppFormatters.rupiah(saldoKas)}\n\nTransaksi terbaru:\n${_kasLines(transaksi, jenis)}';
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());
    final saldoArisan = totalIuranAktif - pencairanAktif;
    final arisanProgress = ikutArisan == 0 ? 0.0 : (sudahBayarArisan / ikutArisan).clamp(0.0, 1.0);
    final kasProgress = ikutKas == 0 ? 0.0 : (sudahBayarKasBulanIni / ikutKas).clamp(0.0, 1.0);
    final isWide = MediaQuery.of(context).size.width > 720;

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _HeroPanel(
            periodeAktif: periodeAktif,
            bulanKasAktif: bulanKasAktif,
            penerimaArisanTerakhir: penerimaArisanTerakhir,
            saldoKas: saldoKas,
            saldoArisan: saldoArisan,
            onRefresh: _load,
          ),
          const SizedBox(height: 14),
          _SectionTitle(title: 'Status Utama', subtitle: 'Ringkasan cepat kondisi arisan, kas, dan talangan.'),
          const SizedBox(height: 10),
          _ResponsiveGrid(
            isWide: isWide,
            children: [
              _MetricCard(title: 'Belum Bayar Arisan', value: '$belumBayarArisan orang', subtitle: periodeAktif, icon: Icons.warning_amber_rounded, tone: const Color(0xFFFFF3D6), onTap: () => _showDetail('Belum Bayar Arisan', _detailBelumBayarArisan)),
              _MetricCard(title: 'Belum Bayar Kas', value: '$belumBayarKasBulanIni orang', subtitle: 'Bulan $bulanKasAktif', icon: Icons.savings_outlined, tone: const Color(0xFFE8F4FF), onTap: () => _showDetail('Belum Bayar Kas', _detailBelumBayarKas)),
              _MetricCard(title: 'Talangan Aktif', value: '$talanganAktifCount orang', subtitle: AppFormatters.rupiah(totalTalanganAktif), icon: Icons.volunteer_activism_outlined, tone: const Color(0xFFFFE8EC), onTap: () => _showDetail('Talangan Aktif', _detailTalanganAktif)),
              _MetricCard(title: 'Saldo Kas WK', value: AppFormatters.rupiah(saldoKas), subtitle: 'Kas berjalan', icon: Icons.account_balance_wallet_outlined, tone: const Color(0xFFE9F8EE), onTap: () => _showDetail('Saldo Kas WK', () => _detailKas('Pemasukan'))),
            ],
          ),
          const SizedBox(height: 14),
          _SectionTitle(title: 'Panel Arisan', subtitle: 'Progress periode aktif dan saldo arisan.'),
          const SizedBox(height: 10),
          _DashboardPanel(
            children: [
              _ProgressCard(
                title: 'Progress Pembayaran Arisan',
                progress: arisanProgress,
                leadingValue: '$sudahBayarArisan/$ikutArisan',
                trailingText: '${(arisanProgress * 100).toStringAsFixed(0)}%',
                description: 'Sudah bayar pada periode aktif.',
                color: const Color(0xFF7B2CBF),
                onTap: () => _showDetail('Pembayaran Arisan', _detailPembayaranArisan),
              ),
              const SizedBox(height: 10),
              _InlineMetrics(metrics: [
                _InlineMetricData('Total Iuran', AppFormatters.rupiah(totalIuranAktif), Icons.payments_outlined, () => _showDetail('Total Iuran Arisan', _detailPembayaranArisan)),
                _InlineMetricData('Pencairan', AppFormatters.rupiah(pencairanAktif), Icons.outbox_outlined, () => _showDetail('Pencairan Penerima Arisan', _detailSaldoArisan)),
                _InlineMetricData('Saldo Arisan', AppFormatters.rupiah(saldoArisan), Icons.event_available_outlined, () => _showDetail('Saldo Arisan', _detailSaldoArisan)),
              ]),
            ],
          ),
          const SizedBox(height: 14),
          _SectionTitle(title: 'Panel Kas WK', subtitle: 'Progress iuran kas bulan berjalan dan mutasi kas.'),
          const SizedBox(height: 10),
          _DashboardPanel(
            children: [
              _ProgressCard(
                title: 'Progress Iuran Kas Bulan Ini',
                progress: kasProgress,
                leadingValue: '$sudahBayarKasBulanIni/$ikutKas',
                trailingText: '${(kasProgress * 100).toStringAsFixed(0)}%',
                description: 'Bulan $bulanKasAktif. Ketuk untuk melihat anggota yang sudah bayar kas.',
                color: const Color(0xFF198754),
                onTap: () => _showDetail('Pembayaran Kas Bulan Ini', _detailPembayaranKas),
              ),
              const SizedBox(height: 10),
              _InlineMetrics(metrics: [
                _InlineMetricData('Iuran Kas', AppFormatters.rupiah(totalIuranKasBulanIni), Icons.savings_outlined, () => _showDetail('Pembayaran Kas Bulan Ini', _detailPembayaranKas)),
                _InlineMetricData('Pemasukan', AppFormatters.rupiah(totalPemasukan), Icons.trending_up_outlined, () => _showDetail('Pemasukan Kas', () => _detailKas('Pemasukan'))),
                _InlineMetricData('Pengeluaran', AppFormatters.rupiah(totalPengeluaran), Icons.trending_down_outlined, () => _showDetail('Pengeluaran Kas', () => _detailKas('Pengeluaran'))),
              ]),
            ],
          ),
          const SizedBox(height: 14),
          _SectionTitle(title: 'Panel Keanggotaan', subtitle: 'Komposisi anggota aktif, kas, dan arisan.'),
          const SizedBox(height: 10),
          _ResponsiveGrid(
            isWide: isWide,
            children: [
              _MetricCard(title: 'Anggota Aktif', value: '$aktif', subtitle: 'Total aktif', icon: Icons.people_alt_outlined, tone: const Color(0xFFF1ECFF), onTap: () => _showDetail('Anggota Aktif', _detailAnggotaAktif)),
              _MetricCard(title: 'Ikut Arisan', value: '$ikutArisan', subtitle: 'Eligible arisan', icon: Icons.groups_outlined, tone: const Color(0xFFEAF7F0), onTap: () => _showDetail('Anggota Ikut Arisan', _detailIkutArisan)),
              _MetricCard(title: 'Ikut Kas', value: '$ikutKas', subtitle: 'Eligible kas', icon: Icons.account_balance_outlined, tone: const Color(0xFFEAF1FF), onTap: () => _showDetail('Anggota Ikut Kas', _detailIkutKas)),
              _MetricCard(title: 'Nonaktif', value: '$nonAktif', subtitle: 'Tidak aktif', icon: Icons.person_off_outlined, tone: const Color(0xFFF4F4F4), onTap: () => _showDetail('Anggota Nonaktif', _detailAnggotaNonAktif)),
            ],
          ),
          const SizedBox(height: 16),
          const Text('Tarik layar ke bawah untuk refresh. Semua kartu dapat diketuk untuk melihat detail.', style: TextStyle(color: Colors.black54)),
        ],
      ),
    );
  }
}

class _HeroPanel extends StatelessWidget {
  final String periodeAktif;
  final String bulanKasAktif;
  final String penerimaArisanTerakhir;
  final double saldoKas;
  final double saldoArisan;
  final Future<void> Function() onRefresh;

  const _HeroPanel({required this.periodeAktif, required this.bulanKasAktif, required this.penerimaArisanTerakhir, required this.saldoKas, required this.saldoArisan, required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF6F35A5), Color(0xFF9D7BD8)]),
        borderRadius: BorderRadius.circular(22),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.08), blurRadius: 14, offset: const Offset(0, 8))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(child: Text('Dashboard Arisan WK', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold))),
              IconButton(onPressed: onRefresh, icon: const Icon(Icons.refresh, color: Colors.white), tooltip: 'Refresh'),
            ],
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _HeroChip(icon: Icons.event_note_outlined, label: 'Periode: $periodeAktif'),
              _HeroChip(icon: Icons.calendar_month_outlined, label: 'Kas: $bulanKasAktif'),
              _HeroChip(icon: Icons.emoji_events_outlined, label: 'Penerima terakhir: $penerimaArisanTerakhir'),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(child: _HeroAmount(label: 'Saldo Kas', value: AppFormatters.rupiah(saldoKas))),
              const SizedBox(width: 10),
              Expanded(child: _HeroAmount(label: 'Saldo Arisan', value: AppFormatters.rupiah(saldoArisan))),
            ],
          ),
        ],
      ),
    );
  }
}

class _HeroChip extends StatelessWidget {
  final IconData icon;
  final String label;

  const _HeroChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.14), borderRadius: BorderRadius.circular(999)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 15, color: Colors.white),
          const SizedBox(width: 6),
          Flexible(child: Text(label, style: const TextStyle(color: Colors.white, fontSize: 12))),
        ],
      ),
    );
  }
}

class _HeroAmount extends StatelessWidget {
  final String label;
  final String value;

  const _HeroAmount({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.16), borderRadius: BorderRadius.circular(16)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final String subtitle;

  const _SectionTitle({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 2),
        Text(subtitle, style: const TextStyle(color: Colors.black54, fontSize: 12)),
      ],
    );
  }
}

class _ResponsiveGrid extends StatelessWidget {
  final bool isWide;
  final List<Widget> children;

  const _ResponsiveGrid({required this.isWide, required this.children});

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: isWide ? 4 : 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      childAspectRatio: isWide ? 1.55 : 1.18,
      children: children,
    );
  }
}

class _DashboardPanel extends StatelessWidget {
  final List<Widget> children;

  const _DashboardPanel({required this.children});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  final String title;
  final String value;
  final String subtitle;
  final IconData icon;
  final Color tone;
  final VoidCallback? onTap;

  const _MetricCard({required this.title, required this.value, required this.subtitle, required this.icon, required this.tone, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      color: tone,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(13),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(icon, size: 28, color: Theme.of(context).colorScheme.primary),
                  Icon(Icons.open_in_new, size: 16, color: Colors.grey.shade600),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(value, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 2),
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w600), maxLines: 1, overflow: TextOverflow.ellipsis),
                  Text(subtitle, style: const TextStyle(color: Colors.black54, fontSize: 11), maxLines: 1, overflow: TextOverflow.ellipsis),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ProgressCard extends StatelessWidget {
  final String title;
  final double progress;
  final String leadingValue;
  final String trailingText;
  final String description;
  final Color color;
  final VoidCallback? onTap;

  const _ProgressCard({required this.title, required this.progress, required this.leadingValue, required this.trailingText, required this.description, required this.color, this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(4),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold))),
                Text(leadingValue, style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(width: 8),
                Text(trailingText, style: TextStyle(color: color, fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(999),
              child: LinearProgressIndicator(value: progress, minHeight: 10, backgroundColor: color.withValues(alpha: 0.12), valueColor: AlwaysStoppedAnimation<Color>(color)),
            ),
            const SizedBox(height: 6),
            Text(description, style: const TextStyle(color: Colors.black54, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}

class _InlineMetricData {
  final String label;
  final String value;
  final IconData icon;
  final VoidCallback onTap;

  const _InlineMetricData(this.label, this.value, this.icon, this.onTap);
}

class _InlineMetrics extends StatelessWidget {
  final List<_InlineMetricData> metrics;

  const _InlineMetrics({required this.metrics});

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: metrics.map((m) {
        return InkWell(
          onTap: m.onTap,
          borderRadius: BorderRadius.circular(14),
          child: Container(
            width: 180,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: Colors.grey.shade50, borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.grey.shade200)),
            child: Row(
              children: [
                Icon(m.icon, size: 22, color: Theme.of(context).colorScheme.primary),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(m.value, style: const TextStyle(fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis),
                      Text(m.label, style: const TextStyle(color: Colors.black54, fontSize: 11), maxLines: 1, overflow: TextOverflow.ellipsis),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }
}
