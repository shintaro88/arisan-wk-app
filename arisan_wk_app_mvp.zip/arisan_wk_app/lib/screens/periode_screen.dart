import 'package:flutter/material.dart';

import '../core/database/database_helper.dart';
import '../core/utils/formatters.dart';
import '../models/periode_model.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/numeric_text_field.dart';

class PeriodeScreen extends StatefulWidget {
  const PeriodeScreen({super.key});

  @override
  State<PeriodeScreen> createState() => _PeriodeScreenState();
}

class _PeriodeScreenState extends State<PeriodeScreen> {
  List<PeriodeArisan> _periode = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final data = await DatabaseHelper.instance.getPeriode();
    if (!mounted) return;
    setState(() {
      _periode = data;
      _loading = false;
    });
  }

  Future<void> _openForm({PeriodeArisan? periode}) async {
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (context) => _PeriodeForm(periode: periode),
    );
    if (saved == true) _load();
  }

  Future<void> _delete(PeriodeArisan periode) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus periode?'),
        content: Text('Periode ${periode.namaPeriode} akan dihapus.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus')),
        ],
      ),
    );
    if (ok == true && periode.id != null) {
      await DatabaseHelper.instance.deletePeriode(periode.id!);
      await _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openForm(),
        icon: const Icon(Icons.add),
        label: const Text('Tambah'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _periode.isEmpty
              ? const Center(child: Text('Belum ada periode arisan'))
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
                  itemCount: _periode.length,
                  itemBuilder: (context, index) {
                    final item = _periode[index];
                    return Card(
                      child: ListTile(
                        leading: Icon(item.status == 'Aktif' ? Icons.event_available : Icons.event_busy),
                        title: Text(item.namaPeriode, style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text('${item.tanggalArisan} • ${item.lokasi}\nIuran: ${AppFormatters.rupiah(item.nominalIuran)} • ${item.status}'),
                        isThreeLine: true,
                        trailing: PopupMenuButton<String>(
                          onSelected: (value) {
                            if (value == 'edit') _openForm(periode: item);
                            if (value == 'delete') _delete(item);
                          },
                          itemBuilder: (context) => const [
                            PopupMenuItem(value: 'edit', child: Text('Edit')),
                            PopupMenuItem(value: 'delete', child: Text('Hapus')),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}

class _PeriodeForm extends StatefulWidget {
  final PeriodeArisan? periode;

  const _PeriodeForm({this.periode});

  @override
  State<_PeriodeForm> createState() => _PeriodeFormState();
}

class _PeriodeFormState extends State<_PeriodeForm> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nama;
  late final TextEditingController _tanggal;
  late final TextEditingController _lokasi;
  late final TextEditingController _nominal;
  late final TextEditingController _catatan;
  String _status = 'Aktif';

  @override
  void initState() {
    super.initState();
    final p = widget.periode;
    _nama = TextEditingController(text: p?.namaPeriode ?? '');
    _tanggal = TextEditingController(text: p?.tanggalArisan ?? AppFormatters.today());
    _lokasi = TextEditingController(text: p?.lokasi ?? '');
    _nominal = TextEditingController(text: p == null ? '50000' : p.nominalIuran.toStringAsFixed(0));
    _catatan = TextEditingController(text: p?.catatan ?? '');
    _status = p?.status ?? 'Aktif';
  }

  @override
  void dispose() {
    _nama.dispose();
    _tanggal.dispose();
    _lokasi.dispose();
    _nominal.dispose();
    _catatan.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final periode = PeriodeArisan(
      id: widget.periode?.id,
      namaPeriode: _nama.text.trim(),
      tanggalArisan: _tanggal.text.trim(),
      lokasi: _lokasi.text.trim(),
      nominalIuran: AppFormatters.parseNumber(_nominal.text),
      status: _status,
      catatan: _catatan.text.trim(),
    );
    if (widget.periode == null) {
      await DatabaseHelper.instance.insertPeriode(periode);
    } else {
      await DatabaseHelper.instance.updatePeriode(periode);
    }
    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(context).viewInsets.bottom + 16),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(widget.periode == null ? 'Tambah Periode' : 'Edit Periode', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              TextFormField(controller: _nama, decoration: const InputDecoration(labelText: 'Nama periode'), validator: (v) => v == null || v.trim().isEmpty ? 'Nama periode wajib diisi' : null),
              const SizedBox(height: 10),
              DatePickerField(controller: _tanggal, labelText: 'Tanggal arisan'),
              const SizedBox(height: 10),
              TextFormField(controller: _lokasi, decoration: const InputDecoration(labelText: 'Lokasi')),
              const SizedBox(height: 10),
              NumericTextField(controller: _nominal, labelText: 'Nominal iuran', validator: (v) => AppFormatters.parseNumber(v ?? '') <= 0 ? 'Nominal wajib lebih dari 0' : null),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                initialValue: _status,
                decoration: const InputDecoration(labelText: 'Status'),
                items: const ['Aktif', 'Selesai'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                onChanged: (value) => setState(() => _status = value ?? 'Aktif'),
              ),
              const SizedBox(height: 10),
              TextFormField(controller: _catatan, decoration: const InputDecoration(labelText: 'Catatan'), maxLines: 2),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Simpan'))),
            ],
          ),
        ),
      ),
    );
  }
}
