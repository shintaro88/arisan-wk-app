import 'package:flutter/material.dart';

import '../core/database/database_helper.dart';
import '../core/utils/formatters.dart';
import '../models/anggota_model.dart';
import '../models/pembayaran_model.dart';
import '../models/periode_model.dart';

class PembayaranScreen extends StatefulWidget {
  const PembayaranScreen({super.key});

  @override
  State<PembayaranScreen> createState() => _PembayaranScreenState();
}

class _PembayaranScreenState extends State<PembayaranScreen> {
  List<PeriodeArisan> _periode = [];
  PeriodeArisan? _selected;
  List<Map<String, dynamic>> _pembayaran = [];
  double _total = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final periode = await DatabaseHelper.instance.getPeriode();
    final selected = periode.isNotEmpty ? periode.first : null;
    if (!mounted) return;
    setState(() {
      _periode = periode;
      _selected = selected;
      _loading = false;
    });
    await _loadDetail();
  }

  Future<void> _loadDetail() async {
    if (_selected?.id == null) return;
    final detail = await DatabaseHelper.instance.getPembayaranDetail(_selected!.id!);
    final total = await DatabaseHelper.instance.totalIuranPeriode(_selected!.id!);
    if (!mounted) return;
    setState(() {
      _pembayaran = detail;
      _total = total;
    });
  }

  Future<void> _openForm() async {
    if (_selected == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Buat periode arisan terlebih dahulu.')));
      return;
    }
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (context) => _PembayaranForm(periode: _selected!),
    );
    if (saved == true) _loadDetail();
  }

  Future<void> _delete(int id) async {
    await DatabaseHelper.instance.deletePembayaran(id);
    await _loadDetail();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openForm,
        icon: const Icon(Icons.add),
        label: const Text('Input Bayar'),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
        children: [
          DropdownButtonFormField<PeriodeArisan>(
            value: _selected,
            decoration: const InputDecoration(labelText: 'Pilih periode'),
            items: _periode.map((p) => DropdownMenuItem(value: p, child: Text(p.namaPeriode))).toList(),
            onChanged: (value) {
              setState(() => _selected = value);
              _loadDetail();
            },
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.summarize),
              title: const Text('Total Iuran Terkumpul'),
              subtitle: Text(AppFormatters.rupiah(_total), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
          ),
          const SizedBox(height: 12),
          if (_pembayaran.isEmpty)
            const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('Belum ada pembayaran pada periode ini.')))
          else
            ..._pembayaran.map((item) => Card(
                  child: ListTile(
                    title: Text(item['nama']?.toString() ?? '-', style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('${item['status_bayar']} • ${item['metode_bayar']} • ${item['tanggal_bayar']}\n${AppFormatters.rupiah((item['nominal_bayar'] as num?) ?? 0)}'),
                    isThreeLine: true,
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () => _delete(item['id'] as int),
                    ),
                  ),
                )),
        ],
      ),
    );
  }
}

class _PembayaranForm extends StatefulWidget {
  final PeriodeArisan periode;

  const _PembayaranForm({required this.periode});

  @override
  State<_PembayaranForm> createState() => _PembayaranFormState();
}

class _PembayaranFormState extends State<_PembayaranForm> {
  final _formKey = GlobalKey<FormState>();
  final _nominal = TextEditingController();
  final _tanggal = TextEditingController(text: AppFormatters.today());
  final _catatan = TextEditingController();
  String _metode = 'Tunai';
  List<Anggota> _anggota = [];
  Anggota? _selectedAnggota;

  @override
  void initState() {
    super.initState();
    _nominal.text = widget.periode.nominalIuran.toStringAsFixed(0);
    _loadAnggota();
  }

  Future<void> _loadAnggota() async {
    final data = await DatabaseHelper.instance.getAnggota(status: 'Aktif');
    if (!mounted) return;
    setState(() {
      _anggota = data;
      if (data.isNotEmpty) _selectedAnggota = data.first;
    });
  }

  @override
  void dispose() {
    _nominal.dispose();
    _tanggal.dispose();
    _catatan.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedAnggota?.id == null || widget.periode.id == null) return;
    final bayar = AppFormatters.parseNumber(_nominal.text);
    final status = PembayaranIuran.hitungStatus(widget.periode.nominalIuran, bayar);
    final item = PembayaranIuran(
      idAnggota: _selectedAnggota!.id!,
      idPeriode: widget.periode.id!,
      nominalIuran: widget.periode.nominalIuran,
      nominalBayar: bayar,
      tanggalBayar: _tanggal.text.trim(),
      metodeBayar: _metode,
      statusBayar: status,
      catatan: _catatan.text.trim(),
    );
    await DatabaseHelper.instance.insertPembayaran(item);
    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(context).viewInsets.bottom + 16),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Input Pembayaran Iuran', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text('Periode: ${widget.periode.namaPeriode}'),
              const SizedBox(height: 16),
              DropdownButtonFormField<Anggota>(
                value: _selectedAnggota,
                decoration: const InputDecoration(labelText: 'Anggota'),
                items: _anggota.map((a) => DropdownMenuItem(value: a, child: Text(a.nama))).toList(),
                onChanged: (value) => setState(() => _selectedAnggota = value),
                validator: (v) => v == null ? 'Pilih anggota' : null,
              ),
              const SizedBox(height: 10),
              TextFormField(controller: _nominal, decoration: const InputDecoration(labelText: 'Nominal bayar'), keyboardType: TextInputType.number, validator: (v) => AppFormatters.parseNumber(v ?? '') < 0 ? 'Nominal tidak valid' : null),
              const SizedBox(height: 10),
              TextFormField(controller: _tanggal, decoration: const InputDecoration(labelText: 'Tanggal bayar')),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: _metode,
                decoration: const InputDecoration(labelText: 'Metode bayar'),
                items: const ['Tunai', 'Transfer', 'QRIS', 'Lainnya'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                onChanged: (value) => setState(() => _metode = value ?? 'Tunai'),
              ),
              const SizedBox(height: 10),
              TextFormField(controller: _catatan, decoration: const InputDecoration(labelText: 'Catatan'), maxLines: 2),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Simpan'))),
            ],
          ),
        ),
      ),
    );
  }
}
