import 'package:flutter/material.dart';

import '../core/database/database_helper.dart';
import '../core/utils/formatters.dart';
import '../models/anggota_model.dart';
import '../models/pembayaran_model.dart';
import '../models/periode_model.dart';
import '../widgets/date_picker_field.dart';

class PembayaranScreen extends StatefulWidget {
  const PembayaranScreen({super.key});

  @override
  State<PembayaranScreen> createState() => _PembayaranScreenState();
}

class _PembayaranScreenState extends State<PembayaranScreen> {
  List<PeriodeArisan> _periode = [];
  PeriodeArisan? _selected;
  List<Map<String, dynamic>> _pembayaran = [];
  double _total = 0;
  double _pencairan = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final periode = await DatabaseHelper.instance.getPeriode();
    final selected = periode.isNotEmpty ? periode.first : null;
    if (!mounted) return;
    setState(() {
      _periode = periode;
      _selected = selected;
      _loading = false;
    });
    await _loadDetail();
  }

  Future<void> _loadDetail() async {
    if (_selected?.id == null) return;
    final detail = await DatabaseHelper.instance.getPembayaranDetail(_selected!.id!);
    final total = await DatabaseHelper.instance.totalIuranPeriode(_selected!.id!);
    final pencairan = await DatabaseHelper.instance.totalPencairanPeriode(_selected!.id!);
    if (!mounted) return;
    setState(() {
      _pembayaran = detail;
      _total = total;
      _pencairan = pencairan;
    });
  }

  Future<void> _openForm() async {
    if (_selected == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Buat periode arisan terlebih dahulu.')));
      return;
    }
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (context) => _PembayaranBatchForm(periode: _selected!),
    );
    if (saved == true) _loadDetail();
  }

  Future<void> _delete(int id) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus pembayaran?'),
        content: const Text('Data pembayaran anggota ini akan dihapus dari periode terpilih.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus')),
        ],
      ),
    );
    if (ok == true) {
      await DatabaseHelper.instance.deletePembayaran(id);
      await _loadDetail();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    final estimasiTarget = _pembayaran.length * (_selected?.nominalIuran ?? 0);
    final saldoArisan = _total - _pencairan;
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openForm,
        icon: const Icon(Icons.checklist),
        label: const Text('Centang Peserta'),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
        children: [
          DropdownButtonFormField<PeriodeArisan>(
            initialValue: _selected,
            decoration: const InputDecoration(labelText: 'Pilih periode'),
            items: _periode.map((p) => DropdownMenuItem(value: p, child: Text(p.namaPeriode))).toList(),
            onChanged: (value) async {
              setState(() => _selected = value);
              await _loadDetail();
            },
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Rekap Periode Terpilih', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  _SummaryRow(label: 'Peserta/bayar tercatat', value: '${_pembayaran.length} orang'),
                  _SummaryRow(label: 'Nominal iuran per orang', value: AppFormatters.rupiah(_selected?.nominalIuran ?? 0)),
                  _SummaryRow(label: 'Target berdasarkan peserta', value: AppFormatters.rupiah(estimasiTarget)),
                  _SummaryRow(label: 'Total iuran terkumpul', value: AppFormatters.rupiah(_total)),
                  _SummaryRow(label: 'Pencairan pemenang', value: AppFormatters.rupiah(_pencairan)),
                  _SummaryRow(label: 'Saldo arisan setelah undian', value: AppFormatters.rupiah(saldoArisan)),
                  const SizedBox(height: 4),
                  Text('Saldo arisan otomatis berkurang ketika pemenang dicatat dengan status Sudah Diterima.', style: TextStyle(fontSize: 12, color: Colors.grey.shade700)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (_pembayaran.isEmpty)
            const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('Belum ada peserta/pembayaran pada periode ini. Tekan tombol “Centang Peserta”.')))
          else
            ..._pembayaran.map((item) => Card(
                  child: ListTile(
                    title: Text(item['nama']?.toString() ?? '-', style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('${item['status_bayar']} • ${item['metode_bayar']} • ${item['tanggal_bayar']}\n${AppFormatters.rupiah((item['nominal_bayar'] as num?) ?? 0)}'),
                    isThreeLine: true,
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () => _delete(item['id'] as int),
                    ),
                  ),
                )),
        ],
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  final String label;
  final String value;

  const _SummaryRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(child: Text(label, style: const TextStyle(color: Colors.black54))),
          const SizedBox(width: 12),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}

class _PembayaranBatchForm extends StatefulWidget {
  final PeriodeArisan periode;

  const _PembayaranBatchForm({required this.periode});

  @override
  State<_PembayaranBatchForm> createState() => _PembayaranBatchFormState();
}

class _PembayaranBatchFormState extends State<_PembayaranBatchForm> {
  final _formKey = GlobalKey<FormState>();
  final _nominal = TextEditingController();
  final _tanggal = TextEditingController(text: AppFormatters.today());
  final _catatan = TextEditingController();
  String _metode = 'Tunai';
  List<Anggota> _anggotaBelumBayar = [];
  List<Map<String, dynamic>> _anggotaSudahBayar = [];
  final Set<int> _selectedAnggotaIds = <int>{};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _nominal.text = widget.periode.nominalIuran.toStringAsFixed(0);
    _loadAnggota();
  }

  Future<void> _loadAnggota() async {
    if (widget.periode.id == null) return;
    final belumBayar = await DatabaseHelper.instance.getAnggotaBelumBayar(widget.periode.id!);
    final sudahBayar = await DatabaseHelper.instance.getPembayaranDetail(widget.periode.id!);
    if (!mounted) return;
    setState(() {
      _anggotaBelumBayar = belumBayar;
      _anggotaSudahBayar = sudahBayar;
      _loading = false;
    });
  }

  @override
  void dispose() {
    _nominal.dispose();
    _tanggal.dispose();
    _catatan.dispose();
    super.dispose();
  }

  double get _nominalPerOrang => AppFormatters.parseNumber(_nominal.text);
  double get _totalTerpilih => _selectedAnggotaIds.length * _nominalPerOrang;
  bool get _semuaTerpilih => _anggotaBelumBayar.isNotEmpty && _anggotaBelumBayar.every((a) => a.id != null && _selectedAnggotaIds.contains(a.id));

  void _toggleSemua(bool? checked) {
    setState(() {
      _selectedAnggotaIds.clear();
      if (checked == true) {
        for (final anggota in _anggotaBelumBayar) {
          if (anggota.id != null) _selectedAnggotaIds.add(anggota.id!);
        }
      }
    });
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (widget.periode.id == null) return;
    if (_selectedAnggotaIds.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pilih minimal satu anggota yang ikut arisan.')));
      return;
    }

    final bayar = AppFormatters.parseNumber(_nominal.text);
    final status = PembayaranIuran.hitungStatus(widget.periode.nominalIuran, bayar);
    var saved = 0;

    try {
      for (final idAnggota in _selectedAnggotaIds) {
        final item = PembayaranIuran(
          idAnggota: idAnggota,
          idPeriode: widget.periode.id!,
          nominalIuran: widget.periode.nominalIuran,
          nominalBayar: bayar,
          tanggalBayar: _tanggal.text.trim(),
          metodeBayar: _metode,
          statusBayar: status,
          catatan: _catatan.text.trim(),
        );
        await DatabaseHelper.instance.insertPembayaran(item);
        saved++;
      }
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
      if (saved > 0) Navigator.pop(context, true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(context).viewInsets.bottom + 16),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Centang Peserta Arisan', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text('Periode: ${widget.periode.namaPeriode}'),
              Text('Iuran normal: ${AppFormatters.rupiah(widget.periode.nominalIuran)}'),
              const SizedBox(height: 16),
              TextFormField(
                controller: _nominal,
                decoration: const InputDecoration(labelText: 'Nominal bayar per anggota'),
                keyboardType: TextInputType.number,
                onChanged: (_) => setState(() {}),
                validator: (v) => AppFormatters.parseNumber(v ?? '') < 0 ? 'Nominal tidak valid' : null,
              ),
              const SizedBox(height: 10),
              DatePickerField(controller: _tanggal, labelText: 'Tanggal bayar'),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                initialValue: _metode,
                decoration: const InputDecoration(labelText: 'Metode bayar'),
                items: const ['Tunai', 'Transfer', 'QRIS', 'Lainnya'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                onChanged: (value) => setState(() => _metode = value ?? 'Tunai'),
              ),
              const SizedBox(height: 10),
              TextFormField(controller: _catatan, decoration: const InputDecoration(labelText: 'Catatan'), maxLines: 2),
              const SizedBox(height: 14),
              Card(
                color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.35),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Total Otomatis', style: TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 6),
                      Text('${_selectedAnggotaIds.length} anggota x ${AppFormatters.rupiah(_nominalPerOrang)}'),
                      Text(AppFormatters.rupiah(_totalTerpilih), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              if (_loading)
                const Center(child: CircularProgressIndicator())
              else ...[
                if (_anggotaBelumBayar.isEmpty)
                  const Padding(padding: EdgeInsets.all(12), child: Text('Semua anggota aktif sudah tercatat pada periode ini.'))
                else ...[
                  CheckboxListTile(
                    value: _semuaTerpilih,
                    onChanged: _toggleSemua,
                    controlAffinity: ListTileControlAffinity.leading,
                    title: const Text('Centang semua yang belum bayar'),
                    subtitle: const Text('Nama yang sudah bayar tidak muncul di daftar centang agar tidak dobel.'),
                  ),
                  const Divider(),
                  ConstrainedBox(
                    constraints: const BoxConstraints(maxHeight: 280),
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: _anggotaBelumBayar.length,
                      itemBuilder: (context, index) {
                        final anggota = _anggotaBelumBayar[index];
                        final id = anggota.id;
                        final selected = id != null && _selectedAnggotaIds.contains(id);
                        return CheckboxListTile(
                          value: selected,
                          onChanged: id == null
                              ? null
                              : (checked) {
                                  setState(() {
                                    if (checked == true) {
                                      _selectedAnggotaIds.add(id);
                                    } else {
                                      _selectedAnggotaIds.remove(id);
                                    }
                                  });
                                },
                          controlAffinity: ListTileControlAffinity.leading,
                          title: Text(anggota.nama),
                          subtitle: Text(anggota.wilayah.isEmpty ? 'Tanpa wilayah' : anggota.wilayah),
                        );
                      },
                    ),
                  ),
                ],
                if (_anggotaSudahBayar.isNotEmpty) ...[
                  const SizedBox(height: 14),
                  const Text('Sudah Bayar / Lunas', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  ..._anggotaSudahBayar.map((item) => ListTile(
                        dense: true,
                        leading: const Icon(Icons.check_circle, color: Colors.green),
                        title: Text(item['nama']?.toString() ?? '-'),
                        subtitle: Text('${item['status_bayar']} • ${item['tanggal_bayar']} • ${AppFormatters.rupiah((item['nominal_bayar'] as num?) ?? 0)}'),
                      )),
                ],
              ],
              const SizedBox(height: 16),
              SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Simpan Peserta Tercentang'))),
            ],
          ),
        ),
      ),
    );
  }
}
