import 'package:flutter/material.dart';

import 'anggota_screen.dart';
import 'dashboard_screen.dart';
import 'kas_screen.dart';
import 'laporan_screen.dart';
import 'pembayaran_screen.dart';
import 'periode_screen.dart';
import 'pemenang_screen.dart';
import 'pengaturan_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  final _pages = const [
    DashboardScreen(),
    AnggotaScreen(),
    PeriodeScreen(),
    PembayaranScreen(),
    PemenangScreen(),
    KasScreen(),
    LaporanScreen(),
    PengaturanScreen(),
  ];

  final _titles = const [
    'Dashboard',
    'Data Anggota',
    'Periode Arisan',
    'Pembayaran Iuran',
    'Pemenang Arisan',
    'Kas WK',
    'Laporan',
    'Pengaturan',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_titles[_index]),
      ),
      body: _pages[_index],
      drawer: NavigationDrawer(
        selectedIndex: _index,
        onDestinationSelected: (value) {
          setState(() => _index = value);
          Navigator.pop(context);
        },
        children: const [
          Padding(
            padding: EdgeInsets.fromLTRB(24, 24, 24, 8),
            child: Text('Arisan WK', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(24, 0, 24, 16),
            child: Text('Administrasi arisan dan kas Wanita Katolik'),
          ),
          NavigationDrawerDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: Text('Dashboard')),
          NavigationDrawerDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: Text('Data Anggota')),
          NavigationDrawerDestination(icon: Icon(Icons.event_note_outlined), selectedIcon: Icon(Icons.event_note), label: Text('Periode Arisan')),
          NavigationDrawerDestination(icon: Icon(Icons.payments_outlined), selectedIcon: Icon(Icons.payments), label: Text('Pembayaran Iuran')),
          NavigationDrawerDestination(icon: Icon(Icons.emoji_events_outlined), selectedIcon: Icon(Icons.emoji_events), label: Text('Pemenang')),
          NavigationDrawerDestination(icon: Icon(Icons.account_balance_wallet_outlined), selectedIcon: Icon(Icons.account_balance_wallet), label: Text('Kas WK')),
          NavigationDrawerDestination(icon: Icon(Icons.assessment_outlined), selectedIcon: Icon(Icons.assessment), label: Text('Laporan')),
          NavigationDrawerDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: Text('Pengaturan')),
        ],
      ),
    );
  }
}
