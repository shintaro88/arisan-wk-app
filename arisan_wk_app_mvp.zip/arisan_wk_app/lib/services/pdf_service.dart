import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'download_storage_service.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../core/utils/formatters.dart';
import '../models/kas_model.dart';
import '../models/pengaturan_model.dart';

class _SummaryItem {
  final String label;
  final String value;

  const _SummaryItem(this.label, this.value);
}

class PdfService {
  Future<String> exportGenericReport({
    required String title,
    required List<String> headers,
    required List<List<Object?>> rows,
    required Pengaturan pengaturan,
    required String fileName,
  }) async {
    final pdf = pw.Document();
    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4.landscape,
        margin: const pw.EdgeInsets.all(28),
        build: (context) => [
          _header(title, pengaturan),
          pw.SizedBox(height: 16),
          _table(headers, rows),
        ],
      ),
    );
    return _savePdf(pdf, fileName);
  }

  Future<String> exportTunggakanPivotReport({
    required String title,
    required String jenisIuran,
    required List<Map<String, dynamic>> rows,
    required Pengaturan pengaturan,
    required String fileName,
  }) async {
    final totalOrang = rows.length;
    final totalBulan = rows.fold<int>(0, (sum, item) => sum + ((item['jumlah_bulan'] as num?)?.toInt() ?? 0));
    final totalNominal = rows.fold<double>(0, (sum, item) => sum + ((item['total_nominal'] as num?)?.toDouble() ?? 0));

    final pdf = pw.Document();
    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4.landscape,
        margin: const pw.EdgeInsets.all(26),
        build: (context) => [
          _header(title, pengaturan),
          pw.SizedBox(height: 10),
          pw.Text(
            'Format simpel per anggota agar mudah dibaca: contoh Natalia: Mei - Juni. Kolom keterangan akan menampilkan status khusus seperti dana talangan.',
            style: const pw.TextStyle(fontSize: 9),
          ),
          pw.SizedBox(height: 12),
          _summaryCards([
            _SummaryItem('Jenis Iuran', jenisIuran),
            _SummaryItem('Jumlah Anggota', '$totalOrang orang'),
            _SummaryItem('Total Bulan Tertunggak', '$totalBulan bulan'),
            _SummaryItem('Estimasi Nominal', AppFormatters.rupiah(totalNominal)),
          ]),
          pw.SizedBox(height: 14),
          _pivotTunggakanTable(rows),
        ],
      ),
    );
    return _savePdf(pdf, fileName);
  }

  Future<String> exportKas({required List<KasTransaksi> transaksi, required Pengaturan pengaturan}) async {
    double pemasukan = 0;
    double pengeluaran = 0;
    final rows = <List<Object?>>[];
    for (var i = 0; i < transaksi.length; i++) {
      final item = transaksi[i];
      final masuk = item.jenisTransaksi == 'Pemasukan' ? item.nominal : 0;
      final keluar = item.jenisTransaksi == 'Pengeluaran' ? item.nominal : 0;
      pemasukan += masuk;
      pengeluaran += keluar;
      rows.add([i + 1, item.tanggalTransaksi, item.jenisTransaksi, item.kategori, item.keterangan, masuk, keluar, item.penanggungJawab]);
    }
    rows.add(['', '', '', '', 'TOTAL', pemasukan, pengeluaran, '']);
    rows.add(['', '', '', '', 'SALDO AKHIR', pemasukan - pengeluaran, '', '']);
    return exportGenericReport(
      title: 'Laporan Kas WK',
      headers: ['No', 'Tanggal', 'Jenis', 'Kategori', 'Keterangan', 'Pemasukan', 'Pengeluaran', 'PJ'],
      rows: rows,
      pengaturan: pengaturan,
      fileName: 'Laporan_Kas_WK.pdf',
    );
  }

  Future<String> exportBuktiPembayaran({
    required Map<String, dynamic> pembayaran,
    required Pengaturan pengaturan,
  }) async {
    final id = pembayaran['id']?.toString() ?? '0';
    final nama = pembayaran['nama']?.toString() ?? '-';
    final periode = pembayaran['nama_periode']?.toString() ?? '-';
    final tanggal = pembayaran['tanggal_bayar']?.toString() ?? '-';
    final nominal = (pembayaran['nominal_bayar'] as num?)?.toDouble() ?? 0;
    final metode = pembayaran['metode_bayar']?.toString() ?? '-';
    final status = pembayaran['status_bayar']?.toString() ?? '-';
    final jenisBukti = pembayaran['jenis_bukti']?.toString() ?? 'Arisan';
    final sumberBayar = pembayaran['sumber_bayar']?.toString() ?? 'Pribadi';
    final statusTalangan = pembayaran['status_talangan']?.toString() ?? 'Tidak Ada';
    final title = jenisBukti == 'Kas' ? 'Bukti Pembayaran Iuran Kas' : 'Bukti Pembayaran Iuran Arisan';
    final periodeLabel = jenisBukti == 'Kas' ? 'Periode Kas' : 'Periode Arisan';
    final receiptNo = _receiptNumber('$jenisBukti-$id', nama, periode, tanggal, nominal);
    final verification = _verificationCode(receiptNo, nominal, status);

    final pdf = pw.Document();
    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(36),
        build: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            _header(title, pengaturan),
            pw.SizedBox(height: 24),
            pw.Container(
              width: double.infinity,
              padding: const pw.EdgeInsets.all(16),
              decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.purple, width: 1.2), borderRadius: pw.BorderRadius.circular(8)),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('Nomor Bukti: $receiptNo', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 14)),
                  pw.SizedBox(height: 8),
                  _receiptRow(jenisBukti == 'Kas' ? 'Pembayar' : 'Nama Anggota', nama),
                  _receiptRow(periodeLabel, periode),
                  _receiptRow('Jenis Iuran', jenisBukti),
                  _receiptRow('Tanggal Transaksi', tanggal),
                  _receiptRow('Metode Bayar', metode),
                  _receiptRow('Nominal Bayar', AppFormatters.rupiah(nominal)),
                  _receiptRow('Status', status),
                  if (jenisBukti == 'Arisan') _receiptRow('Sumber Bayar', sumberBayar),
                  if (sumberBayar == 'Ditalangi Kas WK') _receiptRow('Status Talangan', statusTalangan),
                ],
              ),
            ),
            pw.SizedBox(height: 16),
            pw.Container(
              width: double.infinity,
              padding: const pw.EdgeInsets.all(12),
              decoration: pw.BoxDecoration(color: PdfColors.grey200, borderRadius: pw.BorderRadius.circular(6)),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('Kode Validasi Bukti', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                  pw.SizedBox(height: 4),
                  pw.Text(verification, style: const pw.TextStyle(fontSize: 10)),
                  pw.SizedBox(height: 4),
                  pw.Text('Catatan: kode ini dibuat otomatis dari data transaksi. Jika isi bukti berubah, kode validasi juga akan berbeda.', style: const pw.TextStyle(fontSize: 9)),
                ],
              ),
            ),
            pw.SizedBox(height: 24),
            pw.Text('Dokumen ini sah sebagai bukti transaksi internal apabila nomor bukti dan kode validasi sesuai dengan data transaksi pada aplikasi.', style: const pw.TextStyle(fontSize: 9)),
          ],
        ),
      ),
    );
    return _savePdf(pdf, 'Bukti_Iuran_${jenisBukti}_${_safe(nama)}_$id.pdf');
  }

  pw.Widget _summaryCards(List<_SummaryItem> items) {
    return pw.Row(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        for (final item in items)
          pw.Expanded(
            child: pw.Container(
              margin: const pw.EdgeInsets.only(right: 8),
              padding: const pw.EdgeInsets.all(10),
              decoration: pw.BoxDecoration(
                color: PdfColor(0.96, 0.93, 0.99),
                border: pw.Border.all(color: PdfColor(0.75, 0.63, 0.84), width: 0.6),
                borderRadius: pw.BorderRadius.circular(7),
              ),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text(item.label, style: pw.TextStyle(fontSize: 8, color: PdfColor(0.35, 0.35, 0.35))),
                  pw.SizedBox(height: 4),
                  pw.Text(item.value, style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold)),
                ],
              ),
            ),
          ),
      ],
    );
  }

  pw.Widget _pivotTunggakanTable(List<Map<String, dynamic>> rows) {
    const headers = ['No', 'Nama Anggota', 'Bulan Belum Bayar', 'Total', 'Keterangan'];

    pw.Widget cell(String text, {bool header = false, PdfColor? color, pw.Alignment alignment = pw.Alignment.centerLeft}) {
      return pw.Container(
        padding: const pw.EdgeInsets.symmetric(vertical: 7, horizontal: 7),
        color: header ? PdfColors.purple : color,
        alignment: alignment,
        child: pw.Text(
          text,
          style: pw.TextStyle(
            fontSize: header ? 9 : 10,
            fontWeight: header ? pw.FontWeight.bold : pw.FontWeight.normal,
            color: header ? PdfColors.white : PdfColors.black,
          ),
        ),
      );
    }

    final tableRows = <pw.TableRow>[
      pw.TableRow(children: headers.map((h) => cell(h, header: true)).toList()),
    ];

    for (var i = 0; i < rows.length; i++) {
      final item = rows[i];
      final nama = item['nama']?.toString() ?? '-';
      final bg = _pastelForName(nama);
      tableRows.add(
        pw.TableRow(
          children: [
            cell('${i + 1}', color: bg, alignment: pw.Alignment.center),
            cell(nama, color: bg),
            cell(item['bulan_ringkas']?.toString() ?? '-', color: bg),
            cell(AppFormatters.rupiah((item['total_nominal'] as num?)?.toDouble() ?? 0), color: bg),
            cell(item['keterangan']?.toString() ?? 'Belum bayar', color: bg),
          ],
        ),
      );
    }

    return pw.Table(
      border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.35),
      columnWidths: {
        0: pw.FixedColumnWidth(28),
        1: pw.FlexColumnWidth(1.5),
        2: pw.FlexColumnWidth(1.4),
        3: pw.FlexColumnWidth(1.0),
        4: pw.FlexColumnWidth(1.7),
      },
      children: tableRows,
    );
  }

  PdfColor _pastelForName(String name) {
    final palette = <PdfColor>[
      PdfColor(0.98, 0.93, 0.96),
      PdfColor(0.93, 0.97, 1.00),
      PdfColor(0.94, 0.98, 0.94),
      PdfColor(1.00, 0.96, 0.90),
      PdfColor(0.96, 0.94, 1.00),
      PdfColor(0.93, 0.98, 0.97),
      PdfColor(1.00, 0.94, 0.92),
      PdfColor(0.97, 0.97, 0.90),
    ];
    var hash = 0;
    for (final code in name.toLowerCase().codeUnits) {
      hash = (hash + code) % palette.length;
    }
    return palette[hash];
  }

  pw.Widget _table(List<String> headers, List<List<Object?>> rows) {
    pw.Widget cell(String text, {bool header = false}) {
      return pw.Container(
        padding: const pw.EdgeInsets.all(5),
        color: header ? PdfColors.purple : null,
        child: pw.Text(
          text,
          style: pw.TextStyle(fontSize: 8, fontWeight: header ? pw.FontWeight.bold : pw.FontWeight.normal, color: header ? PdfColors.white : PdfColors.black),
        ),
      );
    }

    return pw.Table(
      border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.4),
      children: [
        pw.TableRow(children: headers.map((h) => cell(h, header: true)).toList()),
        ...rows.map((row) => pw.TableRow(children: row.map((item) => cell(_formatCell(item))).toList())),
      ],
    );
  }

  pw.Widget _header(String title, Pengaturan pengaturan) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(pengaturan.namaOrganisasi, style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
        pw.Text(title, style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
        pw.Text('Tanggal Cetak: ${AppFormatters.today()}', style: const pw.TextStyle(fontSize: 10)),
        pw.Divider(thickness: 1),
      ],
    );
  }

  pw.Widget _receiptRow(String label, String value) {
    return pw.Padding(
      padding: const pw.EdgeInsets.only(bottom: 6),
      child: pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.SizedBox(width: 120, child: pw.Text(label)),
          pw.Text(': '),
          pw.Expanded(child: pw.Text(value, style: pw.TextStyle(fontWeight: pw.FontWeight.bold))),
        ],
      ),
    );
  }

  String _formatCell(Object? value) {
    if (value is double) return AppFormatters.rupiah(value);
    if (value is num) return value.toString();
    return value?.toString() ?? '';
  }

  String _receiptNumber(String id, String nama, String periode, String tanggal, double nominal) {
    final raw = '$id|$nama|$periode|$tanggal|$nominal';
    final digest = sha256.convert(utf8.encode(raw)).toString().substring(0, 8).toUpperCase();
    return 'WK-$id-$digest';
  }

  String _verificationCode(String receiptNo, double nominal, String status) {
    final raw = '$receiptNo|$nominal|$status|ARISAN-WK';
    return sha256.convert(utf8.encode(raw)).toString().toUpperCase();
  }

  String _safe(String text) => text.replaceAll(RegExp(r'[^A-Za-z0-9_-]+'), '_');

  Future<String> _savePdf(pw.Document pdf, String fileName) async {
    return DownloadStorageService.saveReport(
      bytes: await pdf.save(),
      fileName: fileName.replaceAll('/', '_'),
      mimeType: 'application/pdf',
    );
  }
}
