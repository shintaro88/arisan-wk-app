import 'dart:typed_data';

import 'package:excel/excel.dart' as xls;
import 'download_storage_service.dart';

import '../core/utils/formatters.dart';
import '../models/anggota_model.dart';
import '../models/kas_model.dart';
import '../models/pengaturan_model.dart';

class ExcelService {
  Future<String> exportAnggota({required List<Anggota> anggota, required Pengaturan pengaturan}) async {
    final excel = xls.Excel.createExcel();
    final sheet = excel['Data Anggota'];
    _writeTitle(sheet, 'Laporan Data Anggota', pengaturan.namaOrganisasi);
    _writeRow(sheet, 4, ['No', 'Nama', 'Status', 'Tanggal Bergabung', 'Catatan']);

    for (var i = 0; i < anggota.length; i++) {
      final item = anggota[i];
      _writeRow(sheet, i + 5, [
        i + 1,
        item.nama,
        item.status,
        item.tanggalBergabung,
        item.catatan,
      ]);
    }
    return _save(excel, 'Laporan_Anggota_WK.xlsx');
  }

  Future<String> exportKas({required List<KasTransaksi> transaksi, required Pengaturan pengaturan}) async {
    final excel = xls.Excel.createExcel();
    final sheet = excel['Laporan Kas'];
    _writeTitle(sheet, 'Laporan Kas WK', pengaturan.namaOrganisasi);
    _writeRow(sheet, 4, ['No', 'Tanggal', 'Jenis', 'Kategori', 'Keterangan', 'Pemasukan', 'Pengeluaran', 'Penanggung Jawab']);

    double pemasukan = 0;
    double pengeluaran = 0;
    for (var i = 0; i < transaksi.length; i++) {
      final item = transaksi[i];
      final masuk = item.jenisTransaksi == 'Pemasukan' ? item.nominal : 0;
      final keluar = item.jenisTransaksi == 'Pengeluaran' ? item.nominal : 0;
      pemasukan += masuk;
      pengeluaran += keluar;
      _writeRow(sheet, i + 5, [
        i + 1,
        item.tanggalTransaksi,
        item.jenisTransaksi,
        item.kategori,
        item.keterangan,
        masuk,
        keluar,
        item.penanggungJawab,
      ]);
    }

    final totalRow = transaksi.length + 6;
    _writeRow(sheet, totalRow, ['Total', '', '', '', '', pemasukan, pengeluaran, '']);
    _writeRow(sheet, totalRow + 1, ['Saldo Akhir', '', '', '', '', pemasukan - pengeluaran, '', '']);
    return _save(excel, 'Laporan_Kas_WK.xlsx');
  }

  Future<String> exportGenericReport({
    required String sheetName,
    required String title,
    required List<String> headers,
    required List<List<Object?>> rows,
    required Pengaturan pengaturan,
    required String fileName,
  }) async {
    final excel = xls.Excel.createExcel();
    final sheet = excel[sheetName];
    _writeTitle(sheet, title, pengaturan.namaOrganisasi);
    _writeRow(sheet, 4, headers);
    for (var i = 0; i < rows.length; i++) {
      _writeRow(sheet, i + 5, rows[i]);
    }
    return _save(excel, fileName);
  }

  void _writeTitle(xls.Sheet sheet, String title, String organisasi) {
    _setCell(sheet, 0, 0, title);
    _setCell(sheet, 0, 1, organisasi);
    _setCell(sheet, 0, 2, 'Tanggal Cetak: ${AppFormatters.today()}');
  }

  void _writeRow(xls.Sheet sheet, int row, List<Object?> values) {
    for (var col = 0; col < values.length; col++) {
      _setCell(sheet, col, row, values[col]);
    }
  }

  void _setCell(xls.Sheet sheet, int col, int row, Object? value) {
    final cell = sheet.cell(xls.CellIndex.indexByColumnRow(columnIndex: col, rowIndex: row));
    if (value is int) {
      cell.value = xls.IntCellValue(value);
    } else if (value is double) {
      cell.value = xls.DoubleCellValue(value);
    } else if (value is num) {
      cell.value = xls.DoubleCellValue(value.toDouble());
    } else {
      cell.value = xls.TextCellValue(value?.toString() ?? '');
    }
  }

  Future<String> _save(xls.Excel excel, String fileName) async {
    final bytes = excel.save();
    if (bytes == null) {
      throw Exception('Gagal membuat file Excel');
    }

    return DownloadStorageService.saveReport(
      bytes: Uint8List.fromList(bytes),
      fileName: fileName.replaceAll('/', '_'),
      mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    );
  }
}
