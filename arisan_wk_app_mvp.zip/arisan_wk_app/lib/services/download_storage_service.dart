import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

class DownloadStorageService {
  DownloadStorageService._();

  static const MethodChannel _channel = MethodChannel('arisan_wk/download_storage');
  static const String reportDir = 'Arisan WK';
  static const String backupDir = 'Arisan WK/Backup Database';

  static String get reportLocationLabel => 'Download/$reportDir';
  static String get backupLocationLabel => 'Download/$backupDir';

  static Future<String> saveReport({
    required Uint8List bytes,
    required String fileName,
    required String mimeType,
  }) {
    return saveToDownloads(bytes: bytes, fileName: fileName, mimeType: mimeType, relativeDir: reportDir);
  }

  static Future<String> saveBackup({
    required Uint8List bytes,
    required String fileName,
  }) {
    return saveToDownloads(bytes: bytes, fileName: fileName, mimeType: 'application/octet-stream', relativeDir: backupDir);
  }

  static Future<String> saveToDownloads({
    required Uint8List bytes,
    required String fileName,
    required String mimeType,
    required String relativeDir,
  }) async {
    final safeFileName = fileName.replaceAll('/', '_');

    if (Platform.isAndroid) {
      try {
        final result = await _channel.invokeMethod<String>('saveToDownloads', {
          'bytes': bytes,
          'fileName': safeFileName,
          'mimeType': mimeType,
          'relativeDir': relativeDir,
        });
        if (result != null && result.isNotEmpty) return result;
      } on PlatformException catch (e) {
        throw Exception(e.message ?? 'Gagal menyimpan file ke folder Download.');
      } on MissingPluginException {
        throw Exception('Fitur penyimpanan ke folder Download belum siap pada APK ini. Pastikan sudah install APK versi terbaru.');
      }
    }

    final fallback = await _fallbackDownloadDirectory(relativeDir);
    final outputPath = p.join(fallback.path, safeFileName);
    final file = File(outputPath);
    await file.create(recursive: true);
    await file.writeAsBytes(bytes, flush: true);
    return outputPath;
  }

  static Future<Uint8List> readLatestBackupFromDownloads() async {
    if (Platform.isAndroid) {
      try {
        final result = await _channel.invokeMethod<Uint8List>('readLatestBackupFromDownloads');
        if (result == null || result.isEmpty) {
          throw Exception('File backup database tidak ditemukan di $backupLocationLabel.');
        }
        return result;
      } on PlatformException catch (e) {
        throw Exception(e.message ?? 'Gagal membaca file backup dari folder Download.');
      } on MissingPluginException {
        throw Exception('Fitur restore dari folder Download belum siap pada APK ini. Pastikan sudah install APK versi terbaru.');
      }
    }

    final directory = await _fallbackDownloadDirectory(backupDir);
    final backups = directory
        .listSync()
        .whereType<File>()
        .where((file) {
          final name = p.basename(file.path).toLowerCase();
          return name.startsWith('arisan_wk_backup_') && name.endsWith('.db');
        })
        .toList()
      ..sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));

    if (backups.isEmpty) {
      throw Exception('File backup database tidak ditemukan di ${directory.path}.');
    }
    return backups.first.readAsBytes();
  }

  static Future<Directory> _fallbackDownloadDirectory(String relativeDir) async {
    final candidates = <Directory>[];
    try {
      final systemDownloads = await getDownloadsDirectory();
      if (systemDownloads != null) candidates.add(Directory(p.join(systemDownloads.path, relativeDir)));
    } catch (_) {}

    final appDocuments = await getApplicationDocumentsDirectory();
    candidates.add(Directory(p.join(appDocuments.path, 'Download', relativeDir)));

    for (final directory in candidates) {
      try {
        await directory.create(recursive: true);
        final probe = File(p.join(directory.path, '.write_test'));
        await probe.writeAsString('ok', flush: true);
        if (await probe.exists()) await probe.delete();
        return directory;
      } catch (_) {
        continue;
      }
    }
    throw Exception('Tidak bisa menemukan folder Download yang dapat ditulis.');
  }
}
