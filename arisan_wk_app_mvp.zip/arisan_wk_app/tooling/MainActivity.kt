package com.example.arisan_wk_app

import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

class MainActivity : FlutterActivity() {
    private val channelName = "arisan_wk/download_storage"
    private val backupRelativeDir = "Arisan WK/Backup Database"
    private val backupPrefix = "arisan_wk_backup_"
    private val backupSuffix = ".db"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            try {
                when (call.method) {
                    "saveToDownloads" -> {
                        val bytes = call.argument<ByteArray>("bytes")
                        val fileName = call.argument<String>("fileName") ?: "arisan_wk_file"
                        val mimeType = call.argument<String>("mimeType") ?: "application/octet-stream"
                        val relativeDir = call.argument<String>("relativeDir") ?: "Arisan WK"
                        if (bytes == null || bytes.isEmpty()) {
                            result.error("EMPTY_FILE", "File kosong, tidak bisa disimpan.", null)
                            return@setMethodCallHandler
                        }
                        val saved = saveToDownloads(bytes, fileName, mimeType, relativeDir)
                        result.success(saved)
                    }
                    "readLatestBackupFromDownloads" -> {
                        val bytes = readLatestBackupFromDownloads()
                        if (bytes == null || bytes.isEmpty()) {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
                                openManageAllFilesAccessSettings()
                                result.error(
                                    "NEED_STORAGE_ACCESS",
                                    "File backup belum bisa dibaca otomatis dari Download. Aktifkan izin akses file untuk aplikasi Arisan WK pada halaman pengaturan yang terbuka, lalu tekan Restore lagi.",
                                    null
                                )
                            } else {
                                result.error(
                                    "BACKUP_NOT_FOUND",
                                    "File backup database tidak ditemukan di Download/Arisan WK/Backup Database. Pastikan file backup bernama arisan_wk_backup_*.db dan berada di folder tersebut.",
                                    null
                                )
                            }
                        } else {
                            result.success(bytes)
                        }
                    }
                    "openFileFromDownloads" -> {
                        val fileName = call.argument<String>("fileName") ?: ""
                        val mimeType = call.argument<String>("mimeType") ?: "application/pdf"
                        val relativeDir = call.argument<String>("relativeDir") ?: "Arisan WK"
                        val uri = findDownloadFileUri(fileName, relativeDir)
                        if (uri == null) {
                            result.error("FILE_NOT_FOUND", "File $fileName tidak ditemukan di Download/$relativeDir.", null)
                        } else {
                            openFile(uri, mimeType)
                            result.success(true)
                        }
                    }
                    "shareFileFromDownloads" -> {
                        val fileName = call.argument<String>("fileName") ?: ""
                        val mimeType = call.argument<String>("mimeType") ?: "application/pdf"
                        val relativeDir = call.argument<String>("relativeDir") ?: "Arisan WK"
                        val uri = findDownloadFileUri(fileName, relativeDir)
                        if (uri == null) {
                            result.error("FILE_NOT_FOUND", "File $fileName tidak ditemukan di Download/$relativeDir.", null)
                        } else {
                            shareFile(uri, mimeType, fileName)
                            result.success(true)
                        }
                    }
                    else -> result.notImplemented()
                }
            } catch (e: Exception) {
                result.error("DOWNLOAD_STORAGE_ERROR", e.message ?: "Terjadi kesalahan penyimpanan Download.", null)
            }
        }
    }

    private fun saveToDownloads(bytes: ByteArray, fileName: String, mimeType: String, relativeDir: String): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = contentResolver
            val relativePath = Environment.DIRECTORY_DOWNLOADS + "/" + relativeDir.trim('/').replace("//", "/")
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, relativePath)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw Exception("Gagal membuat file di folder Download.")
            resolver.openOutputStream(uri)?.use { it.write(bytes) }
                ?: throw Exception("Gagal membuka file output di folder Download.")
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            "$relativePath/$fileName"
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), relativeDir)
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, fileName)
            FileOutputStream(file).use { it.write(bytes) }
            file.absolutePath
        }
    }

    private fun readLatestBackupFromDownloads(): ByteArray? {
        // 1) Coba baca melalui MediaStore. Ini yang paling sesuai untuk file di Download pada Android modern.
        readLatestBackupFromMediaStore()?.let { return it }

        // 2) Fallback baca path Download langsung. Ini penting setelah aplikasi di-uninstall/reinstall,
        // karena beberapa device tidak lagi menganggap file lama sebagai milik app baru di MediaStore.
        return readLatestBackupFromDirectDownloadPath()
    }

    private fun readLatestBackupFromMediaStore(): ByteArray? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val resolver = contentResolver
        val projection = arrayOf(
            MediaStore.Downloads._ID,
            MediaStore.Downloads.DISPLAY_NAME,
            MediaStore.Downloads.DATE_MODIFIED,
            MediaStore.Downloads.RELATIVE_PATH
        )
        val selection = "${MediaStore.Downloads.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("$backupPrefix%$backupSuffix")
        val sortOrder = "${MediaStore.Downloads.DATE_MODIFIED} DESC"
        resolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI, projection, selection, selectionArgs, sortOrder)?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Downloads._ID)
            val pathColumn = cursor.getColumnIndexOrThrow(MediaStore.Downloads.RELATIVE_PATH)
            val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
            while (cursor.moveToNext()) {
                val name = cursor.getString(nameColumn) ?: ""
                val relativePath = cursor.getString(pathColumn) ?: ""
                if (!isBackupFileName(name)) continue
                if (!isBackupRelativePath(relativePath)) continue
                val id = cursor.getLong(idColumn)
                val uri = ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id)
                readUri(uri)?.let { return it }
            }
        }
        return null
    }

    private fun readLatestBackupFromDirectDownloadPath(): ByteArray? {
        val backupDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), backupRelativeDir)
        if (!backupDir.exists() || !backupDir.isDirectory) return null
        val latest = backupDir.listFiles()
            ?.filter { it.isFile && isBackupFileName(it.name) }
            ?.maxWithOrNull(compareBy<File> { it.lastModified() }.thenBy { it.name })
        return try {
            latest?.readBytes()
        } catch (_: Exception) {
            null
        }
    }

    private fun isBackupFileName(name: String): Boolean {
        val lower = name.lowercase()
        return lower.startsWith(backupPrefix) && lower.endsWith(backupSuffix)
    }

    private fun isBackupRelativePath(relativePath: String): Boolean {
        val normalized = relativePath.replace('\\', '/').trim('/').lowercase()
        val expected1 = "download/${backupRelativeDir.lowercase()}"
        val expected2 = "downloads/${backupRelativeDir.lowercase()}"
        return normalized == expected1 || normalized == expected2 || normalized.endsWith("/${backupRelativeDir.lowercase()}") || normalized.endsWith(expected1)
    }

    private fun readUri(uri: Uri): ByteArray? {
        contentResolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArrayOutputStream()
            val data = ByteArray(16 * 1024)
            while (true) {
                val read = input.read(data)
                if (read <= 0) break
                buffer.write(data, 0, read)
            }
            return buffer.toByteArray()
        }
        return null
    }

    private fun findDownloadFileUri(fileName: String, relativeDir: String): Uri? {
        if (fileName.isBlank()) return null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val projection = arrayOf(
                MediaStore.Downloads._ID,
                MediaStore.Downloads.DISPLAY_NAME,
                MediaStore.Downloads.DATE_MODIFIED,
                MediaStore.Downloads.RELATIVE_PATH
            )
            val selection = "${MediaStore.Downloads.DISPLAY_NAME} = ?"
            val selectionArgs = arrayOf(fileName)
            val sortOrder = "${MediaStore.Downloads.DATE_MODIFIED} DESC"
            contentResolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI, projection, selection, selectionArgs, sortOrder)?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Downloads._ID)
                val pathColumn = cursor.getColumnIndexOrThrow(MediaStore.Downloads.RELATIVE_PATH)
                while (cursor.moveToNext()) {
                    val relativePath = cursor.getString(pathColumn) ?: ""
                    if (!isReportRelativePath(relativePath, relativeDir)) continue
                    val id = cursor.getLong(idColumn)
                    return ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id)
                }
            }
        }

        val file = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "$relativeDir/$fileName")
        return if (file.exists()) Uri.fromFile(file) else null
    }

    private fun isReportRelativePath(relativePath: String, relativeDir: String): Boolean {
        val normalized = relativePath.replace('\\', '/').trim('/').lowercase()
        val expected = "download/${relativeDir.trim('/').lowercase()}"
        val expected2 = "downloads/${relativeDir.trim('/').lowercase()}"
        return normalized == expected || normalized == expected2 || normalized.endsWith("/${relativeDir.trim('/').lowercase()}") || normalized.endsWith(expected)
    }

    private fun openFile(uri: Uri, mimeType: String) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(Intent.createChooser(intent, "Buka PDF Laporan"))
    }

    private fun shareFile(uri: Uri, mimeType: String, fileName: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, fileName)
            putExtra(Intent.EXTRA_TEXT, "Laporan Arisan WK: $fileName")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Bagikan PDF Laporan").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun openManageAllFilesAccessSettings() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        try {
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                data = Uri.parse("package:$packageName")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (_: Exception) {
            val intent = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        }
    }
}
