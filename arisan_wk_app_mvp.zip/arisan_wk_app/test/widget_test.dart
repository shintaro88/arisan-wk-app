import 'package:flutter_test/flutter_test.dart';
import 'package:arisan_wk_app/app.dart';

void main() {
  testWidgets('Aplikasi Arisan WK dapat dibuka', (WidgetTester tester) async {
    await tester.pumpWidget(const ArisanWkApp());
    expect(find.text('Arisan WK'), findsWidgets);
  });
}
