# Arisan WK App

Aplikasi Flutter offline untuk pengelolaan Arisan WK / Wanita Katolik.

## Fitur MVP
- Dashboard ringkas
- Data anggota
- Periode arisan
- Pembayaran iuran
- Pemenang arisan
- Kas WK
- Laporan dan export Excel
- Pengaturan organisasi
- Build APK otomatis via GitHub Actions

## Cara Build APK di GitHub
1. Upload seluruh isi folder ini ke repository GitHub.
2. Buka tab **Actions**.
3. Jalankan workflow **Build Flutter APK** atau tunggu workflow berjalan otomatis setelah push.
4. Download artifact bernama **Arisan-WK-APK**.
5. Extract file ZIP, lalu install `app-debug.apk` ke HP Android.

## Cara Build Lokal
```bash
flutter pub get
flutter create . --platforms=android
flutter build apk --debug
```

Output APK:
```text
build/app/outputs/flutter-apk/app-debug.apk
```


## Catatan v7
Dependency file_picker diperbarui agar kompatibel dengan Flutter/Android SDK terbaru di GitHub Actions.
