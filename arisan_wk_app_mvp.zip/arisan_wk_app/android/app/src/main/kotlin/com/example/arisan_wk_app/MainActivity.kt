package com.example.arisan_wk_app

import android.content.ContentUris
import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

class MainActivity : FlutterActivity() {
    private val channelName = "arisan_wk/download_storage"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            try {
                when (call.method) {
                    "saveToDownloads" -> {
                        val bytes = call.argument<ByteArray>("bytes")
                        val fileName = call.argument<String>("fileName") ?: "arisan_wk_file"
                        val mimeType = call.argument<String>("mimeType") ?: "application/octet-stream"
                        val relativeDir = call.argument<String>("relativeDir") ?: "Arisan WK"
                        if (bytes == null || bytes.isEmpty()) {
                            result.error("EMPTY_FILE", "File kosong, tidak bisa disimpan.", null)
                            return@setMethodCallHandler
                        }
                        val saved = saveToDownloads(bytes, fileName, mimeType, relativeDir)
                        result.success(saved)
                    }
                    "readLatestBackupFromDownloads" -> {
                        val bytes = readLatestBackupFromDownloads()
                        if (bytes == null || bytes.isEmpty()) {
                            result.error("BACKUP_NOT_FOUND", "File backup database tidak ditemukan di Download/Arisan WK/Backup Database.", null)
                        } else {
                            result.success(bytes)
                        }
                    }
                    else -> result.notImplemented()
                }
            } catch (e: Exception) {
                result.error("DOWNLOAD_STORAGE_ERROR", e.message ?: "Terjadi kesalahan penyimpanan Download.", null)
            }
        }
    }

    private fun saveToDownloads(bytes: ByteArray, fileName: String, mimeType: String, relativeDir: String): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = contentResolver
            val relativePath = Environment.DIRECTORY_DOWNLOADS + "/" + relativeDir.trim('/').replace("//", "/")
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, relativePath)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw Exception("Gagal membuat file di folder Download.")
            resolver.openOutputStream(uri)?.use { it.write(bytes) }
                ?: throw Exception("Gagal membuka file output di folder Download.")
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            "$relativePath/$fileName"
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), relativeDir)
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, fileName)
            FileOutputStream(file).use { it.write(bytes) }
            file.absolutePath
        }
    }

    private fun readLatestBackupFromDownloads(): ByteArray? {
        val dir = "Arisan WK/Backup Database"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = contentResolver
            val relativePath = Environment.DIRECTORY_DOWNLOADS + "/" + dir + "/"
            val projection = arrayOf(
                MediaStore.Downloads._ID,
                MediaStore.Downloads.DISPLAY_NAME,
                MediaStore.Downloads.DATE_MODIFIED,
                MediaStore.Downloads.RELATIVE_PATH
            )
            val selection = "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.DISPLAY_NAME} LIKE ?"
            val selectionArgs = arrayOf(relativePath, "arisan_wk_backup_%.db")
            val sortOrder = "${MediaStore.Downloads.DATE_MODIFIED} DESC"
            resolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI, projection, selection, selectionArgs, sortOrder)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Downloads._ID)
                    val id = cursor.getLong(idColumn)
                    val uri = ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id)
                    return readUri(uri)
                }
            }
            null
        } else {
            val backupDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), dir)
            if (!backupDir.exists()) return null
            val latest = backupDir.listFiles()
                ?.filter { it.isFile && it.name.startsWith("arisan_wk_backup_") && it.name.endsWith(".db") }
                ?.maxByOrNull { it.lastModified() }
            latest?.readBytes()
        }
    }

    private fun readUri(uri: Uri): ByteArray? {
        contentResolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArrayOutputStream()
            val data = ByteArray(16 * 1024)
            while (true) {
                val read = input.read(data)
                if (read <= 0) break
                buffer.write(data, 0, read)
            }
            return buffer.toByteArray()
        }
        return null
    }
}
