package com.wk.arisan_wk_app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileOutputStream

class MainActivity : FlutterActivity() {
    private val restoreChannelName = "arisan_wk_app/restore_picker"
    private val requestPickDatabase = 788748
    private var pendingResult: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, restoreChannelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "pickDatabaseBackup" -> openDatabasePicker(result)
                else -> result.notImplemented()
            }
        }
    }

    private fun openDatabasePicker(result: MethodChannel.Result) {
        if (pendingResult != null) {
            result.error("RESTORE_BUSY", "Proses pemilihan file masih berjalan.", null)
            return
        }

        pendingResult = result
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf(
                    "application/octet-stream",
                    "application/x-sqlite3",
                    "application/vnd.sqlite3",
                    "application/x-sqlite",
                    "application/db",
                    "application/database"
                )
            )
        }

        try {
            startActivityForResult(intent, requestPickDatabase)
        } catch (e: Exception) {
            pendingResult = null
            result.error("PICKER_ERROR", "Pemilih file tidak dapat dibuka: ${e.message}", null)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != requestPickDatabase) return

        val result = pendingResult
        pendingResult = null

        if (result == null) return
        if (resultCode != Activity.RESULT_OK) {
            result.success(null)
            return
        }

        val uri: Uri? = data?.data
        if (uri == null) {
            result.error("NO_FILE", "Tidak ada file yang dipilih.", null)
            return
        }

        try {
            val tempDir = File(cacheDir, "restore_database")
            if (!tempDir.exists()) tempDir.mkdirs()
            val tempFile = File(tempDir, "arisan_wk_restore.db")

            contentResolver.openInputStream(uri).use { input ->
                if (input == null) {
                    result.error("READ_ERROR", "File backup tidak dapat dibaca.", null)
                    return
                }
                FileOutputStream(tempFile, false).use { output ->
                    input.copyTo(output)
                }
            }

            if (!tempFile.exists() || tempFile.length() <= 0L) {
                result.error("EMPTY_FILE", "File backup kosong atau tidak valid.", null)
                return
            }

            result.success(tempFile.absolutePath)
        } catch (e: Exception) {
            result.error("RESTORE_COPY_ERROR", "Gagal membaca file backup: ${e.message}", null)
        }
    }
}
